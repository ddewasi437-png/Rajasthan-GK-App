package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GKViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GKViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // Determine theme dynamically based on manual setting in settings screen
            val darkTheme = when (viewModel.darkThemeOverride) {
                true -> true
                false -> false
                null -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = darkTheme) {
                var currentRoute by remember { mutableStateOf("splash") }

                // Synchronize viewmodel state tab with local route
                LaunchedEffect(viewModel.activeTab) {
                    if (currentRoute != "splash" && currentRoute != "onboarding") {
                        currentRoute = viewModel.activeTab
                    }
                }

                // Force authentication / profile setup guards
                LaunchedEffect(viewModel.isLoggedIn, viewModel.profileSetupCompleted, currentRoute) {
                    if (currentRoute == "splash" || currentRoute == "onboarding") {
                        return@LaunchedEffect
                    }
                    if (!viewModel.isLoggedIn) {
                        currentRoute = "login"
                    } else if (!viewModel.profileSetupCompleted) {
                        currentRoute = "profile_setup"
                    } else if (currentRoute == "login" || currentRoute == "profile_setup") {
                        currentRoute = "home"
                        viewModel.activeTab = "home"
                    }
                }

                // Root destinations that show bottom navigation bar
                val bottomNavigationRoutes = listOf("home", "quiz_hub", "pdf_notes", "leaderboard", "profile")
                val showBottomBar = bottomNavigationRoutes.contains(currentRoute)

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                NavigationBarItem(
                                    selected = currentRoute == "home",
                                    onClick = {
                                        viewModel.activeTab = "home"
                                        currentRoute = "home"
                                    },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text("मुख्य", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "quiz_hub",
                                    onClick = {
                                        viewModel.activeTab = "quiz_hub"
                                        currentRoute = "quiz_hub"
                                    },
                                    icon = { Icon(Icons.Default.Book, contentDescription = "Quiz Hub") },
                                    label = { Text("क्विज़", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "pdf_notes",
                                    onClick = {
                                        viewModel.activeTab = "pdf_notes"
                                        currentRoute = "pdf_notes"
                                    },
                                    icon = { Icon(Icons.Default.Description, contentDescription = "PDF Notes") },
                                    label = { Text("पीडीएफ", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "leaderboard",
                                    onClick = {
                                        viewModel.activeTab = "leaderboard"
                                        currentRoute = "leaderboard"
                                    },
                                    icon = { Icon(Icons.Default.EmojiEvents, contentDescription = "Leaderboard") },
                                    label = { Text("लीडरबोर्ड", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "profile",
                                    onClick = {
                                        viewModel.activeTab = "profile"
                                        currentRoute = "profile"
                                    },
                                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
                                    label = { Text("प्रोफ़ाइल", fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Crossfade(
                        targetState = currentRoute,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        label = "ScreenTransition"
                    ) { route ->
                        when (route) {
                            "splash" -> SplashScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    if (destination == "home") {
                                        viewModel.activeTab = "home"
                                    }
                                }
                            )
                            "onboarding" -> OnboardingScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    if (destination == "home") {
                                        viewModel.activeTab = "home"
                                    }
                                }
                            )
                            "login" -> LoginScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "profile_setup" -> ProfileSetupScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "home" -> HomeScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "quiz_hub" -> QuizHubScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "rajasthan_gk" -> GKCategoriesScreen(
                                type = "RAJASTHAN",
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "india_gk" -> GKCategoriesScreen(
                                type = "INDIA",
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "bookmarks" -> BookmarkScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "settings" -> SettingsScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "profile" -> ProfileScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "leaderboard" -> LeaderboardScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "current_affairs" -> CurrentAffairsScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "previous_papers" -> PreviousPapersScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "pdf_notes" -> NotesScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "quiz_screen" -> QuizScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "mock_test" -> MockTestScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "admin_panel" -> AdminPanelScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            "premium_rewards" -> PremiumRewardScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                            else -> HomeScreen(
                                viewModel = viewModel,
                                onNavigate = { destination ->
                                    currentRoute = destination
                                    viewModel.activeTab = destination
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
