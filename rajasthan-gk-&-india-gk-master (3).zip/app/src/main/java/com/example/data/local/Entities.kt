package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gk_categories")
data class GkCategory(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val type: String, // "RAJASTHAN" or "INDIA"
    val iconName: String
)

@Entity(tableName = "gk_questions")
data class GkQuestion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryId: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: String, // "A", "B", "C", or "D" (or correct match answer string)
    val explanation: String,
    val questionType: String = "MCQ", // "MCQ", "TF", "MATCH", "IMAGE"
    val imageUrl: String = "",
    val matchPairsLeft: String = "", // e.g. "1. विजय स्तंभ, 2. कीर्ति स्तंभ, 3. मेहरानगढ़"
    val matchPairsRight: String = "", // e.g. "A. जोधपुर, B. चित्तौड़गढ़, C. चित्तौड़गढ़"
    val reference: String = "राजस्थान माध्यमिक शिक्षा बोर्ड"
)

@Entity(tableName = "user_results")
data class UserResult(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val quizTitle: String,
    val totalQuestions: Int,
    val correctAnswers: Int,
    val score: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey val id: String, // e.g. "q_1" or "n_raj_his_1"
    val type: String, // "QUESTION" or "NOTE" or "AFFAIR"
    val title: String,
    val categoryId: String,
    val contentJson: String // Serialized question/note for restoration
)

@Entity(tableName = "study_notes")
data class StudyNote(
    @PrimaryKey val id: String,
    val categoryId: String,
    val title: String,
    val content: String,
    val pdfName: String,
    val fileSize: String = "1.5 MB",
    val isDownloaded: Boolean = false
)

@Entity(tableName = "current_affairs")
data class CurrentAffair(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val content: String,
    val date: String,
    val isMonthly: Boolean = false
)

@Entity(tableName = "previous_papers")
data class PreviousPaper(
    @PrimaryKey val id: String,
    val examName: String,
    val year: Int,
    val totalQuestions: Int,
    val subject: String
)

@Entity(tableName = "leaderboard")
data class LeaderboardEntry(
    @PrimaryKey val userId: String,
    val name: String,
    val score: Int,
    val rank: Int,
    val avatarId: String, // For beautiful student avatar display
    val district: String // E.g., "जयपुर", "जोधपुर", "अजमेर"
)
