package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GkDao {
    // Categories
    @Query("SELECT * FROM gk_categories")
    fun getAllCategories(): Flow<List<GkCategory>>

    @Query("SELECT * FROM gk_categories WHERE type = :type")
    fun getCategoriesByType(type: String): Flow<List<GkCategory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<GkCategory>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: GkCategory)

    @Query("DELETE FROM gk_categories WHERE id = :id")
    suspend fun deleteCategoryById(id: String)

    // Questions
    @Query("SELECT * FROM gk_questions")
    fun getAllQuestions(): Flow<List<GkQuestion>>

    @Query("SELECT * FROM gk_questions WHERE categoryId = :categoryId")
    fun getQuestionsByCategory(categoryId: String): Flow<List<GkQuestion>>

    @Query("SELECT * FROM gk_questions ORDER BY RANDOM() LIMIT :limit")
    fun getRandomQuestions(limit: Int): Flow<List<GkQuestion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<GkQuestion>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: GkQuestion)

    @Query("DELETE FROM gk_questions WHERE id = :id")
    suspend fun deleteQuestionById(id: Int)

    // User Results
    @Query("SELECT * FROM user_results ORDER BY timestamp DESC")
    fun getAllResults(): Flow<List<UserResult>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: UserResult)

    // Bookmarks
    @Query("SELECT * FROM bookmarks")
    fun getAllBookmarks(): Flow<List<Bookmark>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE id = :id)")
    suspend fun isBookmarked(id: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: Bookmark)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmarkById(id: String)

    // Study Notes
    @Query("SELECT * FROM study_notes")
    fun getAllNotes(): Flow<List<StudyNote>>

    @Query("SELECT * FROM study_notes WHERE categoryId = :categoryId")
    fun getNotesByCategory(categoryId: String): Flow<List<StudyNote>>

    @Query("UPDATE study_notes SET isDownloaded = :isDownloaded WHERE id = :id")
    suspend fun updateDownloadStatus(id: String, isDownloaded: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<StudyNote>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: StudyNote)

    @Query("DELETE FROM study_notes WHERE id = :id")
    suspend fun deleteNoteById(id: String)

    // Current Affairs
    @Query("SELECT * FROM current_affairs ORDER BY id DESC")
    fun getAllCurrentAffairs(): Flow<List<CurrentAffair>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCurrentAffairs(affairs: List<CurrentAffair>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCurrentAffair(affair: CurrentAffair)

    @Query("DELETE FROM current_affairs WHERE id = :id")
    suspend fun deleteCurrentAffairById(id: Int)

    // Previous Papers
    @Query("SELECT * FROM previous_papers ORDER BY year DESC")
    fun getAllPreviousPapers(): Flow<List<PreviousPaper>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreviousPapers(papers: List<PreviousPaper>)

    // Leaderboard
    @Query("SELECT * FROM leaderboard ORDER BY rank ASC")
    fun getLeaderboard(): Flow<List<LeaderboardEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboard(entries: List<LeaderboardEntry>)

    @Query("DELETE FROM leaderboard")
    suspend fun clearLeaderboard()
}
