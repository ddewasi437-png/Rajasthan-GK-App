package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GKRepository(private val gkDao: GkDao) {

    val allCategories: Flow<List<GkCategory>> = gkDao.getAllCategories()
    val rajasthanCategories: Flow<List<GkCategory>> = gkDao.getCategoriesByType("RAJASTHAN")
    val indiaCategories: Flow<List<GkCategory>> = gkDao.getCategoriesByType("INDIA")
    val allResults: Flow<List<UserResult>> = gkDao.getAllResults()
    val allBookmarks: Flow<List<Bookmark>> = gkDao.getAllBookmarks()
    val allNotes: Flow<List<StudyNote>> = gkDao.getAllNotes()
    val allCurrentAffairs: Flow<List<CurrentAffair>> = gkDao.getAllCurrentAffairs()
    val allPreviousPapers: Flow<List<PreviousPaper>> = gkDao.getAllPreviousPapers()
    val leaderboard: Flow<List<LeaderboardEntry>> = gkDao.getLeaderboard()

    fun getQuestionsByCategory(categoryId: String): Flow<List<GkQuestion>> =
        gkDao.getQuestionsByCategory(categoryId)

    fun getRandomQuestions(limit: Int): Flow<List<GkQuestion>> =
        gkDao.getRandomQuestions(limit)

    suspend fun isBookmarked(id: String): Boolean =
        gkDao.isBookmarked(id)

    suspend fun toggleBookmark(id: String, type: String, title: String, categoryId: String, contentJson: String) {
        if (gkDao.isBookmarked(id)) {
            gkDao.deleteBookmarkById(id)
        } else {
            gkDao.insertBookmark(Bookmark(id, type, title, categoryId, contentJson))
        }
    }

    suspend fun saveQuizResult(quizTitle: String, totalQuestions: Int, correctAnswers: Int, score: Int) {
        gkDao.insertResult(UserResult(quizTitle = quizTitle, totalQuestions = totalQuestions, correctAnswers = correctAnswers, score = score))
    }

    suspend fun updateDownloadStatus(id: String, isDownloaded: Boolean) {
        gkDao.updateDownloadStatus(id, isDownloaded)
    }

    // Function to populate initial DB data if it's empty
    suspend fun checkAndSeedDatabase() {
        withContext(Dispatchers.IO) {
            val existing = gkDao.getAllCategories().firstOrNull()
            if (existing.isNullOrEmpty()) {
                seedDatabase()
            }
        }
    }

    private suspend fun seedDatabase() {
        // 1. Seed Categories
        val categories = listOf(
            GkCategory("raj_history", "राजस्थान का इतिहास", "राजवंश, एकीकरण, 1857 की क्रांति, प्रमुख व्यक्तित्व", "RAJASTHAN", "History"),
            GkCategory("raj_geography", "राजस्थान का भूगोल", "अरावली, नदियाँ, झीलें, जलवायु, वन्यजीव", "RAJASTHAN", "Terrain"),
            GkCategory("raj_polity", "राजस्थान की राजव्यवस्था", "राज्यपाल, मुख्यमंत्री, विधानसभा, उच्च न्यायालय", "RAJASTHAN", "Gavel"),
            GkCategory("raj_culture", "कला और संस्कृति", "लोक नृत्य, लोक देवियाँ, मेले, त्योहार, दुर्ग, चित्रकला", "RAJASTHAN", "Palette"),
            GkCategory("raj_economy", "राजस्थान की अर्थव्यवस्था", "बजट 2026, आर्थिक समीक्षा, प्रमुख योजनाएं, कृषि", "RAJASTHAN", "TrendingUp"),
            
            GkCategory("ind_history", "भारत का इतिहास", "सिंधु घाटी, मौर्य काल, गुप्त काल, स्वतंत्रता संग्राम", "INDIA", "HistoryEdu"),
            GkCategory("ind_geography", "भारत का भूगोल", "हिमालय, नदियाँ, मानसून, मिट्टी, राष्ट्रीय उद्यान", "INDIA", "Explore"),
            GkCategory("ind_polity", "भारतीय संविधान और राजव्यवस्था", "प्रस्तावना, मौलिक अधिकार, राष्ट्रपति, संसद", "INDIA", "Policy"),
            GkCategory("ind_science", "सामान्य विज्ञान", "भौतिक, रसायन, जीव विज्ञान, तकनीकी", "INDIA", "Science"),
            GkCategory("ind_economy", "भारतीय अर्थव्यवस्था", "जीडीपी, आरबीआई, बैंकिंग, पंचवर्षीय योजनाएं", "INDIA", "CurrencyRupee")
        )
        gkDao.insertCategories(categories)

        // 2. Seed Questions
        val questions = listOf(
            // Rajasthan History Questions
            GkQuestion(
                categoryId = "raj_history",
                questionText = "राजस्थान का एकीकरण कितने चरणों में संपन्न हुआ था?",
                optionA = "5 चरणों में",
                optionB = "6 चरणों में",
                optionC = "7 चरणों में",
                optionD = "8 चरणों में",
                correctOption = "C",
                explanation = "राजस्थान का एकीकरण कुल 7 चरणों में संपन्न हुआ। यह प्रक्रिया 18 मार्च 1948 से प्रारंभ होकर 1 नवंबर 1956 को पूर्ण हुई।"
            ),
            GkQuestion(
                categoryId = "raj_history",
                questionText = "प्रसिद्ध खानवा का युद्ध (1527 ई.) किस-किस के बीच लड़ा गया था?",
                optionA = "राणा सांगा और बाबर",
                optionB = "महाराणा प्रताप और अकबर",
                optionC = "राणा कुम्भा और खिलजी",
                optionD = "पृथ्वीराज चौहान और गोरी",
                correctOption = "A",
                explanation = "खानवा का युद्ध 17 मार्च 1527 को मुगल शासक बाबर और मेवाड़ के महाराणा सांगा के मध्य लड़ा गया था, जिसमें बाबर की विजय हुई।"
            ),
            GkQuestion(
                categoryId = "raj_history",
                questionText = "राजस्थान में 1857 की क्रांति का प्रारंभ सर्वप्रथम कहाँ से हुआ था?",
                optionA = "नीमच",
                optionB = "एरिनपुरा",
                optionC = "नसीराबाद",
                optionD = "देवली",
                correctOption = "C",
                explanation = "राजस्थान में 1857 की क्रांति की शुरुआत 28 मई 1857 को नसीराबाद छावनी (अजमेर) से 15वीं बंगाल नेटिव इन्फैंट्री द्वारा की गई थी।"
            ),

            // Rajasthan Geography Questions
            GkQuestion(
                categoryId = "raj_geography",
                questionText = "अरावली पर्वत श्रृंखला की राजस्थान में कुल लंबाई कितनी है?",
                optionA = "692 किमी",
                optionB = "550 किमी",
                optionC = "500 किमी",
                optionD = "450 किमी",
                correctOption = "B",
                explanation = "अरावली पर्वतमाला की कुल लंबाई 692 किमी है, जिसमें से लगभग 550 किमी (80%) हिस्सा राजस्थान में विस्तृत है।"
            ),
            GkQuestion(
                categoryId = "raj_geography",
                questionText = "राजस्थान की सबसे ऊँची चोटी 'गुरुशिखर' किस जिले में स्थित है?",
                optionA = "उदयपुर",
                optionB = "सिरोही",
                optionC = "राजसमंद",
                optionD = "जयपुर",
                correctOption = "B",
                explanation = "गुरुशिखर सिरोही जिले में माउंट आबू क्षेत्र में स्थित है। इसकी ऊंचाई 1722 मीटर है और इसे कर्नल जेम्स टॉड ने 'संतों का शिखर' कहा था।"
            ),
            GkQuestion(
                categoryId = "raj_geography",
                questionText = "निम्नलिखित में से कौन सी नदी पूर्णतः राजस्थान में बहने वाली सबसे लंबी नदी है?",
                optionA = "चम्बल",
                optionB = "बनास",
                optionC = "लूनी",
                optionD = "माही",
                correctOption = "B",
                explanation = "बनास नदी पूर्णतः राजस्थान में बहने वाली सबसे लंबी नदी है। इसका उद्गम राजसमंद जिले की खमनोर पहाड़ियों से होता है।"
            ),

            // Rajasthan Culture Questions
            GkQuestion(
                categoryId = "raj_culture",
                questionText = "राजस्थान का राज्य नृत्य कौन सा है, जिसे 'नृत्यों का सिरमौर' भी कहा जाता है?",
                optionA = "कालबेलिया",
                optionB = "गैर नृत्य",
                optionC = "घूमर",
                optionD = "कच्छी घोड़ी",
                correctOption = "C",
                explanation = "घूमर राजस्थान का पारंपरिक राज्य लोक नृत्य है। यह मांगलिक अवसरों पर महिलाओं द्वारा किया जाता है और इसे राज्य नृत्य का गौरव प्राप्त है।"
            ),
            GkQuestion(
                categoryId = "raj_culture",
                questionText = "यूनेस्को (UNESCO) की विश्व धरोहर सूची में शामिल 'जंतर-मंतर' वेधशाला कहाँ स्थित है?",
                optionA = "जोधपुर",
                optionB = "जयपुर",
                optionC = "उदयपुर",
                optionD = "बीकानेर",
                correctOption = "B",
                explanation = "जयपुर स्थित जंतर-मंतर का निर्माण सवाई जयसिंह द्वितीय ने करवाया था। इसे 2010 में यूनेस्को की विश्व धरोहर सूची में शामिल किया गया था।"
            ),

            // India History Questions
            GkQuestion(
                categoryId = "ind_history",
                questionText = "सिंधु घाटी सभ्यता का प्रसिद्ध स्थल 'कालीबंगा' भारत के किस राज्य में स्थित है?",
                optionA = "गुजरात",
                optionB = "पंजाब",
                optionC = "हरियाणा",
                optionD = "राजस्थान",
                correctOption = "D",
                explanation = "कालीबंगा राजस्थान के हनुमानगढ़ जिले में घग्गर नदी के किनारे स्थित है। इसकी खोज 1952 में अमलानंद घोष ने की थी।"
            ),
            GkQuestion(
                categoryId = "ind_history",
                questionText = "महात्मा गांधी ने असहयोग आंदोलन (Non-Cooperation Movement) किस वर्ष प्रारंभ किया था?",
                optionA = "1915",
                optionB = "1920",
                optionC = "1930",
                optionD = "1942",
                correctOption = "B",
                explanation = "महात्मा गांधी ने 1920 में असहयोग आंदोलन शुरू किया था। वर्ष 1922 में चौरी-चौरा कांड के बाद इस आंदोलन को वापस ले लिया गया था।"
            ),

            // India Polity Questions
            GkQuestion(
                categoryId = "ind_polity",
                questionText = "भारतीय संविधान के किस अनुच्छेद को डॉ. अम्बेडकर ने 'संविधान की आत्मा और हृदय' कहा था?",
                optionA = "अनुच्छेद 19",
                optionB = "अनुच्छेद 21",
                optionC = "अनुच्छेद 32",
                optionD = "अनुच्छेद 45",
                correctOption = "C",
                explanation = "अनुच्छेद 32 संवैधानिक उपचारों के अधिकार से संबंधित है। डॉ. बी.आर. अम्बेडकर ने इसे संविधान का सबसे महत्वपूर्ण अनुच्छेद और इसकी आत्मा माना था।"
            ),
            GkQuestion(
                categoryId = "ind_polity",
                questionText = "लोकसभा का सदस्य बनने के लिए न्यूनतम आयु सीमा कितनी होनी चाहिए?",
                optionA = "18 वर्ष",
                optionB = "21 वर्ष",
                optionC = "25 वर्ष",
                optionD = "30 वर्ष",
                correctOption = "C",
                explanation = "लोकसभा चुनाव लड़ने या सदस्य बनने के लिए न्यूनतम आयु 25 वर्ष आवश्यक है, जबकि राज्यसभा के लिए न्यूनतम आयु 30 वर्ष निर्धारित है।"
            ),
            // True / False Question
            GkQuestion(
                categoryId = "raj_history",
                questionText = "क्या वीर शिरोमणि महाराणा प्रताप का जन्म कुम्भलगढ़ दुर्ग (कटारगढ़) में हुआ था?",
                optionA = "सत्य (True)",
                optionB = "असत्य (False)",
                optionC = "जानकारी उपलब्ध नहीं",
                optionD = "विवादास्पद",
                correctOption = "A",
                explanation = "सत्य! महाराणा प्रताप का जन्म 9 मई 1540 को कुम्भलगढ़ के कटारगढ़ दुर्ग के बादल महल में हुआ था। उनके पिता का नाम महाराणा उदयसिंह और माता का नाम जयवंता बाई था।",
                questionType = "TF",
                reference = "मेवाड़ राजघराने का इतिहास - आर.बी.एस.ई"
            ),
            // Match the Following Question
            GkQuestion(
                categoryId = "raj_culture",
                questionText = "निम्नलिखित ऐतिहासिक स्मारकों का उनके सही संबंधित जिलों के साथ मिलान कीजिए:",
                optionA = "1-A, 2-B, 3-C",
                optionB = "1-B, 2-A, 3-C",
                optionC = "1-C, 2-B, 3-A",
                optionD = "1-A, 2-C, 3-B",
                correctOption = "A",
                explanation = "हवा महल जयपुर में स्थित है (सवाई प्रताप सिंह द्वारा 1799 में निर्मित), मेहरानगढ़ किला जोधपुर में चिड़ियाटूंख पहाड़ी पर स्थित है, तथा विजय स्तंभ चित्तौड़गढ़ दुर्ग में स्थित है।",
                questionType = "MATCH",
                matchPairsLeft = "1. हवा महल\n2. मेहरानगढ़ दुर्ग\n3. विजय स्तंभ (चित्तौड़गढ़)",
                matchPairsRight = "A. जयपुर जिला\nB. जोधपुर जिला\nC. चित्तौड़गढ़ जिला",
                reference = "राजस्थान पर्यटन विभाग हैंडबुक"
            ),
            // Image Based Question
            GkQuestion(
                categoryId = "raj_geography",
                questionText = "नीचे दिए गए चित्र में प्रदर्शित अरावली श्रृंखला की सर्वोच्च चोटी 'गुरुशिखर' के विषय में कौन सा कथन सत्य है?",
                optionA = "यह सिरोही जिले में स्थित है और इसकी ऊंचाई 1722 मीटर है।",
                optionB = "यह जयपुर जिले में स्थित सबसे लंबी चोटी है।",
                optionC = "यह थार मरुस्थल की एकमात्र पर्वत चोटी है।",
                optionD = "इस चोटी पर राणा सांगा का स्मारक बना हुआ है।",
                correctOption = "A",
                explanation = "गुरुशिखर राजस्थान की अरावली पर्वतमाला की सर्वोच्च चोटी है। यह सिरोही जिले में स्थित है, और इसकी ऊंचाई 1722 मीटर (अथवा मंदिर के ध्वज सहित 1727 मीटर) है।",
                questionType = "IMAGE",
                imageUrl = "ic_mountain",
                reference = "राजस्थान भूगोल - हरिमोहन सक्सेना"
            )
        )
        gkDao.insertQuestions(questions)

        // 3. Seed Study Notes
        val notes = listOf(
            StudyNote(
                id = "n_raj_his_1",
                categoryId = "raj_history",
                title = "राजस्थान का एकीकरण (चरण-वार संक्षिप्त विवरण)",
                content = "राजस्थान का एकीकरण कुल 7 चरणों में संपन्न हुआ:\n\n1. मत्स्य संघ (18 मार्च 1948): अलवर, भरतपुर, धौलपुर, करौली रियासतें मिलीं। राजधानी अलवर बनी। उदयभान सिंह राजप्रमुख बने।\n2. पूर्व राजस्थान (25 मार्च 1948): कोटा, बूंदी, झालावाड़, टोंक, डूंगरपुर, बांसवाड़ा, प्रतापगढ़, शाहपुरा, किशनगढ़ मिले।\n3. संयुक्त राजस्थान (18 अप्रैल 1948): उदयपुर रियासत पूर्व राजस्थान में मिली।\n4. वृहद राजस्थान (30 मार्च 1949): जयपुर, जोधपुर, जैसलमेर, बीकानेर का विलय हुआ। 30 मार्च को 'राजस्थान दिवस' के रूप में मनाया जाता है।\n5. संयुक्त वृहद राजस्थान (15 मई 1949): मत्स्य संघ का वृहद राजस्थान में विलय हुआ।\n6. राजस्थान संघ (26 जनवरी 1950): सिरोही (आबू-दिलवाड़ा छोड़कर) का विलय।\n7. पुनर्गठित राजस्थान (1 नवंबर 1956): आबू-दिलवाड़ा, अजमेर-मेरवाड़ा और सुनेल टप्पा का विलय हुआ। राजस्थान का वर्तमान स्वरूप अस्तित्व में आया।",
                pdfName = "Rajasthan_EkiKaran_Complete_Notes.pdf",
                fileSize = "1.8 MB"
            ),
            StudyNote(
                id = "n_raj_geo_1",
                categoryId = "raj_geography",
                title = "राजस्थान की भौतिक संरचना और अरावली श्रेणी",
                content = "राजस्थान को मुख्य रूप से चार भौतिक विभागों में बांटा जाता है:\n1. पश्चिमी मरुस्थलीय प्रदेश (61.11% क्षेत्रफल, 40% जनसंख्या)\n2. अरावली पर्वतीय प्रदेश (9% क्षेत्रफल, 10% जनसंख्या)\n3. पूर्वी मैदानी भाग (23% क्षेत्रफल, 39% जनसंख्या)\n4. दक्षिणी-पूर्वी पठारी भाग या हाड़ौती का पठार (6.89% क्षेत्रफल)\n\nअरावली पर्वतमाला:\n- यह विश्व की प्राचीनतम वलित पर्वत श्रृंखला है जो प्री-कैम्ब्रियन काल की है।\n- इसका विस्तार गुजरात के पालनपुर से दिल्ली की रायसीना पहाड़ियों तक 692 किमी है।\n- राजस्थान में सिरोही से झुंझुनू तक 550 किमी है।\n- प्रमुख चोटियाँ: गुरुशिखर (1722 मीटर, सिरोही), सेर (1597 मीटर, सिरोही), दिलवाड़ा (1442 मीटर, सिरोही), जरगा (1431 मीटर, उदयपुर), अचलगढ़ (1380 मीटर, सिरोही)।",
                pdfName = "Aravalli_And_Physical_Divisions.pdf",
                fileSize = "2.4 MB"
            ),
            StudyNote(
                id = "n_ind_pol_1",
                categoryId = "ind_polity",
                title = "भारतीय संविधान की प्रस्तावना और मुख्य विशेषताएं",
                content = "भारतीय संविधान विश्व का सबसे बड़ा लिखित और व्यापक संविधान है।\n\nप्रस्तावना (Preamble):\n- प्रस्तावना को 'संविधान की कुंजी' या 'संविधान का परिचय पत्र' कहा जाता है।\n- इसमें प्रयुक्त शब्द 'हम भारत के लोग' यह दर्शाता है कि संप्रभुता भारतीय जनता में निहित है।\n- 42वें संविधान संशोधन (1976) द्वारा प्रस्तावना में तीन नए शब्द जोड़े गए: समाजवादी (Socialist), धर्मनिरपेक्ष/पंथनिरपेक्ष (Secular) और अखंडता (Integrity)।\n\nसंविधान के मुख्य स्रोत:\n- मौलिक अधिकार: अमेरिका का संविधान\n- नीति निदेशक तत्व (DPSP): आयरलैंड का संविधान\n- संसदीय प्रणाली: ब्रिटेन का संविधान\n- आपातकालीन उपबंध: जर्मनी का वाइमर संविधान\n- संविधान संशोधन: दक्षिण अफ्रीका",
                pdfName = "Indian_Polity_Preamble_Sources.pdf",
                fileSize = "1.2 MB"
            )
        )
        gkDao.insertNotes(notes)

        // 4. Seed Current Affairs
        val affairs = listOf(
            CurrentAffair(
                title = "राजस्थान बजट 2026 की प्रमुख घोषणाएं",
                description = "युवाओं, किसानों और महिलाओं के लिए विशेष राहत और कल्याणकारी योजनाएं की गईं लागू।",
                content = "राजस्थान सरकार द्वारा वर्ष 2026-27 के लिए पेश बजट में निम्नलिखित महत्वपूर्ण घोषणाएं की गई हैं:\n\n1. भर्ती परीक्षा सुधार: राज्य में आगामी वर्ष में 1 लाख नई सरकारी नौकरियों की घोषणा की गई है।\n2. किसान ऋण माफी: लघु एवं सीमांत किसानों के लिए कृषि ऋण राहत योजना के तहत सहकारी बैंकों के ऋणों के लिए विशेष सब्सिडी घोषित की गई।\n3. लाडो प्रोत्साहन योजना: गरीब परिवारों में बेटी के जन्म पर 2 लाख रुपये का सेविंग बॉन्ड प्रदान किया जाएगा।\n4. सोलर रूफटॉप योजना: घरेलू उपभोक्ताओं के लिए बिजली बिल शून्य करने के उद्देश्य से सोलर पैनल लगाने हेतु 80% तक की भारी सब्सिडी दी जाएगी।\n5. मुख्यमंत्री आयुष स्वास्थ्य बीमा: बीमा कवरेज सीमा को बढ़ाकर प्रति परिवार 30 लाख रुपये प्रति वर्ष कर दिया गया है।",
                date = "27 June 2026",
                isMonthly = false
            ),
            CurrentAffair(
                title = "राजस्थान के नए मुख्य सचिव की नियुक्ति",
                description = "वरिष्ठ आईएएस अधिकारी ने ग्रहण किया राज्य के मुख्य प्रशासनिक अधिकारी का पदभार।",
                content = "वरिष्ठ भारतीय प्रशासनिक सेवा (IAS) अधिकारी को राजस्थान का नया मुख्य सचिव नियुक्त किया गया है। वे राज्य के प्रशासनिक ढांचे में सर्वोच्च स्थान पर रहकर नीति कार्यान्वयन की निगरानी करेंगे। उनकी प्राथमिकताएं सरकारी योजनाओं का पारदर्शी क्रियान्वयन, जनसुनवाई तंत्र को मजबूत करना और पेपर लीक जैसी घटनाओं को रोकने के लिए परीक्षा प्रणालियों में सुरक्षा व्यवस्था बढ़ाना है।",
                date = "24 June 2026",
                isMonthly = false
            ),
            CurrentAffair(
                title = "जून 2026: मासिक राष्ट्रीय एवं अंतर्राष्ट्रीय सार संग्रह",
                description = "जून महीने की सभी महत्वपूर्ण राष्ट्रीय, अंतर्राष्ट्रीय घटनाएं और पुरस्कारों का संकलन।",
                content = "जून 2026 के प्रमुख करेंट अफेयर्स बिंदु:\n\n1. राष्ट्रीय सुरक्षा: भारत ने ओडिशा तट से अपनी नई पीढ़ी की बैलिस्टिक मिसाइल का सफल रात्रिकालीन परीक्षण किया।\n2. वैश्विक शिखर सम्मेलन: G7 देशों का वार्षिक शिखर सम्मेलन इटली में आयोजित हुआ, जिसमें जलवायु परिवर्तन, एआई नियमन और वैश्विक व्यापार संकट पर चर्चा हुई।\n3. खेल जगत: भारत ने अंतर्राष्ट्रीय तीरंदाजी चैंपियनशिप में 3 स्वर्ण पदक जीतकर अंक तालिका में शीर्ष स्थान प्राप्त किया।\n4. पर्यावरण दिवस: 5 जून को मनाए गए विश्व पर्यावरण दिवस 2026 की थीम 'भूमि जीर्णोद्धार, मरुस्थलीकरण और सूखे से मुकाबला' रही।",
                date = "June 2026",
                isMonthly = true
            )
        )
        gkDao.insertCurrentAffairs(affairs)

        // 5. Seed Previous Papers
        val papers = listOf(
            PreviousPaper("p_ras_2023", "RAS Pre-Exam General Studies", 2023, 150, "राजस्थान & भारत सामान्य ज्ञान"),
            PreviousPaper("p_reet_2022", "REET L-2 Social Studies Paper", 2022, 150, "सामाजिक अध्ययन & शिक्षाशास्त्र"),
            PreviousPaper("p_patwar_2021", "Patwar Combined Recruitment Paper", 2021, 150, "जीके, गणित, कंप्यूटर और हिंदी"),
            PreviousPaper("p_cet_2024", "CET Graduate Level Exam Paper", 2024, 150, "राजस्थान इतिहास, भूगोल, राजव्यवस्था")
        )
        gkDao.insertPreviousPapers(papers)

        // 6. Seed Leaderboard Entries
        val leaderboardEntries = listOf(
            LeaderboardEntry("u_1", "सुरेश कुमार मीणा", 4850, 1, "avatar_male_1", "जयपुर"),
            LeaderboardEntry("u_2", "प्रियंका विश्नोई", 4720, 2, "avatar_female_1", "जोधपुर"),
            LeaderboardEntry("u_3", "दिनेश गुर्जर", 4590, 3, "avatar_male_2", "भरतपुर"),
            LeaderboardEntry("u_4", "अंजू चौधरी", 4480, 4, "avatar_female_2", "सीकर"),
            LeaderboardEntry("u_5", "राकेश शर्मा", 4320, 5, "avatar_male_3", "कोटा"),
            LeaderboardEntry("u_6", "महेन्द्र सिंह", 4210, 6, "avatar_male_4", "अजमेर"),
            LeaderboardEntry("u_7", "सोनू सिंह", 4150, 7, "avatar_female_3", "बीकानेर")
        )
        gkDao.insertLeaderboard(leaderboardEntries)
    }

    // Admin CRUD Methods
    fun getAllQuestionsFlow(): Flow<List<GkQuestion>> = gkDao.getAllQuestions()

    suspend fun insertQuestion(question: GkQuestion) = gkDao.insertQuestion(question)

    suspend fun deleteQuestion(id: Int) = gkDao.deleteQuestionById(id)

    suspend fun insertCategory(category: GkCategory) = gkDao.insertCategory(category)

    suspend fun deleteCategory(id: String) = gkDao.deleteCategoryById(id)

    suspend fun insertNote(note: StudyNote) = gkDao.insertNote(note)

    suspend fun deleteNote(id: String) = gkDao.deleteNoteById(id)

    suspend fun insertCurrentAffair(affair: CurrentAffair) = gkDao.insertCurrentAffair(affair)

    suspend fun deleteCurrentAffair(id: Int) = gkDao.deleteCurrentAffairById(id)

    suspend fun clearLeaderboard() = gkDao.clearLeaderboard()

    suspend fun insertLeaderboard(entries: List<LeaderboardEntry>) = gkDao.insertLeaderboard(entries)
}
