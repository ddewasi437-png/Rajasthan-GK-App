package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.AmberGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumRewardScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTab by remember { mutableStateOf("PREMIUM") } // PREMIUM, REWARDS, AD_CENTER

    // Simulated Billing states
    var showPurchaseDialog by remember { mutableStateOf<Pair<String, Double>?>(null) } // Plan Name, Price
    var showSuccessDialog by remember { mutableStateOf<String?>(null) } // Success Message
    var referralInput by remember { mutableStateOf("") }

    // Spin Wheel states
    var isSpinning by remember { mutableStateOf(false) }
    var spinAngle by remember { mutableStateOf(0f) }
    var spinResultMsg by remember { mutableStateOf<String?>(null) }

    // Analytics counters for revenue
    var adImpressions by remember { mutableStateOf(142) }
    var adClicks by remember { mutableStateOf(18) }
    var adRevenue by remember { mutableStateOf(2.84) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            MainAppHeader(
                title = "राजस्व & इनाम केंद्र 💎",
                subtitle = "Premium Plan, Daily Reward & Spin Wheel",
                onBackClick = { onNavigate("home") }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Live Balanced header (Coins, XP, Status)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Saffron.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🪙 ${viewModel.userCoins}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = AmberGold
                                )
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "⭐ ${viewModel.userXP} XP",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = RoyalBlue
                                )
                            )
                        }
                        Text(
                            text = "डेली स्ट्रीक: 🔥 ${viewModel.userStreak} दिन लगातार",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // Membership status badge
                    if (viewModel.isPremiumUser) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.horizontalGradient(listOf(Saffron, AmberGold)))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.WorkspacePremium,
                                    contentDescription = "Premium Badge",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "प्रीमियम सदस्य",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { selectedTab = "PREMIUM" },
                            border = BorderStroke(1.5.dp, Saffron),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Saffron),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("फ्री प्लान (अपग्रेड करें)", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            // Tab Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { selectedTab = "PREMIUM" },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_premium"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == "PREMIUM") Saffron else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "प्रीमियम सदस्यता",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == "PREMIUM") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { selectedTab = "REWARDS" },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_rewards"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == "REWARDS") Saffron else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "डेली इनाम & स्पिन",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == "REWARDS") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { selectedTab = "AD_CENTER" },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_ad_center"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == "AD_CENTER") Saffron else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "AdMob सिम्युलेटर",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedTab == "AD_CENTER") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // RENDER AD BANNER PLACEHOLDER IF USER IS NOT PREMIUM
                if (!viewModel.isPremiumUser && viewModel.adsEnabled) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color.Gray.copy(alpha = 0.5f))
                                .clickable {
                                    adClicks += 1
                                    adRevenue += 0.12
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Ad Clicked! +$0.12 Simulated Revenue Generated.")
                                    }
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color.Yellow)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("Ad", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "REAK REET/RAS EXAM WITH PREMIUM NOTES",
                                        fontSize = 10.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text("Google AdMob Adaptive Banner — Click to simulate user interaction", fontSize = 8.sp, color = Color.LightGray)
                            }
                        }
                    }
                }

                when (selectedTab) {
                    "PREMIUM" -> {
                        // Premium Benefits List
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                border = BorderStroke(1.5.dp, Saffron.copy(alpha = 0.8f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        text = "GK Master Premium सदस्यता के लाभ ✨",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Saffron
                                        )
                                    )

                                    val benefits = listOf(
                                        "विज्ञापन मुक्त अनुभव (No Banner/Popups Ads)" to "पढ़ाई में कोई रुकावट नहीं!",
                                        "प्रीमियम परीक्षा मॉक टेस्ट सीरीज" to "नवीनतम प्रश्नों की लाइव एक्सेस",
                                        "प्रीमियम स्टडी PDF और नोट्स" to "ऑफलाइन सेव व अनलिमिटेड डाउनलोड",
                                        "विस्तृत विश्लेषण (Advanced Statistics)" to "अपनी कमजोरियों को जानें",
                                        "विशेष दैनिक करंट अफेयर्स कैप्सूल" to "परीक्षा में सफलता सुनिश्चित करें",
                                        "प्रोफाइल पर चमकदार गोल्डन प्रीमियम बैच" to "लीडरबोर्ड में अलग चमकें"
                                    )

                                    benefits.forEach { (title, subtitle) ->
                                        Row(
                                            verticalAlignment = Alignment.Top,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("✅", fontSize = 14.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(subtitle, fontSize = 11.sp, color = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Premium Plans
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    "एक प्लान चुनें और तुरंत शुरू करें:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black)
                                )

                                val plans = listOf(
                                    Triple("1 महीना (Monthly Basic)", 149.00, "₹149/महीना"),
                                    Triple("3 महीने (Quarterly Value)", 349.00, "₹116/महीना (बचत 22%)"),
                                    Triple("12 महीने (Yearly Super Saver)", 799.00, "₹66/महीना (बचत 55%)"),
                                    Triple("आजीवन प्लान (Lifetime Platinum)", 1499.00, "एक बार भुगतान, आजीवन एक्सेस")
                                )

                                plans.forEach { (name, price, desc) ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { showPurchaseDialog = Pair(name, price) },
                                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(name, fontWeight = FontWeight.Black, fontSize = 14.sp)
                                                Text(desc, fontSize = 11.sp, color = Saffron, fontWeight = FontWeight.Bold)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("₹$price", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, fontSize = 15.sp)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Icon(Icons.Default.ArrowForwardIos, contentDescription = "Buy", modifier = Modifier.size(12.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Add coins pack shop
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    "कॉइंस पैक दुकान (Simulated Coin Store):",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black)
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { showPurchaseDialog = Pair("1000 Coins Pack", 49.00) },
                                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f))
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .padding(12.dp)
                                                .fillMaxWidth(),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("🪙", fontSize = 28.sp)
                                            Text("1,000 कॉइंस", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("₹49.00", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                        }
                                    }

                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { showPurchaseDialog = Pair("5000 Coins Pack", 199.00) },
                                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f))
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .padding(12.dp)
                                                .fillMaxWidth(),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("🪙🪙", fontSize = 28.sp)
                                            Text("5,000 कॉइंस", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("₹199.00", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "REWARDS" -> {
                        // 7-Day Rewards List
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "7-Day Daily Claim Streak 🗓️",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black)
                                        )
                                        if (viewModel.hasCollectedDailyRewardToday) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(Color.Gray.copy(alpha = 0.2f))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("आज पूरा हुआ", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    // 7 Day visual progress
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        (1..7).forEach { day ->
                                            val isClaimed = day < viewModel.currentDailyDay || (day == viewModel.currentDailyDay && viewModel.hasCollectedDailyRewardToday)
                                            val isCurrent = day == viewModel.currentDailyDay && !viewModel.hasCollectedDailyRewardToday

                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            when {
                                                                isClaimed -> Saffron
                                                                isCurrent -> AmberGold.copy(alpha = 0.2f)
                                                                else -> Color.LightGray.copy(alpha = 0.2f)
                                                            }
                                                        )
                                                        .border(
                                                            width = 1.5.dp,
                                                            color = if (isCurrent) Saffron else Color.Transparent,
                                                            shape = CircleShape
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (isClaimed) {
                                                        Icon(Icons.Default.Check, contentDescription = "Claimed", tint = Color.White, modifier = Modifier.size(16.dp))
                                                    } else {
                                                        Text("$day", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                Text(
                                                    text = when (day) {
                                                        1 -> "+50🪙"
                                                        2 -> "+100⭐"
                                                        3 -> "+100🪙"
                                                        4 -> "+150🪙"
                                                        5 -> "+200⭐"
                                                        6 -> "+200🪙"
                                                        else -> "메가🎁"
                                                    },
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            val msg = viewModel.collectDailyReward()
                                            scope.launch {
                                                snackbarHostState.showSnackbar(msg)
                                            }
                                        },
                                        enabled = !viewModel.hasCollectedDailyRewardToday,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("claim_daily_reward_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                                    ) {
                                        Text(
                                            text = if (viewModel.hasCollectedDailyRewardToday) "कल वापस आएं!" else "आज का इनाम कलेक्ट करें (+🪙/⭐)",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Daily Spin Wheel Screen integration
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        "लकी स्पिन व्हील 🎡 (Daily Spin Wheel)",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black)
                                    )

                                    Text(
                                        "हर स्पिन पर सुनिश्चित उपहार पाएं! कॉइंस, एक्सपी और प्रीमियम ट्रायल जीतें।",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )

                                    // Gorgeous Drawn Spin Wheel with pointer
                                    Box(
                                        modifier = Modifier
                                            .size(200.dp)
                                            .padding(8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        // The animated rotating canvas
                                        val angleAnimation by animateFloatAsState(
                                            targetValue = spinAngle,
                                            animationSpec = if (isSpinning) {
                                                tween(durationMillis = 3000, easing = LinearOutSlowInEasing)
                                            } else {
                                                snap()
                                            },
                                            label = "WheelRotation"
                                        )

                                        Canvas(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .rotate(angleAnimation)
                                        ) {
                                            val center = Offset(size.width / 2, size.height / 2)
                                            val radius = size.width / 2
                                            val colors = listOf(
                                                Color(0xFFFFB300), Color(0xFFE53935),
                                                Color(0xFF1E88E5), Color(0xFF43A047),
                                                Color(0xFF8E24AA), Color(0xFFF4511E),
                                                Color(0xFF00ACC1), Color(0xFF3949AB)
                                            )

                                            for (i in 0 until 8) {
                                                drawArc(
                                                    color = colors[i],
                                                    startAngle = i * 45f,
                                                    sweepAngle = 45f,
                                                    useCenter = true,
                                                    size = Size(size.width, size.height)
                                                )
                                            }

                                            // Draw center golden hub
                                            drawCircle(
                                                color = Color(0xFFFCD34D),
                                                radius = 24.dp.toPx()
                                            )
                                            drawCircle(
                                                color = Color(0xFFB45309),
                                                radius = 24.dp.toPx(),
                                                style = Stroke(width = 2.dp.toPx())
                                            )
                                        }

                                        // Static Pointer at the top
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .align(Alignment.TopCenter)
                                                .offset(y = (-6).dp)
                                        ) {
                                            Text("▼", fontSize = 24.sp, color = Saffron, textAlign = TextAlign.Center)
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            if (!isSpinning) {
                                                isSpinning = true
                                                val targetSpin = spinAngle + 1440f + (0..359).random().toFloat()
                                                spinAngle = targetSpin
                                                scope.launch {
                                                    delay(3000) // Match the 3 second rotation animation duration
                                                    isSpinning = false
                                                    val (resMsg, idx) = viewModel.spinWheel()
                                                    spinResultMsg = resMsg
                                                }
                                            }
                                        },
                                        enabled = !isSpinning && !viewModel.hasSpunWheelToday,
                                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("spin_now_button")
                                    ) {
                                        Text(
                                            text = when {
                                                isSpinning -> "स्पिन घूम रहा है..."
                                                viewModel.hasSpunWheelToday -> "आज का स्पिन पूरा हुआ!"
                                                else -> "स्पिन करें (Spin Now) 🎡"
                                            },
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                }
                            }
                        }

                        // Referral system
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        "दोस्तों को रेफर करें (Referral System) 👥",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black)
                                    )

                                    Text(
                                        "आपके रेफरल कोड से जुड़ने पर आपको और आपके दोस्त दोनों को 250 Coins + 100 XP मिलेंगे!",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )

                                    // Show user code
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "आपका रेफरल कोड: ${viewModel.userReferralCode}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 13.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("GK Master Promo", viewModel.userReferralCode)
                                                clipboard.setPrimaryClip(clip)
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("रेफरल कोड क्लिपबोर्ड पर कॉपी किया गया!")
                                                }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Input code
                                    OutlinedTextField(
                                        value = referralInput,
                                        onValueChange = { referralInput = it },
                                        label = { Text("दोस्त का रेफरल कोड डालें (Referral Code)") },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodyMedium
                                    )

                                    Button(
                                        onClick = {
                                            val success = viewModel.submitReferral(referralInput)
                                            if (success) {
                                                referralInput = ""
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("रेफरल कोड सफलतापूर्वक लागू हुआ! +250 कॉइंस और +100 XP मिले! 🎉")
                                                }
                                            } else {
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("अवैध रेफरल कोड! कृपया सही कोड जांचें।")
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Text("सबमिट रेफरल कोड", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    "AD_CENTER" -> {
                        // AdMob Simulator Center
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        "AdMob Live Ads Simulator 🖥️",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Saffron
                                        )
                                    )

                                    Text(
                                        "यहाँ आप लाइव AdMob एड्स की लोडिंग और क्लिक्स का लाइव अनुकरण देख सकते हैं।",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )

                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                                    // Display live analytics counters
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("Impressions", fontSize = 11.sp, color = Color.Gray)
                                            Text("$adImpressions", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("Ad Clicks", fontSize = 11.sp, color = Color.Gray)
                                            Text("$adClicks", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Saffron)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("Est. Revenue", fontSize = 11.sp, color = Color.Gray)
                                            Text("$${String.format("%.2f", adRevenue)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF2E7D32))
                                        }
                                    }

                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                                    Text("Simulate Live Popups:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                    // Click action triggers
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                adImpressions += 1
                                                adRevenue += 0.05
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("सिम्युलेटेड इंटरस्टिशियल विज्ञापन लोड किया गया! (Interstitial Loaded)")
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Interstitial Ad", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                adImpressions += 1
                                                adRevenue += 0.25
                                                viewModel.addCoins(100)
                                                viewModel.addXP(50)
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("बधाई हो! आपने पूरा रिवॉर्डेड वीडियो देखा। +100 Coins और +50 XP मिले! 🎁")
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Rewarded Ad (+🪙)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                adImpressions += 1
                                                adRevenue += 0.08
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("सिम्युलेटेड ऐप ओपन विज्ञापन (App Open Ad) लोड हुआ!")
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("App Open Ad", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                adImpressions += 1
                                                adRevenue += 0.15
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("सिम्युलेटेड नेटिव इनलाइन विज्ञापन (Native inline Ad) प्रदर्शित!")
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Native Ad", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Interactive simulated billing modal
    showPurchaseDialog?.let { (planName, price) ->
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = null },
            icon = { Icon(Icons.Default.Payment, contentDescription = "Google Play", tint = Saffron) },
            title = { Text("Google Play Billing", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "क्या आप भुगतान की पुष्टि करना चाहते हैं?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text("उत्पाद: $planName", fontSize = 12.sp)
                    Text("कुल राशि: ₹$price", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "यह एक अत्यंत सुरक्षित और रीयल-टाइम सिम्युलेटेड सैंडबॉक्स वातावरण है जो Google Play नीतियों का पूर्ण पालन करता है।",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPurchaseDialog = null
                        if (planName.contains("Coins")) {
                            val coinsToAdd = if (planName.contains("5000")) 5000 else 1000
                            viewModel.addCoins(coinsToAdd)
                            showSuccessDialog = "$coinsToAdd कॉइंस आपके खाते में सफलतापूर्वक जोड़ दिए गए हैं! 🪙"
                        } else {
                            viewModel.setPremiumStatus(true)
                            viewModel.addCoins(500)
                            viewModel.addXP(200)
                            showSuccessDialog = "आपकी प्रीमियम सदस्यता (Premium Plan) सफलतापूर्वक सक्रिय हो गई है! गोल्डन बैच और असीमित स्टडी नोट्स अनलॉक हो गए हैं। 💎🎉"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("भुगतान करें (Simulate Pay)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPurchaseDialog = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Success Alerts
    showSuccessDialog?.let { message ->
        AlertDialog(
            onDismissRequest = { showSuccessDialog = null },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color(0xFF2E7D32), modifier = Modifier.size(36.dp)) },
            title = { Text("भुगतान सफल! 🌟", fontWeight = FontWeight.Black, color = Color(0xFF2E7D32)) },
            text = {
                Text(
                    text = message,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = { showSuccessDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    Text("अद्भुत! (Awesome)")
                }
            }
        )
    }

    // Spin result dialog
    spinResultMsg?.let { msg ->
        AlertDialog(
            onDismissRequest = { spinResultMsg = null },
            icon = { Text("🎁", fontSize = 36.sp) },
            title = { Text("बधाई हो! 🎉", fontWeight = FontWeight.Black) },
            text = {
                Text(
                    text = msg,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = { spinResultMsg = null },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                ) {
                    Text("ठीक है (OK)", color = Color.Black)
                }
            }
        )
    }
}
