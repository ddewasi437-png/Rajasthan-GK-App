package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.StudyNote
import com.example.ui.components.GradientButton
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun NotesScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val notesList by viewModel.allNotes.collectAsState()
    val activeCategory = viewModel.selectedCategory.value

    val filteredNotes = if (activeCategory != null) {
        notesList.filter { it.categoryId == activeCategory.id }
    } else {
        notesList
    }

    var selectedNoteForReading by remember { mutableStateOf<StudyNote?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (selectedNoteForReading != null) {
            // Study Notes PDF simulated reader
            StudyNotesReaderView(
                note = selectedNoteForReading!!,
                viewModel = viewModel,
                onClose = { selectedNoteForReading = null }
            )
        } else {
            // Main lists of notes
            val headerTitle = if (activeCategory != null) {
                "${activeCategory.title} नोट्स"
            } else {
                "अध्ययन नोट्स (Study Notes PDF)"
            }
            val headerSubtitle = if (activeCategory != null) {
                "सटीक और प्रामाणिक पाठ्य सामग्री"
            } else {
                "सभी प्रतियोगी परीक्षाओं हेतु ई-बुक्स और नोट्स"
            }

            MainAppHeader(
                title = headerTitle,
                subtitle = headerSubtitle,
                onBackClick = {
                    if (activeCategory != null) {
                        viewModel.selectedCategory.value = null
                    } else {
                        viewModel.activeTab = "home"
                    }
                }
            )

            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📭", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "इस श्रेणी में कोई नोट्स उपलब्ध नहीं हैं।",
                            style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredNotes) { note ->
                        NoteRow(
                            note = note,
                            onClick = { selectedNoteForReading = note },
                            onDownloadToggle = {
                                if (note.isDownloaded) {
                                    viewModel.simulateDeleteNote(note.id)
                                } else {
                                    viewModel.simulateDownloadNote(note.id)
                                }
                            }
                        )
                    }

                    // Simulated AdBanner on Notes/PDF Screen (Part 6)
                    item {
                        com.example.ui.components.SimulatedAdBanner(viewModel = viewModel, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun NoteRow(
    note: StudyNote,
    onClick: () -> Unit,
    onDownloadToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBox(
                icon = Icons.Default.MenuBook,
                contentDescription = note.title,
                backgroundColor = Saffron.copy(alpha = 0.12f),
                iconColor = Saffron,
                size = 46.dp
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "फाइल नाम: ${note.pdfName}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = note.fileSize,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (note.isDownloaded) Color(0xFF2E7D32).copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (note.isDownloaded) "ऑफलाइन उपलब्ध" else "डाउनलोड करें",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (note.isDownloaded) Color(0xFF2E7D32) else Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = onDownloadToggle) {
                Icon(
                    imageVector = if (note.isDownloaded) Icons.Default.DeleteOutline else Icons.Default.Download,
                    contentDescription = "Action",
                    tint = if (note.isDownloaded) Color.Red.copy(alpha = 0.7f) else Saffron
                )
            }
        }
    }
}

@Composable
fun StudyNotesReaderView(
    note: StudyNote,
    viewModel: GKViewModel,
    onClose: () -> Unit
) {
    var isDownloaded by remember { mutableStateOf(note.isDownloaded) }
    var downloadProgress by remember { mutableStateOf(0f) }
    var isDownloading by remember { mutableStateOf(false) }
    var readingModeDarkMode by remember { mutableStateOf(false) }
    var isBookmarked by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(note.id) {
        isBookmarked = viewModel.isBookmarked("n_${note.id}")
    }

    // Colors according to reading mode
    val readerBackground = if (readingModeDarkMode) Color(0xFF121212) else Color(0xFFFFFDF9)
    val readerTextColor = if (readingModeDarkMode) Color(0xFFECEFF4) else Color(0xFF2E2E2E)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(readerBackground)
    ) {
        // Reader Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (readingModeDarkMode) Color(0xFF1E1E1E) else Saffron.copy(alpha = 0.12f)
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(
                    Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = if (readingModeDarkMode) Color.White else Saffron
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = if (readingModeDarkMode) Color.White else Color.Black
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (isDownloaded) "PDF पाठक (ऑफलाइन)" else "क्लाउड पाठक",
                    fontSize = 11.sp,
                    color = if (readingModeDarkMode) Color.LightGray else Color.Gray,
                    fontWeight = FontWeight.Bold
                )
            }

            // Bookmark notes
            IconButton(
                onClick = {
                    isBookmarked = !isBookmarked
                    viewModel.toggleBookmark(
                        id = "n_${note.id}",
                        type = "NOTE",
                        title = note.title,
                        categoryId = note.categoryId,
                        contentJson = ""
                    )
                }
            ) {
                Icon(
                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = Saffron
                )
            }

            // Dark Mode toggle for reader
            IconButton(onClick = { readingModeDarkMode = !readingModeDarkMode }) {
                Icon(
                    imageVector = if (readingModeDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = "Reading Theme",
                    tint = if (readingModeDarkMode) Color.Yellow else Color.DarkGray
                )
            }
        }

        // Simulating Download Progress Bar
        AnimatedVisibility(visible = isDownloading) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Saffron.copy(alpha = 0.05f))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("PDF फ़ाइल डाउनलोड हो रही है...", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Saffron)
                    Text("${(downloadProgress * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Saffron)
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { downloadProgress },
                    modifier = Modifier.fillMaxWidth(),
                    color = Saffron,
                    trackColor = Saffron.copy(alpha = 0.2f)
                )
            }
        }

        // PDF Content Reader Pane
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = note.title,
                    fontSize = 22.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Black,
                    color = if (readingModeDarkMode) Saffron else Color(0xFF8D2B0D)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = Saffron.copy(alpha = 0.3f), thickness = 2.dp)
            }

            item {
                Text(
                    text = note.content,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Serif,
                    lineHeight = 28.sp,
                    color = readerTextColor,
                    fontWeight = FontWeight.Medium
                )
            }

            item {
                Spacer(modifier = Modifier.height(50.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(1.dp, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = if (readingModeDarkMode) Color(0xFF262626) else Saffron.copy(alpha = 0.06f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "📖 अध्याय पूर्ण हुआ",
                            fontWeight = FontWeight.Bold,
                            color = Saffron,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "बेहतर तैयारी के लिए इस अध्याय का टेस्ट दें।",
                            fontSize = 12.sp,
                            color = readerTextColor.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Bottom Action Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(8.dp),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (readingModeDarkMode) Color(0xFF1F1F1F) else Color.White
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDownloaded) {
                    Button(
                        onClick = {
                            isDownloading = true
                            downloadProgress = 0f
                            scope.launch {
                                while (downloadProgress < 1f) {
                                    delay(200)
                                    downloadProgress += 0.1f
                                }
                                isDownloading = false
                                isDownloaded = true
                                viewModel.simulateDownloadNote(note.id)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Download")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ऑफ़लाइन डाउनलोड करें (${note.fileSize})", fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            isDownloaded = false
                            viewModel.simulateDeleteNote(note.id)
                        },
                        border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                        modifier = Modifier.weight(0.4f)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("हटाएं", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { /* Share simulated PDF link */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(0.6f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("व्हाट्सएप शेयर", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
