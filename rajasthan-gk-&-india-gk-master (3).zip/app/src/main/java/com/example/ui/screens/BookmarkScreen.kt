package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.Bookmark
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun BookmarkScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val bookmarksList by viewModel.bookmarks.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = "बुकमार्क संकलन (Saved Bookmarks)",
            subtitle = "आपके द्वारा भविष्य के अभ्यास के लिए सहेजे गए प्रश्न और नोट्स",
            onBackClick = { viewModel.activeTab = "home" }
        )

        if (bookmarksList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔖", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "कोई बुकमार्क उपलब्ध नहीं है।",
                        style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        "अभ्यास के दौरान 🔖 आइकन दबाकर प्रश्न सहेजें।",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(bookmarksList) { bookmark ->
                    BookmarkRow(
                        bookmark = bookmark,
                        onDelete = {
                            viewModel.toggleBookmark(
                                id = bookmark.id,
                                type = bookmark.type,
                                title = bookmark.title,
                                categoryId = bookmark.categoryId,
                                contentJson = ""
                            )
                        },
                        onOpen = {
                            if (bookmark.type == "QUESTION") {
                                // Direct quiz or show question
                                viewModel.activeTab = "rajasthan"
                                onNavigate("rajasthan_gk")
                            } else if (bookmark.type == "NOTE") {
                                // Navigate to study notes
                                viewModel.activeTab = "pdf_notes"
                                onNavigate("pdf_notes")
                            } else {
                                viewModel.activeTab = "current_affairs"
                                onNavigate("current_affairs")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BookmarkRow(
    bookmark: Bookmark,
    onDelete: () -> Unit,
    onOpen: () -> Unit
) {
    val icon = if (bookmark.type == "QUESTION") Icons.Default.Quiz else Icons.Default.MenuBook
    val badgeText = if (bookmark.type == "QUESTION") "प्रश्नोत्तरी" else if (bookmark.type == "NOTE") "अध्ययन नोट्स" else "करंट अफेयर्स"
    val badgeColor = if (bookmark.type == "QUESTION") Saffron else Color(0xFF1E88E5)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(14.dp))
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBox(
                icon = icon,
                contentDescription = bookmark.title,
                backgroundColor = badgeColor.copy(alpha = 0.12f),
                iconColor = badgeColor,
                size = 44.dp
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(badgeColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = bookmark.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.BookmarkRemove,
                    contentDescription = "Remove Bookmark",
                    tint = Color.Red.copy(alpha = 0.6f)
                )
            }
        }
    }
}
