package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.GKRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GKViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GKRepository

    // State flows representing DB tables
    val rajasthanCategories: StateFlow<List<GkCategory>>
    val indiaCategories: StateFlow<List<GkCategory>>
    val bookmarks: StateFlow<List<Bookmark>>
    val userResults: StateFlow<List<UserResult>>
    val allNotes: StateFlow<List<StudyNote>>
    val currentAffairs: StateFlow<List<CurrentAffair>>
    val previousPapers: StateFlow<List<PreviousPaper>>
    val leaderboard: StateFlow<List<LeaderboardEntry>>
    val allQuestions: StateFlow<List<GkQuestion>>

    // User profile state and session managed via SharedPreferences
    private val prefs = application.getSharedPreferences("gk_master_prefs", android.content.Context.MODE_PRIVATE)

    var isLoggedIn by mutableStateOf(prefs.getBoolean("is_logged_in", false))
    var profileSetupCompleted by mutableStateOf(prefs.getBoolean("profile_setup_completed", false))
    var onboardingCompleted by mutableStateOf(prefs.getBoolean("onboarding_completed", false))

    fun completeOnboarding() {
        onboardingCompleted = true
        prefs.edit().putBoolean("onboarding_completed", true).apply()
    }

    var userName by mutableStateOf(prefs.getString("user_name", "") ?: "")
    var userPhone by mutableStateOf(prefs.getString("user_phone", "") ?: "")
    var userEmail by mutableStateOf(prefs.getString("user_email", "") ?: "")
    var userAvatar by mutableStateOf(prefs.getString("user_avatar", "avatar_male_1") ?: "avatar_male_1")
    var userState by mutableStateOf(prefs.getString("user_state", "राजस्थान (Rajasthan)") ?: "राजस्थान (Rajasthan)")
    var userDistrict by mutableStateOf(prefs.getString("user_district", "जयपुर (Jaipur)") ?: "जयपुर (Jaipur)")
    var userTargetExams by mutableStateOf(
        prefs.getStringSet("user_target_exams", setOf("RAS", "REET", "CET"))?.toSet() ?: setOf("RAS", "REET", "CET")
    )
    
    var darkThemeOverride by mutableStateOf<Boolean?>(
        if (prefs.contains("dark_theme_override")) prefs.getBoolean("dark_theme_override", false) else null
    )
    var appLanguage by mutableStateOf(prefs.getString("app_language", "hi") ?: "hi") // "hi" or "en"

    // Coins & XP States (Saved to SharedPreferences for Offline Persistence)
    var userCoins by mutableStateOf(prefs.getInt("user_coins", 150))
    var userXP by mutableStateOf(prefs.getInt("user_xp", 120))
    var userStreak by mutableStateOf(prefs.getInt("user_streak", 3))

    // Premium & Revenue System States (Part 6)
    var isPremiumUser by mutableStateOf(prefs.getBoolean("user_is_premium", false))
    var userReferralCode by mutableStateOf(prefs.getString("user_referral_code", "GK" + (10000..99999).random().toString()) ?: "GK54921")
    var hasCollectedDailyRewardToday by mutableStateOf(prefs.getBoolean("daily_reward_collected_today", false))
    var currentDailyDay by mutableStateOf(prefs.getInt("current_daily_day", 1))
    var hasSpunWheelToday by mutableStateOf(prefs.getBoolean("has_spun_wheel_today", false))

    // App Setting for Negative marking
    var globalNegativeMarkingEnabled by mutableStateOf(prefs.getBoolean("global_neg_marking", true))

    // Quiz Session Configurations
    var quizType by mutableStateOf("PRACTICE") // "PRACTICE", "DAILY", "MOCK", "CHAPTER", "SUBJECT", "FULL_LENGTH", "PREVIOUS_YEAR"
    var quizName by mutableStateOf("अभ्यास क्विज़ (Practice Quiz)")
    var isNegativeMarkingEnabled by mutableStateOf(true)
    var difficultyLevel by mutableStateOf("मध्यम (Medium)")
    var totalMarks by mutableStateOf(100)
    var quizTimeLimitSeconds by mutableStateOf(0)
    var quizStartTime by mutableStateOf(0L)
    var quizTimeTaken by mutableStateOf(0) // in seconds
    
    // Quiz Progress & Answers map (enables back/forth navigation and state retention)
    var userAnswers by mutableStateOf<Map<Int, String>>(emptyMap()) // map of question index to chosen option ("A", "B", "C", "D")
    var markedForReview by mutableStateOf<Set<Int>>(emptySet()) // set of question indexes marked for review
    var skippedQuestionsCount by mutableStateOf(0)
    var wrongAnswersCount by mutableStateOf(0)

    // Quiz Session States
    var quizQuestions = mutableStateOf<List<GkQuestion>>(emptyList())
    var currentQuestionIndex by mutableStateOf(0)
    var selectedOption by mutableStateOf<String?>(null) // "A", "B", "C", "D" (currently focused)
    var isAnswerChecked by mutableStateOf(false) // used in Practice Mode to show explanations immediately
    var quizScore by mutableStateOf(0)
    var correctAnswersCount by mutableStateOf(0)
    var quizFinished by mutableStateOf(false)
    var quizTimerSeconds by mutableStateOf(0)
    private var timerJob: Job? = null

    // Navigation and UX states
    var selectedCategory = mutableStateOf<GkCategory?>(null)
    var selectedNote = mutableStateOf<StudyNote?>(null)
    var activeTab by mutableStateOf("home") // "home", "rajasthan", "india", "bookmarks", "profile", etc.

    init {
        val database = AppDatabase.getDatabase(application)
        repository = GKRepository(database.gkDao())

        // Initialize state flows
        rajasthanCategories = repository.rajasthanCategories.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        indiaCategories = repository.indiaCategories.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        bookmarks = repository.allBookmarks.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        userResults = repository.allResults.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allNotes = repository.allNotes.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        currentAffairs = repository.allCurrentAffairs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        previousPapers = repository.allPreviousPapers.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        leaderboard = repository.leaderboard.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allQuestions = repository.getAllQuestionsFlow().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Seed DB on startup if empty
        viewModelScope.launch {
            repository.checkAndSeedDatabase()
        }
    }

    // Toggle Bookmarking for questions
    fun toggleBookmark(id: String, type: String, title: String, categoryId: String, contentJson: String) {
        viewModelScope.launch {
            repository.toggleBookmark(id, type, title, categoryId, contentJson)
        }
    }

    suspend fun isBookmarked(id: String): Boolean {
        return repository.isBookmarked(id)
    }

    // PDF / Study Note Download simulation
    fun simulateDownloadNote(noteId: String) {
        viewModelScope.launch {
            repository.updateDownloadStatus(noteId, true)
        }
    }

    fun simulateDeleteNote(noteId: String) {
        viewModelScope.launch {
            repository.updateDownloadStatus(noteId, false)
        }
    }

    // Quiz Control Methods (Enhanced Universal Quiz Engine)
    fun startQuizEngine(
        type: String,
        name: String,
        questions: List<GkQuestion>,
        withTimer: Boolean,
        timeLimitMinutes: Int = 10,
        difficulty: String = "मध्यम (Medium)"
    ) {
        quizType = type
        quizName = name
        quizQuestions.value = questions
        quizTimeLimitSeconds = if (withTimer) timeLimitMinutes * 60 else 0
        difficultyLevel = difficulty
        isNegativeMarkingEnabled = globalNegativeMarkingEnabled
        totalMarks = questions.size * 10
        
        // Reset progress counters
        currentQuestionIndex = 0
        selectedOption = null
        isAnswerChecked = false
        quizScore = 0
        correctAnswersCount = 0
        wrongAnswersCount = 0
        skippedQuestionsCount = 0
        quizFinished = false
        userAnswers = emptyMap()
        markedForReview = emptySet()
        quizStartTime = System.currentTimeMillis()
        quizTimeTaken = 0
        
        timerJob?.cancel()
        if (withTimer) {
            quizTimerSeconds = quizTimeLimitSeconds
            timerJob = viewModelScope.launch {
                while (quizTimerSeconds > 0 && !quizFinished) {
                    delay(1000)
                    quizTimerSeconds--
                }
                if (quizTimerSeconds == 0) {
                    submitQuizFinal()
                }
            }
        }
    }

    fun selectEngineOption(option: String) {
        userAnswers = userAnswers + (currentQuestionIndex to option)
        selectedOption = option
    }

    fun toggleMarkForReview(index: Int) {
        markedForReview = if (markedForReview.contains(index)) {
            markedForReview - index
        } else {
            markedForReview + index
        }
    }

    fun skipQuestion() {
        nextEngineQuestion()
    }

    fun prevEngineQuestion() {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--
            selectedOption = userAnswers[currentQuestionIndex]
        }
    }

    fun nextEngineQuestion() {
        if (currentQuestionIndex < quizQuestions.value.size - 1) {
            currentQuestionIndex++
            selectedOption = userAnswers[currentQuestionIndex]
        }
    }

    fun submitQuizFinal() {
        if (quizFinished) return
        quizFinished = true
        timerJob?.cancel()
        
        // Calculate time taken
        val now = System.currentTimeMillis()
        val elapsed = ((now - quizStartTime) / 1000).toInt()
        quizTimeTaken = if (quizTimeLimitSeconds > 0) minOf(elapsed, quizTimeLimitSeconds) else elapsed

        // Compute scores
        var correct = 0
        var wrong = 0
        var skipped = 0
        var computedScore = 0

        quizQuestions.value.forEachIndexed { index, question ->
            val answer = userAnswers[index]
            if (answer == null) {
                skipped++
            } else if (answer == question.correctOption) {
                correct++
                computedScore += 10
            } else {
                wrong++
                if (isNegativeMarkingEnabled) {
                    computedScore -= 3
                }
            }
        }

        correctAnswersCount = correct
        wrongAnswersCount = wrong
        skippedQuestionsCount = skipped
        quizScore = maxOf(0, computedScore) // Keep non-negative

        // Distribute Coins & XP (Offline local + cloud syncing simulation)
        val coinsEarned = correct * 2
        val xpEarned = correct * 10
        userCoins += coinsEarned
        userXP += xpEarned
        
        // Save to Shared Preferences
        prefs.edit()
            .putInt("user_coins", userCoins)
            .putInt("user_xp", userXP)
            .apply()

        // Sync with Room Local DB (Acts as offline sync cache)
        viewModelScope.launch {
            repository.saveQuizResult(
                quizTitle = quizName,
                totalQuestions = quizQuestions.value.size,
                correctAnswers = correct,
                score = quizScore
            )
            
            // Console Sync to Cloud Firestore as requested
            println("📊 [Firestore Offline-Sync] Saved score to Firestore: correct=$correct score=$quizScore coins=$userCoins")
        }
    }

    fun startCategoryQuiz(category: GkCategory) {
        viewModelScope.launch {
            repository.getQuestionsByCategory(category.id).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions.shuffled() else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "PRACTICE",
                    name = "${category.title} अभ्यास",
                    questions = qList,
                    withTimer = false,
                    difficulty = "मध्यम (Medium)"
                )
            }
        }
    }

    fun startDailyQuiz() {
        viewModelScope.launch {
            repository.getRandomQuestions(5).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "DAILY",
                    name = "डेली लाइव क्विज़ (Daily Live Quiz)",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = 5,
                    difficulty = "मध्यम (Medium)"
                )
            }
        }
    }

    fun startMockTest(durationMinutes: Int) {
        viewModelScope.launch {
            repository.getRandomQuestions(10).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "MOCK",
                    name = "मॉक टेस्ट परीक्षा (Full Mock)",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = durationMinutes,
                    difficulty = "कठिन (Hard)"
                )
            }
        }
    }

    fun startChapterQuiz(chapterName: String, categoryId: String) {
        viewModelScope.launch {
            repository.getQuestionsByCategory(categoryId).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions.take(6) else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "CHAPTER",
                    name = "अध्याय क्विज़: $chapterName",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = 6,
                    difficulty = "मध्यम (Medium)"
                )
            }
        }
    }

    fun startSubjectQuiz(subjectName: String, categoryId: String) {
        viewModelScope.launch {
            repository.getQuestionsByCategory(categoryId).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "SUBJECT",
                    name = "विषय टेस्ट: $subjectName",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = 8,
                    difficulty = "मध्यम (Medium)"
                )
            }
        }
    }

    fun startFullLengthTest() {
        viewModelScope.launch {
            repository.getRandomQuestions(15).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "FULL_LENGTH",
                    name = "पूर्ण लम्बाई मॉक टेस्ट (Full Length Test)",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = 15,
                    difficulty = "कठिन (Hard)"
                )
            }
        }
    }

    fun startPreviousYearQuiz(examName: String) {
        viewModelScope.launch {
            repository.getRandomQuestions(8).collectLatest { questions ->
                val qList = if (questions.isNotEmpty()) questions else getFallbackGeneralQuestions()
                startQuizEngine(
                    type = "PREVIOUS_YEAR",
                    name = "गत वर्ष प्रश्न पत्र: $examName",
                    questions = qList,
                    withTimer = true,
                    timeLimitMinutes = 8,
                    difficulty = "कठिन (Hard)"
                )
            }
        }
    }

    fun toggleGlobalNegativeMarking(enabled: Boolean) {
        globalNegativeMarkingEnabled = enabled
        prefs.edit().putBoolean("global_neg_marking", enabled).apply()
    }

    private fun getFallbackGeneralQuestions(): List<GkQuestion> {
        return listOf(
            GkQuestion(
                categoryId = "general",
                questionText = "भारत का राष्ट्रीय फूल कौन सा है?",
                optionA = "गुलाब",
                optionB = "कमल",
                optionC = "सूरजमुखी",
                optionD = "गेंदा",
                correctOption = "B",
                explanation = "भारत का राष्ट्रीय फूल कमल (Lotus) है। इसका वैज्ञानिक नाम नेलुम्बो न्यूसिफेरा है।"
            ),
            GkQuestion(
                categoryId = "general",
                questionText = "क्षेत्रफल की दृष्टि से भारत का सबसे बड़ा राज्य कौन सा है?",
                optionA = "उत्तर प्रदेश",
                optionB = "मध्य प्रदेश",
                optionC = "महाराष्ट्र",
                optionD = "राजस्थान",
                correctOption = "D",
                explanation = "क्षेत्रफल की दृष्टि से राजस्थान भारत का सबसे बड़ा राज्य है। इसका कुल क्षेत्रफल 342,239 वर्ग किलोमीटर है।"
            )
        )
    }

    fun updateProfile(name: String, district: String, avatar: String) {
        userName = name
        userDistrict = district
        userAvatar = avatar
        prefs.edit()
            .putString("user_name", name)
            .putString("user_district", district)
            .putString("user_avatar", avatar)
            .apply()
    }

    fun toggleTargetExam(exam: String) {
        val current = userTargetExams.toMutableSet()
        if (current.contains(exam)) {
            current.remove(exam)
        } else {
            current.add(exam)
        }
        userTargetExams = current
        prefs.edit().putStringSet("user_target_exams", current).apply()
    }

    fun loginWithPhone(phone: String, onSuccess: (isNewUser: Boolean) -> Unit) {
        isLoggedIn = true
        userPhone = phone
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_phone", phone)
            .apply()
        
        val isNew = userName.isEmpty() || profileSetupCompleted == false
        onSuccess(isNew)
    }

    fun loginWithGoogle(onSuccess: (isNewUser: Boolean) -> Unit) {
        isLoggedIn = true
        if (userName.isEmpty()) {
            userName = "अमित कुमार देवसी"
            userEmail = "amit.dewasi99@gmail.com"
            userPhone = "9876543210"
            userDistrict = "जोधपुर (Jodhpur)"
        }
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_name", userName)
            .putString("user_email", userEmail)
            .putString("user_phone", userPhone)
            .putString("user_district", userDistrict)
            .apply()
        
        val isNew = profileSetupCompleted == false
        onSuccess(isNew)
    }

    fun loginAsGuest(onSuccess: () -> Unit) {
        isLoggedIn = true
        if (userName.isEmpty()) {
            userName = "अतिथि (Guest)"
            userPhone = "0000000000"
            userEmail = "guest@gkmaster.com"
            userDistrict = "जयपुर (Jaipur)"
        }
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_name", userName)
            .putString("user_phone", userPhone)
            .putString("user_email", userEmail)
            .putString("user_district", userDistrict)
            .apply()
        onSuccess()
    }

    fun saveProfile(
        name: String,
        phone: String,
        email: String,
        photo: String,
        state: String,
        district: String,
        targetExams: Set<String>
    ) {
        userName = name
        userPhone = phone
        userEmail = email
        userAvatar = photo
        userState = state
        userDistrict = district
        userTargetExams = targetExams
        profileSetupCompleted = true

        prefs.edit()
            .putString("user_name", name)
            .putString("user_phone", phone)
            .putString("user_email", email)
            .putString("user_avatar", photo)
            .putString("user_state", state)
            .putString("user_district", district)
            .putStringSet("user_target_exams", targetExams)
            .putBoolean("profile_setup_completed", true)
            .apply()
    }

    fun logout() {
        isLoggedIn = false
        profileSetupCompleted = false
        userName = ""
        userPhone = ""
        userEmail = ""
        userAvatar = "avatar_male_1"
        userState = "राजस्थान (Rajasthan)"
        userDistrict = "जयपुर (Jaipur)"
        userTargetExams = setOf("RAS", "REET", "CET")
        
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .putBoolean("profile_setup_completed", false)
            .putString("user_name", "")
            .putString("user_phone", "")
            .putString("user_email", "")
            .putString("user_avatar", "avatar_male_1")
            .putString("user_state", "राजस्थान (Rajasthan)")
            .putString("user_district", "जयपुर (Jaipur)")
            .putStringSet("user_target_exams", setOf("RAS", "REET", "CET"))
            .apply()
            
        activeTab = "home"
    }

    fun setDarkTheme(enabled: Boolean?) {
        darkThemeOverride = enabled
        if (enabled == null) {
            prefs.edit().remove("dark_theme_override").apply()
        } else {
            prefs.edit().putBoolean("dark_theme_override", enabled).apply()
        }
    }

    fun setAppLang(lang: String) {
        appLanguage = lang
        prefs.edit().putString("app_language", lang).apply()
    }

    // ==========================================
    // ADMIN PANEL PROPERTIES AND ACTIONS (PART 4)
    // ==========================================
    var isAdminLoggedIn by mutableStateOf(prefs.getBoolean("admin_logged_in", false))
    var adminEmail by mutableStateOf(prefs.getString("admin_email_auth", "admin@gkmaster.com") ?: "admin@gkmaster.com")

    // Advertisement settings
    var bannerAdId by mutableStateOf(prefs.getString("admin_banner_ad_id", "ca-app-pub-3940256099942544/6300978111") ?: "ca-app-pub-3940256099942544/6300978111")
    var interstitialAdId by mutableStateOf(prefs.getString("admin_interstitial_ad_id", "ca-app-pub-3940256099942544/1033173712") ?: "ca-app-pub-3940256099942544/1033173712")
    var rewardedAdId by mutableStateOf(prefs.getString("admin_rewarded_ad_id", "ca-app-pub-3940256099942544/5224354917") ?: "ca-app-pub-3940256099942544/5224354917")
    var nativeAdId by mutableStateOf(prefs.getString("admin_native_ad_id", "ca-app-pub-3940256099942544/2247696110") ?: "ca-app-pub-3940256099942544/2247696110")
    var appOpenAdId by mutableStateOf(prefs.getString("admin_app_open_ad_id", "ca-app-pub-3940256099942544/9257395921") ?: "ca-app-pub-3940256099942544/9257395921")
    var adsEnabled by mutableStateOf(prefs.getBoolean("admin_ads_enabled", true))

    // App Preferences
    var adminAppName by mutableStateOf(prefs.getString("admin_app_name", "GK Master - राजस्थान & भारत") ?: "GK Master - राजस्थान & भारत")
    var adminAboutUs by mutableStateOf(prefs.getString("admin_about_us", "यह ऐप राजस्थान और भारत की प्रतियोगी परीक्षाओं की तैयारी कर रहे विद्यार्थियों के लिए सर्वश्रेष्ठ मार्गदर्शक है।") ?: "यह ऐप राजस्थान और भारत की प्रतियोगी परीक्षाओं की तैयारी कर रहे विद्यार्थियों के लिए सर्वश्रेष्ठ मार्गदर्शक है।")
    var adminPrivacyPolicy by mutableStateOf(prefs.getString("admin_privacy_policy", "हम आपकी गोपनीयता का पूर्ण आदर करते हैं और सुरक्षित अध्ययन अनुभव प्रदान करते हैं।") ?: "हम आपकी गोपनीयता का पूर्ण आदर करते हैं और सुरक्षित अध्ययन अनुभव प्रदान करते हैं।")
    var adminTermsAndConditions by mutableStateOf(prefs.getString("admin_terms_and_conditions", "सभी सामग्री केवल संदर्भ और तैयारी के उद्देश्य से प्रदान की गई है।") ?: "सभी सामग्री केवल संदर्भ और तैयारी के उद्देश्य से प्रदान की गई है।")

    fun loginAdmin(email: String, isGoogle: Boolean = false): Boolean {
        // Admin security role access check: matches any email containing "admin"
        if (isGoogle || email.trim().lowercase().contains("admin")) {
            isAdminLoggedIn = true
            adminEmail = email.ifEmpty { "admin@gkmaster.com" }
            prefs.edit()
                .putBoolean("admin_logged_in", true)
                .putString("admin_email_auth", adminEmail)
                .apply()
            return true
        }
        return false
    }

    fun logoutAdmin() {
        isAdminLoggedIn = false
        prefs.edit().putBoolean("admin_logged_in", false).apply()
    }

    fun updateAdSettings(banner: String, interstitial: String, rewarded: String, native: String, appOpen: String, enabled: Boolean) {
        bannerAdId = banner
        interstitialAdId = interstitial
        rewardedAdId = rewarded
        nativeAdId = native
        appOpenAdId = appOpen
        adsEnabled = enabled
        prefs.edit()
            .putString("admin_banner_ad_id", banner)
            .putString("admin_interstitial_ad_id", interstitial)
            .putString("admin_rewarded_ad_id", rewarded)
            .putString("admin_native_ad_id", native)
            .putString("admin_app_open_ad_id", appOpen)
            .putBoolean("admin_ads_enabled", enabled)
            .apply()
    }

    fun updateAppSettingsAdmin(name: String, about: String, privacy: String, terms: String) {
        adminAppName = name
        adminAboutUs = about
        adminPrivacyPolicy = privacy
        adminTermsAndConditions = terms
        prefs.edit()
            .putString("admin_app_name", name)
            .putString("admin_about_us", about)
            .putString("admin_privacy_policy", privacy)
            .putString("admin_terms_and_conditions", terms)
            .apply()
    }

    // CRUD triggers
    fun addQuestion(question: GkQuestion) {
        viewModelScope.launch {
            repository.insertQuestion(question)
        }
    }

    fun deleteQuestion(id: Int) {
        viewModelScope.launch {
            repository.deleteQuestion(id)
        }
    }

    fun addCategory(category: GkCategory) {
        viewModelScope.launch {
            repository.insertCategory(category)
        }
    }

    fun deleteCategory(id: String) {
        viewModelScope.launch {
            repository.deleteCategory(id)
        }
    }

    fun addNote(note: StudyNote) {
        viewModelScope.launch {
            repository.insertNote(note)
        }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun addCurrentAffair(affair: CurrentAffair) {
        viewModelScope.launch {
            repository.insertCurrentAffair(affair)
        }
    }

    fun deleteCurrentAffair(id: Int) {
        viewModelScope.launch {
            repository.deleteCurrentAffair(id)
        }
    }

    fun resetLeaderboard() {
        viewModelScope.launch {
            repository.clearLeaderboard()
            // Add initial fresh dummy leaderboard
            val freshLeaderboard = listOf(
                LeaderboardEntry("u_1", "नया टॉपर (Fresh Air)", 1200, 1, "avatar_female_2", "जयपुर"),
                LeaderboardEntry("u_2", "अजय पाल सिंह", 950, 2, "avatar_male_2", "जोधपुर"),
                LeaderboardEntry("u_3", "मीना कुमारी", 800, 3, "avatar_female_1", "अजमेर")
            )
            repository.insertLeaderboard(freshLeaderboard)
        }
    }

    // Add/Remove Coins & XP on simulated active user state
    fun addCoins(amount: Int) {
        userCoins += amount
        prefs.edit().putInt("user_coins", userCoins).apply()
    }

    fun removeCoins(amount: Int) {
        userCoins = (userCoins - amount).coerceAtLeast(0)
        prefs.edit().putInt("user_coins", userCoins).apply()
    }

    fun addXP(amount: Int) {
        userXP += amount
        prefs.edit().putInt("user_xp", userXP).apply()
    }

    fun removeXP(amount: Int) {
        userXP = (userXP - amount).coerceAtLeast(0)
        prefs.edit().putInt("user_xp", userXP).apply()
    }

    fun setPremiumStatus(isPremium: Boolean) {
        isPremiumUser = isPremium
        prefs.edit().putBoolean("user_is_premium", isPremium).apply()
    }

    fun collectDailyReward(): String {
        if (hasCollectedDailyRewardToday) {
            return "आज का डेली रिवॉर्ड पहले ही कलेक्ट किया जा चुका है!"
        }
        val currentDay = currentDailyDay
        val rewardMessage = when (currentDay) {
            1 -> {
                addCoins(50)
                "पहला दिन! +50 कॉइंस कलेक्ट किए गए 🎉"
            }
            2 -> {
                addXP(100)
                "दूसरा दिन! +100 XP कलेक्ट किए गए ✨"
            }
            3 -> {
                addCoins(100)
                "तीसरा दिन! +100 कॉइंस कलेक्ट किए गए 📚"
            }
            4 -> {
                addCoins(150)
                "चौथा दिन! +150 कॉइंस कलेक्ट किए गए 🌟"
            }
            5 -> {
                addXP(200)
                "पांचवां दिन! +200 XP कलेक्ट किए गए 🏆"
            }
            6 -> {
                addCoins(200)
                "छठा दिन! +200 कॉइंस कलेक्ट किए गए 🛡️"
            }
            else -> {
                addCoins(500)
                addXP(500)
                setPremiumStatus(true) // Mega Reward triggers trial premium
                "सातवां दिन! मेगा रिवॉर्ड: +500 कॉइंस, +500 XP और 1 दिन की प्रीमियम सदस्यता! 💎🎁"
            }
        }
        hasCollectedDailyRewardToday = true
        currentDailyDay = if (currentDay >= 7) 1 else currentDay + 1
        prefs.edit()
            .putBoolean("daily_reward_collected_today", true)
            .putInt("current_daily_day", currentDailyDay)
            .apply()
        return rewardMessage
    }

    fun spinWheel(): Pair<String, Int> {
        val rewards = listOf(
            "100 Coins" to 100,
            "50 XP" to 50,
            "250 Coins" to 250,
            "150 XP" to 150,
            "500 Coins" to 500,
            "300 XP" to 300,
            "Premium Trial" to 1,
            "Lucky JackPot" to 1000
        )
        val randomIndex = (0..7).random()
        val (desc, value) = rewards[randomIndex]
        
        when (randomIndex) {
            0 -> addCoins(value)
            1 -> addXP(value)
            2 -> addCoins(value)
            3 -> addXP(value)
            4 -> addCoins(value)
            5 -> addXP(value)
            6 -> setPremiumStatus(true)
            7 -> {
                addCoins(value)
                addXP(500)
            }
        }
        hasSpunWheelToday = true
        prefs.edit().putBoolean("has_spun_wheel_today", true).apply()
        return Pair("बधाई हो! आपने जीता: $desc", randomIndex)
    }

    fun submitReferral(code: String): Boolean {
        if (code.trim().uppercase() == userReferralCode) {
            return false
        }
        if (code.trim().length >= 5) {
            addCoins(250)
            addXP(100)
            return true
        }
        return false
    }

    fun resetDailyReward() {
        hasCollectedDailyRewardToday = false
        hasSpunWheelToday = false
        prefs.edit()
            .putBoolean("daily_reward_collected_today", false)
            .putBoolean("has_spun_wheel_today", false)
            .apply()
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
