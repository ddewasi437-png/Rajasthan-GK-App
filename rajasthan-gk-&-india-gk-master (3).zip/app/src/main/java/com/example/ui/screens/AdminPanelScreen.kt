package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.*
import com.example.data.firebase.FirebaseBackend
import com.example.ui.components.MainAppHeader
import kotlinx.coroutines.launch
import com.example.ui.theme.AmberGold
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminPanelScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val allQuestions by viewModel.allQuestions.collectAsState()
    val allCategoriesRajasthan by viewModel.rajasthanCategories.collectAsState()
    val allCategoriesIndia by viewModel.indiaCategories.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val allCurrentAffairs by viewModel.currentAffairs.collectAsState()
    val leaderboardEntries by viewModel.leaderboard.collectAsState()

    var activeAdminTab by remember { mutableStateOf("DASHBOARD") } // DASHBOARD, QUESTIONS, CATEGORIES, PDFS, NOTIFICATIONS, USERS, SETTINGS

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (!viewModel.isAdminLoggedIn) {
                // Admin Login Screen
                AdminLoginView(viewModel = viewModel, onNavigate = onNavigate)
            } else {
                // Admin Dashboard Content
                Column(modifier = Modifier.fillMaxSize()) {
                    // Custom Header for Admin
                    AdminHeader(
                        adminEmail = viewModel.adminEmail,
                        onGoToApp = { onNavigate("home") },
                        onLogout = { viewModel.logoutAdmin() }
                    )

                    // Tab Selector Navigation Row
                    AdminTabRow(
                        selectedTab = activeAdminTab,
                        onTabSelected = { activeAdminTab = it }
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        when (activeAdminTab) {
                            "DASHBOARD" -> AdminDashboardView(
                                viewModel = viewModel,
                                totalQuestionsCount = allQuestions.size,
                                totalCurrentAffairsCount = allCurrentAffairs.size
                            )
                            "QUESTIONS" -> AdminQuestionsView(
                                viewModel = viewModel,
                                allQuestions = allQuestions,
                                allCategories = allCategoriesRajasthan + allCategoriesIndia,
                                snackbarHostState = snackbarHostState
                            )
                            "CATEGORIES" -> AdminCategoriesView(
                                viewModel = viewModel,
                                allCategories = allCategoriesRajasthan + allCategoriesIndia,
                                snackbarHostState = snackbarHostState
                            )
                            "PDFS" -> AdminPDFsAndAffairsView(
                                viewModel = viewModel,
                                allNotes = allNotes,
                                allCurrentAffairs = allCurrentAffairs,
                                allCategories = allCategoriesRajasthan + allCategoriesIndia,
                                snackbarHostState = snackbarHostState
                            )
                            "NOTIFICATIONS" -> AdminNotificationsView(
                                viewModel = viewModel,
                                allCategories = allCategoriesRajasthan + allCategoriesIndia,
                                snackbarHostState = snackbarHostState
                            )
                            "USERS" -> AdminUserManagementView(
                                viewModel = viewModel,
                                leaderboardEntries = leaderboardEntries,
                                snackbarHostState = snackbarHostState
                            )
                            "SETTINGS" -> AdminSettingsAndBackupView(
                                viewModel = viewModel,
                                snackbarHostState = snackbarHostState
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 1. ADMIN LOGIN VIEW
// ==========================================
@Composable
fun AdminLoginView(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf(false) }
    var generalError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Premium Admin Lock Icon
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Saffron.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Admin Lock",
                tint = Saffron,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "प्रशासक लॉगिन (Admin Login Dashboard)",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "केवल प्रमाणित एडमिन ही क्रेडेंशियल्स का उपयोग कर लॉगिन करें।",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(4.dp, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Email field
                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        emailError = false
                        generalError = null
                    },
                    label = { Text("एडमिन ईमेल (Admin Email)") },
                    placeholder = { Text("e.g. admin@gkmaster.com") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    isError = emailError,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )

                // Password field
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        generalError = null
                    },
                    label = { Text("पासवर्ड (Password)") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )

                if (generalError != null) {
                    Text(
                        text = generalError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Sign In Button
                Button(
                    onClick = {
                        if (email.trim().isEmpty() || !email.contains("@")) {
                            emailError = true
                            generalError = "कृपया मान्य ईमेल दर्ज करें।"
                        } else if (password.trim().isEmpty()) {
                            generalError = "कृपया पासवर्ड दर्ज करें।"
                        } else {
                            // Check admin role eligibility
                            val success = viewModel.loginAdmin(email.trim())
                            if (!success) {
                                generalError = "प्रवेश वर्जित! केवल एडमिन रोल वाले उपयोगकर्ताओं को ही अनुमति है।"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Icon(Icons.Default.Login, contentDescription = "Login")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("एडमिन पोर्टल में प्रवेश करें", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                // Forgot Password Simulation Trigger
                Text(
                    text = "पासवर्ड भूल गए? (Forgot Password)",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Saffron),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickable {
                            generalError = "रीसेट ईमेल सफलतापूर्वक भेजा गया! (Simulated)"
                        }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Or separator
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HorizontalDivider(modifier = Modifier.weight(1f), color = Color.LightGray)
            Text(" अथवा ", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp))
            HorizontalDivider(modifier = Modifier.weight(1f), color = Color.LightGray)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Google Sign In Simulation Button
        OutlinedButton(
            onClick = {
                viewModel.loginAdmin("admin.google@gkmaster.com", isGoogle = true)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color.Gray)
        ) {
            Icon(Icons.Default.AccountCircle, contentDescription = "Google Logo", tint = Saffron)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Google Admin Account से लॉगिन करें", color = MaterialTheme.colorScheme.onBackground)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Switch to App button
        TextButton(
            onClick = { onNavigate("home") }
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            Spacer(modifier = Modifier.width(6.dp))
            Text("छात्र ऐप पर वापस जाएं (Back to Student App)", fontWeight = FontWeight.Bold)
        }
    }
}

// ==========================================
// 2. ADMIN HEADER
// ==========================================
@Composable
fun AdminHeader(
    adminEmail: String,
    onGoToApp: () -> Unit,
    onLogout: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), // Slate dark theme header
        shape = RoundedCornerShape(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "GK Master Admin Panel 🛠️",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = Color.White)
                    )
                }
                Text(
                    text = "लॉगिन ईमेल: $adminEmail",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.LightGray)
                )
            }

            // Go to App Button
            OutlinedButton(
                onClick = onGoToApp,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Saffron),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Saffron),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Icon(Icons.Default.OpenInNew, contentDescription = "App", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ऐप खोलें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // Logout Admin Button
            IconButton(
                onClick = onLogout
            ) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = "Logout", tint = Color.Red)
            }
        }
    }
}

// ==========================================
// 3. ADMIN TAB SELECTOR
// ==========================================
@Composable
fun AdminTabRow(
    selectedTab: String,
    onTabSelected: (String) -> Unit
) {
    val tabs = listOf(
        "DASHBOARD" to "होम",
        "QUESTIONS" to "प्रश्न",
        "CATEGORIES" to "श्रेणी",
        "PDFS" to "पीडीएफ/करेंट",
        "NOTIFICATIONS" to "सूचना",
        "USERS" to "यूजर",
        "SETTINGS" to "सेटिंग्स"
    )

    ScrollableTabRow(
        selectedTabIndex = tabs.indexOfFirst { it.first == selectedTab }.coerceAtLeast(0),
        edgePadding = 12.dp,
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        contentColor = MaterialTheme.colorScheme.primary
    ) {
        tabs.forEach { tab ->
            Tab(
                selected = selectedTab == tab.first,
                onClick = { onTabSelected(tab.first) },
                text = { Text(tab.second, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }
    }
}

// ==========================================
// 4. ADMIN DASHBOARD PANEL
// ==========================================
@Composable
fun AdminDashboardView(
    viewModel: GKViewModel,
    totalQuestionsCount: Int,
    totalCurrentAffairsCount: Int
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcoming card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Saffron.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, Saffron.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.WavingHand, contentDescription = "Welcome", tint = Saffron, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "स्वागत है, मुख्य प्रशासक! 👑",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "आज का संपूर्ण ऐप एनालिटिक्स, प्रश्न प्रणालियों और एडमिन गतिविधियों की निगरानी यहाँ से करें।",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // Stats LazyVerticalGrid (using custom columns layout)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard(title = "कुल उपयोगकर्ता (Total Users)", value = "1,54,230", icon = Icons.Default.People, color = Color(0xFF2563EB), modifier = Modifier.weight(1f))
                    AdminStatCard(title = "सक्रिय यूजर (Active Users)", value = "12,410", icon = Icons.Default.Person, color = Color(0xFF16A34A), modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard(title = "कुल प्रश्न (Total Questions)", value = totalQuestionsCount.toString(), icon = Icons.Default.QuestionAnswer, color = Color(0xFFEA580C), modifier = Modifier.weight(1f))
                    AdminStatCard(title = "क्विज़ प्रयास (Attempts)", value = "8,92,120", icon = Icons.Default.AssignmentTurnedIn, color = Color(0xFF9333EA), modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard(title = "दैनिक सक्रिय (DAU)", value = "8,940", icon = Icons.Default.TrendingUp, color = Color(0xFF0D9488), modifier = Modifier.weight(1f))
                    AdminStatCard(title = "कुल पीडीएफ़ (PDFs)", value = "340", icon = Icons.Default.Description, color = Color(0xFFE11D48), modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AdminStatCard(title = "करेंट अफेयर्स (Affairs)", value = totalCurrentAffairsCount.toString(), icon = Icons.Default.CalendarToday, color = Color(0xFFCA8A04), modifier = Modifier.weight(1f))
                    AdminStatCard(title = "AdMob राजस्व (Est.)", value = "₹42,500", icon = Icons.Default.MonetizationOn, color = Color(0xFF15803D), modifier = Modifier.weight(1f))
                }
            }
        }

        // Beautiful Analytics Canvas/Charts simulator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "दैनिक सक्रिय उपयोगकर्ता चार्ट (DAU Retention Analytics)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulated Visual Chart representation
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        val chartBars = listOf(30, 45, 60, 40, 75, 90, 85, 100, 65, 80)
                        val chartLabels = listOf("Jun 18", "19", "20", "21", "22", "23", "24", "25", "26", "Today")

                        chartBars.forEachIndexed { idx, heightPct ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight(heightPct / 100f)
                                        .width(14.dp)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(if (idx == 9) Saffron else Color(0xFF3B82F6))
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = chartLabels[idx],
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }

        // Latest Notifications & Recent Registrations
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Recent Notifications Box
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("भेजे गए मुख्य अलर्ट 📢", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Saffron)
                        Spacer(modifier = Modifier.height(8.dp))
                        NotificationLogItem("Daily REET Test Alert", "1 hr ago")
                        NotificationLogItem("New Current Affairs June", "4 hrs ago")
                        NotificationLogItem("Exam Date of RAS Out", "Yesterday")
                    }
                }

                // Recent Signups Box
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("नवीनतम पंजीकरण 👥", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color(0xFF2563EB))
                        Spacer(modifier = Modifier.height(8.dp))
                        NotificationLogItem("रोहित जैन - अलवर", "10 m ago")
                        NotificationLogItem("संगीता चौधरी - सीकर", "25 m ago")
                        NotificationLogItem("विकास मीणा - दौसा", "2 hrs ago")
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .shadow(2.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = value,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun NotificationLogItem(title: String, time: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(time, fontSize = 9.sp, color = Color.Gray)
        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f), modifier = Modifier.padding(top = 4.dp))
    }
}

// ==========================================
// 5. QUESTION MANAGEMENT VIEW
// ==========================================
@Composable
fun AdminQuestionsView(
    viewModel: GKViewModel,
    allQuestions: List<GkQuestion>,
    allCategories: List<GkCategory>,
    snackbarHostState: SnackbarHostState
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredQuestions = allQuestions.filter {
        it.questionText.contains(searchQuery, ignoreCase = true) ||
                it.categoryId.contains(searchQuery, ignoreCase = true)
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var editTargetQuestion by remember { mutableStateOf<GkQuestion?>(null) }

    // Dialog form values
    var categoryId by remember { mutableStateOf(allCategories.firstOrNull()?.id ?: "raj_history") }
    var questionText by remember { mutableStateOf("") }
    var optionA by remember { mutableStateOf("") }
    var optionB by remember { mutableStateOf("") }
    var optionC by remember { mutableStateOf("") }
    var optionD by remember { mutableStateOf("") }
    var correctOption by remember { mutableStateOf("A") }
    var explanation by remember { mutableStateOf("") }
    var questionType by remember { mutableStateOf("MCQ") }
    var difficulty by remember { mutableStateOf("सरल") }
    var tags by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    // Function to launch / prefill dialog
    val openAddForm = {
        categoryId = allCategories.firstOrNull()?.id ?: "raj_history"
        questionText = ""
        optionA = ""
        optionB = ""
        optionC = ""
        optionD = ""
        correctOption = "A"
        explanation = ""
        questionType = "MCQ"
        difficulty = "सरल"
        tags = ""
        editTargetQuestion = null
        showAddDialog = true
    }

    val openEditForm = { q: GkQuestion ->
        categoryId = q.categoryId
        questionText = q.questionText
        optionA = q.optionA
        optionB = q.optionB
        optionC = q.optionC
        optionD = q.optionD
        correctOption = q.correctOption
        explanation = q.explanation
        questionType = q.questionType
        difficulty = "मध्यम"
        tags = q.reference
        editTargetQuestion = q
        showAddDialog = true
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("प्रश्न प्रबंधन (${filteredQuestions.size})", fontWeight = FontWeight.Black, fontSize = 16.sp)

            Button(
                onClick = openAddForm,
                colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("नया प्रश्न जोड़ें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bulk operations actions row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    // Bulk Import simulated trigger
                    viewModel.addQuestion(
                        GkQuestion(
                            categoryId = "raj_history",
                            questionText = "राजस्थान राज्य शैक्षिक अनुसंधान एवं प्रशिक्षण परिषद (RSCERT) कहाँ स्थित है?",
                            optionA = "उदयपुर",
                            optionB = "जयपुर",
                            optionC = "अजमेर",
                            optionD = "जोधपुर",
                            correctOption = "A",
                            explanation = "RSCERT उदयपुर में स्थित है। इसकी स्थापना 11 नवंबर 1978 को आर.सी. मेहरोत्रा समिति की सिफारिश पर की गई थी।"
                        )
                    )
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = "Import", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Bulk Import CSV", fontSize = 10.sp)
            }

            OutlinedButton(
                onClick = {
                    // Bulk Export trigger simulation
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = "Export", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Bulk Export CSV", fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("प्रश्न खोजें (Search Question)...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Questions List
        LazyColumn(
            modifier = Modifier.fillMaxSize().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filteredQuestions.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("कोई प्रश्न नहीं मिला।", color = Color.Gray, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                items(filteredQuestions) { q ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(1.dp, RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Badge(containerColor = Saffron) {
                                    Text(q.categoryId, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                    Text(q.questionType, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                }
                                Spacer(modifier = Modifier.weight(1f))

                                // Edit button
                                IconButton(onClick = { openEditForm(q) }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                // Delete button
                                IconButton(onClick = { viewModel.deleteQuestion(q.id) }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = q.questionText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("A. ${q.optionA}  |  B. ${q.optionB}", fontSize = 11.sp, color = Color.Gray)
                            Text("C. ${q.optionC}  |  D. ${q.optionD}", fontSize = 11.sp, color = Color.Gray)

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("सही उत्तर: ${q.correctOption}", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (editTargetQuestion == null) "नया प्रश्न जोड़ें" else "प्रश्न संपादित करें", fontWeight = FontWeight.Black) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Category dropdown simulator
                    Text("कैटेगरी आईडी (Category ID):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = categoryId,
                        onValueChange = { categoryId = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("प्रश्न प्रकार (MCQ / TF / MATCH):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = questionType,
                        onValueChange = { questionType = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("प्रश्न विवरण (Question Text):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = { questionText = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = optionA,
                            onValueChange = { optionA = it },
                            label = { Text("Option A") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = optionB,
                            onValueChange = { optionB = it },
                            label = { Text("Option B") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = optionC,
                            onValueChange = { optionC = it },
                            label = { Text("Option C") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = optionD,
                            onValueChange = { optionD = it },
                            label = { Text("Option D") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text("सही उत्तर (Correct Answer e.g. A, B, C, D):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = correctOption,
                        onValueChange = { correctOption = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("व्याख्या (Explanation):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = explanation,
                        onValueChange = { explanation = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("संदर्भ/टैग्स (Reference/Tags):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = tags,
                        onValueChange = { tags = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newQ = GkQuestion(
                            id = editTargetQuestion?.id ?: 0,
                            categoryId = categoryId,
                            questionText = questionText,
                            optionA = optionA,
                            optionB = optionB,
                            optionC = optionC,
                            optionD = optionD,
                            correctOption = correctOption,
                            explanation = explanation,
                            questionType = questionType,
                            reference = tags.ifEmpty { "प्रशासक द्वारा जोड़ा गया" }
                        )
                        viewModel.addQuestion(newQ)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("सुरक्षित करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

// ==========================================
// 6. CATEGORY MANAGEMENT VIEW
// ==========================================
@Composable
fun AdminCategoriesView(
    viewModel: GKViewModel,
    allCategories: List<GkCategory>,
    snackbarHostState: SnackbarHostState
) {
    var showCategoryDialog by remember { mutableStateOf(false) }

    var catId by remember { mutableStateOf("") }
    var catTitle by remember { mutableStateOf("") }
    var catSubtitle by remember { mutableStateOf("") }
    var catType by remember { mutableStateOf("RAJASTHAN") } // RAJASTHAN or INDIA
    var catIcon by remember { mutableStateOf("Book") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("श्रेणी प्रबंधन (${allCategories.size})", fontWeight = FontWeight.Black, fontSize = 16.sp)

            Button(
                onClick = {
                    catId = ""
                    catTitle = ""
                    catSubtitle = ""
                    catType = "RAJASTHAN"
                    catIcon = "Book"
                    showCategoryDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("नया कैटेगरी जोड़ें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(allCategories) { category ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Saffron.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Category, contentDescription = "Icon", tint = Saffron, modifier = Modifier.size(18.dp))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(category.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("ID: ${category.id}  |  Type: ${category.type}", fontSize = 10.sp, color = Color.Gray)
                        }

                        IconButton(onClick = { viewModel.deleteCategory(category.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (showCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showCategoryDialog = false },
            title = { Text("नया श्रेणी जोड़ें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = catId, onValueChange = { catId = it }, label = { Text("ID (Unique)") })
                    OutlinedTextField(value = catTitle, onValueChange = { catTitle = it }, label = { Text("नाम (Title)") })
                    OutlinedTextField(value = catSubtitle, onValueChange = { catSubtitle = it }, label = { Text("उपशीर्षक (Subtitle)") })
                    OutlinedTextField(value = catType, onValueChange = { catType = it }, label = { Text("प्रकार (RAJASTHAN / INDIA)") })
                    OutlinedTextField(value = catIcon, onValueChange = { catIcon = it }, label = { Text("आइकन नाम (e.g. Book)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (catId.isNotEmpty() && catTitle.isNotEmpty()) {
                            viewModel.addCategory(GkCategory(catId, catTitle, catSubtitle, catType, catIcon))
                        }
                        showCategoryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("जोड़ें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCategoryDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

// ==========================================
// 7. PDF & CURRENT AFFAIRS MANAGEMENT VIEW
// ==========================================
@Composable
fun AdminPDFsAndAffairsView(
    viewModel: GKViewModel,
    allNotes: List<StudyNote>,
    allCurrentAffairs: List<CurrentAffair>,
    allCategories: List<GkCategory>,
    snackbarHostState: SnackbarHostState
) {
    var isCurrentAffairsSection by remember { mutableStateOf(false) }

    var showPdfDialog by remember { mutableStateOf(false) }
    var showAffairDialog by remember { mutableStateOf(false) }

    // PDF States
    var pdfId by remember { mutableStateOf("") }
    var pdfTitle by remember { mutableStateOf("") }
    var pdfContent by remember { mutableStateOf("") }
    var pdfName by remember { mutableStateOf("") }
    var pdfCatId by remember { mutableStateOf("raj_history") }

    // Current Affair States
    var affairTitle by remember { mutableStateOf("") }
    var affairDesc by remember { mutableStateOf("") }
    var affairContent by remember { mutableStateOf("") }
    var affairDate by remember { mutableStateOf("27 June 2026") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Toggle Buttons
        Row(modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { isCurrentAffairsSection = false },
                colors = ButtonDefaults.buttonColors(containerColor = if (!isCurrentAffairsSection) Saffron else Color.Gray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)
            ) {
                Text("पीडीएफ़ नोट्स प्रबंधन", fontSize = 12.sp)
            }
            Button(
                onClick = { isCurrentAffairsSection = true },
                colors = ButtonDefaults.buttonColors(containerColor = if (isCurrentAffairsSection) Saffron else Color.Gray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)
            ) {
                Text("करेंट अफेयर्स", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (!isCurrentAffairsSection) {
            // PDF notes list
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("पीडीएफ़ नोट्स सूची (${allNotes.size})", fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        pdfId = ""
                        pdfTitle = ""
                        pdfContent = ""
                        pdfName = ""
                        showPdfDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("PDF जोड़ें", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(allNotes) { note ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color.Red)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(note.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("फ़ाइल: ${note.pdfName}  |  साइज: ${note.fileSize}", fontSize = 10.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { viewModel.deleteNote(note.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                    }
                }
            }
        } else {
            // Current affairs list
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("करेंट अफेयर्स सूची (${allCurrentAffairs.size})", fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        affairTitle = ""
                        affairDesc = ""
                        affairContent = ""
                        showAffairDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("करेंट न्यूज़ जोड़ें", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(allCurrentAffairs) { affair ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarToday, contentDescription = "Calendar", tint = Saffron)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(affair.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("दिनांक: ${affair.date}  |  ${affair.description}", fontSize = 10.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { viewModel.deleteCurrentAffair(affair.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                    }
                }
            }
        }
    }

    // PDF add dialog
    if (showPdfDialog) {
        AlertDialog(
            onDismissRequest = { showPdfDialog = false },
            title = { Text("नया पीडीएफ दस्तावेज़ जोड़ें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = pdfId, onValueChange = { pdfId = it }, label = { Text("दस्तावेज़ ID") })
                    OutlinedTextField(value = pdfTitle, onValueChange = { pdfTitle = it }, label = { Text("शीर्षक (Title)") })
                    OutlinedTextField(value = pdfContent, onValueChange = { pdfContent = it }, label = { Text("संक्षिप्त विवरण (Content)") })
                    OutlinedTextField(value = pdfName, onValueChange = { pdfName = it }, label = { Text("पीडीएफ फ़ाइल नाम (PDF File name)") })
                    OutlinedTextField(value = pdfCatId, onValueChange = { pdfCatId = it }, label = { Text("श्रेणी आईडी (Category ID)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pdfId.isNotEmpty() && pdfTitle.isNotEmpty()) {
                            viewModel.addNote(StudyNote(pdfId, pdfCatId, pdfTitle, pdfContent, pdfName))
                        }
                        showPdfDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("सुरक्षित करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPdfDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Affair add dialog
    if (showAffairDialog) {
        AlertDialog(
            onDismissRequest = { showAffairDialog = false },
            title = { Text("दैनिक करेंट अफेयर्स जोड़ें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = affairTitle, onValueChange = { affairTitle = it }, label = { Text("समाचार शीर्षक") })
                    OutlinedTextField(value = affairDesc, onValueChange = { affairDesc = it }, label = { Text("संक्षिप्त हेडलाइन") })
                    OutlinedTextField(value = affairContent, onValueChange = { affairContent = it }, label = { Text("विस्तृत विवरण (Content)") })
                    OutlinedTextField(value = affairDate, onValueChange = { affairDate = it }, label = { Text("दिनांक (Date)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (affairTitle.isNotEmpty()) {
                            viewModel.addCurrentAffair(CurrentAffair(title = affairTitle, description = affairDesc, content = affairContent, date = affairDate))
                        }
                        showAffairDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("सुरक्षित करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAffairDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

// ==========================================
// 8. NOTIFICATION PANEL VIEW (FCM)
// ==========================================
@Composable
fun AdminNotificationsView(
    viewModel: GKViewModel,
    allCategories: List<GkCategory>,
    snackbarHostState: SnackbarHostState
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var targetSelection by remember { mutableStateOf("ALL") } // ALL, CATEGORY
    var selectedCategoryTarget by remember { mutableStateOf("raj_history") }
    var notificationType by remember { mutableStateOf("DAILY_QUIZ") } // DAILY_QUIZ, NEW_PDF, EXAM, PROMO

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Firebase Cloud Messaging (FCM) अधिसूचना प्रेषक 📢", fontWeight = FontWeight.Black, fontSize = 16.sp)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("पुश नोटिफिकेशन बनाएँ", fontWeight = FontWeight.Bold, color = Saffron)

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("नोटिफिकेशन शीर्षक (Notification Title)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it },
                    label = { Text("विवरण संदेश (Notification Body)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                Text("लक्षित दर्शक (Target Users Selection):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = targetSelection == "ALL", onClick = { targetSelection = "ALL" })
                        Text("सभी विद्यार्थी (All Users)")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = targetSelection == "CATEGORY", onClick = { targetSelection = "CATEGORY" })
                        Text("श्रेणी विशेष (Category)")
                    }
                }

                if (targetSelection == "CATEGORY") {
                    Text("लक्षित श्रेणी चुनें:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = selectedCategoryTarget,
                        onValueChange = { selectedCategoryTarget = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text("नोटिफिकेशन प्रकार (Notification Type):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                val types = listOf(
                    "DAILY_QUIZ" to "दैनिक क्विज़ स्मरण पत्र",
                    "NEW_PDF" to "नई पीडीएफ सामग्री अलर्ट",
                    "EXAM" to "प्रतियोगी परीक्षा सूचना",
                    "PROMO" to "प्रचार / ऑफर्स"
                )
                Column {
                    types.forEach { t ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { notificationType = t.first }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = notificationType == t.first, onClick = { notificationType = t.first })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(t.second, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        title = ""
                        body = ""
                        // Trigger simulated success snackbar
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("अधिसूचना भेजें (Send Live Notification)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 9. USER & LEADERBOARD MANAGEMENT VIEW
// ==========================================
@Composable
fun AdminUserManagementView(
    viewModel: GKViewModel,
    leaderboardEntries: List<LeaderboardEntry>,
    snackbarHostState: SnackbarHostState
) {
    var selectedUserCoinsTarget by remember { mutableStateOf<LeaderboardEntry?>(null) }
    var adjustCoinsAmount by remember { mutableStateOf("50") }
    var adjustXPAmount by remember { mutableStateOf("100") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("उपयोगकर्ता & लीडरबोर्ड प्रबंधन", fontWeight = FontWeight.Black, fontSize = 16.sp)

            Button(
                onClick = { viewModel.resetLeaderboard() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset")
                Spacer(modifier = Modifier.width(4.dp))
                Text("लीडरबोर्ड रीसेट करें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("सक्रिय विद्यार्थी सूची (Active Student Database)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Saffron)

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(leaderboardEntries) { entry ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Saffron.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("#${entry.rank}", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Saffron)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("जिला: ${entry.district}  |  प्राप्तांक: ${entry.score} XP", fontSize = 11.sp, color = Color.Gray)
                            }

                            // Coin adjustment dialog trigger
                            Button(
                                onClick = { selectedUserCoinsTarget = entry },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("प्रबंधित करें", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedUserCoinsTarget != null) {
        val user = selectedUserCoinsTarget
        AlertDialog(
            onDismissRequest = { selectedUserCoinsTarget = null },
            title = { Text("${user?.name} के कॉइन्स / XP समायोजित करें", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("सक्रिय उपयोगकर्ता: ${user?.name}")

                    OutlinedTextField(
                        value = adjustCoinsAmount,
                        onValueChange = { adjustCoinsAmount = it },
                        label = { Text("कॉइन्स राशि (Coins Amount)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    OutlinedTextField(
                        value = adjustXPAmount,
                        onValueChange = { adjustXPAmount = it },
                        label = { Text("XP राशि (XP Amount)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val coins = adjustCoinsAmount.toIntOrNull() ?: 0
                                viewModel.addCoins(coins)
                                selectedUserCoinsTarget = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ कॉइन्स जोड़ें")
                        }
                        Button(
                            onClick = {
                                val coins = adjustCoinsAmount.toIntOrNull() ?: 0
                                viewModel.removeCoins(coins)
                                selectedUserCoinsTarget = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("- कॉइन्स हटाएँ")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val xp = adjustXPAmount.toIntOrNull() ?: 0
                                viewModel.addXP(xp)
                                selectedUserCoinsTarget = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ XP जोड़ें")
                        }
                        Button(
                            onClick = {
                                val xp = adjustXPAmount.toIntOrNull() ?: 0
                                viewModel.removeXP(xp)
                                selectedUserCoinsTarget = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("- XP हटाएँ")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedUserCoinsTarget = null }) {
                    Text("पूर्ण")
                }
            }
        )
    }
}

// ==========================================
// 10. APP SETTINGS & BACKUP VIEW
// ==========================================
@Composable
fun AdminSettingsAndBackupView(
    viewModel: GKViewModel,
    snackbarHostState: SnackbarHostState
) {
    var appName by remember { mutableStateOf(viewModel.adminAppName) }
    var aboutUs by remember { mutableStateOf(viewModel.adminAboutUs) }
    var privacyPolicy by remember { mutableStateOf(viewModel.adminPrivacyPolicy) }
    var termsAndConditions by remember { mutableStateOf(viewModel.adminTermsAndConditions) }

    // Ad IDs
    var bannerId by remember { mutableStateOf(viewModel.bannerAdId) }
    var interstitialId by remember { mutableStateOf(viewModel.interstitialAdId) }
    var rewardedId by remember { mutableStateOf(viewModel.rewardedAdId) }
    var nativeId by remember { mutableStateOf(viewModel.nativeAdId) }
    var appOpenId by remember { mutableStateOf(viewModel.appOpenAdId) }
    var isAdsEnabled by remember { mutableStateOf(viewModel.adsEnabled) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("सामान्य ऐप सेटिंग्स & बैकअप", fontWeight = FontWeight.Black, fontSize = 16.sp)

        // General Info Settings
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ऐप ब्रांडिंग & कानूनी विवरण (App Branding)", fontWeight = FontWeight.Bold, color = Saffron)

                OutlinedTextField(value = appName, onValueChange = { appName = it }, label = { Text("ऐप का नाम (App Name)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = aboutUs, onValueChange = { aboutUs = it }, label = { Text("हमारे बारे में (About Us)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = privacyPolicy, onValueChange = { privacyPolicy = it }, label = { Text("गोपनीयता नीति (Privacy Policy)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = termsAndConditions, onValueChange = { termsAndConditions = it }, label = { Text("नियम और शर्तें (Terms & Conditions)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                Button(
                    onClick = {
                        viewModel.updateAppSettingsAdmin(appName, aboutUs, privacyPolicy, termsAndConditions)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("ब्रांडिंग सेटिंग्स अपडेट करें", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Ads settings
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("गूगल एडमॉब सेटिंग्स (AdMob IDs)", fontWeight = FontWeight.Bold, color = Saffron)

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("AdMob विज्ञापन चालू करें (Ads ON/OFF)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Switch(checked = isAdsEnabled, onCheckedChange = { isAdsEnabled = it })
                }

                OutlinedTextField(value = bannerId, onValueChange = { bannerId = it }, label = { Text("Banner Ad ID") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = interstitialId, onValueChange = { interstitialId = it }, label = { Text("Interstitial Ad ID") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = rewardedId, onValueChange = { rewardedId = it }, label = { Text("Rewarded Ad ID") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = nativeId, onValueChange = { nativeId = it }, label = { Text("Native Ad ID") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = appOpenId, onValueChange = { appOpenId = it }, label = { Text("App Open Ad ID") }, modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = {
                        viewModel.updateAdSettings(bannerId, interstitialId, rewardedId, nativeId, appOpenId, isAdsEnabled)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("विज्ञापन सेटिंग्स अपडेट करें", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Backup & Restore
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("सुरक्षा, बैकअप & रिस्टोर (Backup Engine)", fontWeight = FontWeight.Bold, color = Saffron)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        scope.launch {
                            snackbarHostState.showSnackbar("डाटाबेस बैकअप सफलतापूर्वक सुरक्षित किया गया! (Offline SQLite + JSON Backup)")
                        }
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))) {
                        Icon(Icons.Default.Backup, contentDescription = "Backup", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("बैकअप बनाएं", fontSize = 11.sp)
                    }
                    Button(onClick = {
                        scope.launch {
                            snackbarHostState.showSnackbar("डाटाबेस बैकअप रिस्टोर किया गया!")
                        }
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))) {
                        Icon(Icons.Default.Restore, contentDescription = "Restore", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("डेटा रिस्टोर", fontSize = 11.sp)
                    }
                }
            }
        }

        // FIREBASE PRODUCTION BACKEND CARD (Part 5)
        var firebaseRulesTab by remember { mutableStateOf("FIRESTORE") } // FIRESTORE, STORAGE, COLLECTIONS, ANALYTICS
        var rcMaintenanceMode by remember { mutableStateOf(false) }
        var rcHomeBannerUrl by remember { mutableStateOf("https://gkmaster.com/banners/welcome.jpg") }
        var rcAdsActive by remember { mutableStateOf(true) }
        var rcFeaturesUnlocked by remember { mutableStateOf(true) }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            border = BorderStroke(1.dp, Saffron.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = "Firebase Security", tint = Saffron, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Firebase Production Control Panel 🚀", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black))
                }

                Text(
                    text = "यह पोर्टल 10 लाख+ विद्यार्थियों के सुरक्षित लोड संतुलन और अद्यतन को संभालने हेतु डिज़ाइन किया गया है।",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                // Firebase Remote Config Live Overrides
                Text("Firebase Remote Config (तत्काल रिमोट अद्यतन):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Saffron)

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("मेंटेनेंस मोड (Maintenance Mode)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("चालू होने पर ऐप में मेंटेनेंस स्क्रीन दिखाई देगी", fontSize = 10.sp, color = Color.Gray)
                    }
                    Switch(checked = rcMaintenanceMode, onCheckedChange = { 
                        rcMaintenanceMode = it 
                        FirebaseBackend.updateRemoteConfig(rcMaintenanceMode, rcHomeBannerUrl, rcAdsActive, rcFeaturesUnlocked)
                    })
                }

                OutlinedTextField(
                    value = rcHomeBannerUrl,
                    onValueChange = { 
                        rcHomeBannerUrl = it 
                        FirebaseBackend.updateRemoteConfig(rcMaintenanceMode, rcHomeBannerUrl, rcAdsActive, rcFeaturesUnlocked)
                    },
                    label = { Text("लाइव बैनर यूआरएल (Home Banner URL)") },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodySmall,
                    shape = RoundedCornerShape(8.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("लाइव विज्ञापन सक्षम (Ads Active status)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Switch(checked = rcAdsActive, onCheckedChange = { 
                        rcAdsActive = it 
                        FirebaseBackend.updateRemoteConfig(rcMaintenanceMode, rcHomeBannerUrl, rcAdsActive, rcFeaturesUnlocked)
                    })
                }

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("नए फीचर्स अनलॉक (New Features Override)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Switch(checked = rcFeaturesUnlocked, onCheckedChange = { 
                        rcFeaturesUnlocked = it 
                        FirebaseBackend.updateRemoteConfig(rcMaintenanceMode, rcHomeBannerUrl, rcAdsActive, rcFeaturesUnlocked)
                    })
                }

                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))

                // Firebase Security Rules & Schema Tabs
                ScrollableTabRow(
                    selectedTabIndex = when (firebaseRulesTab) {
                        "FIRESTORE" -> 0
                        "STORAGE" -> 1
                        "COLLECTIONS" -> 2
                        else -> 3
                    },
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    indicator = {}
                ) {
                    listOf("FIRESTORE" to "Firestore Rules", "STORAGE" to "Storage Rules", "COLLECTIONS" to "Schema", "ANALYTICS" to "Analytics").forEach { item ->
                        Tab(
                            selected = firebaseRulesTab == item.first,
                            onClick = { firebaseRulesTab = item.first },
                            text = { Text(item.second, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (firebaseRulesTab) {
                        "FIRESTORE" -> {
                            Text(
                                text = FirebaseBackend.FIRESTORE_SECURITY_RULES,
                                color = Color(0xFF38BDF8),
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                        "STORAGE" -> {
                            Text(
                                text = FirebaseBackend.STORAGE_SECURITY_RULES,
                                color = Color(0xFF34D399),
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                        "COLLECTIONS" -> {
                            Text(
                                text = """
Firestore Collections Schema (Production Ready):
===================================================
- /users [uid, name, email, mobile, coins, xp, streak, level]
- /questions [id, category, subject, chapter, options, correct, explanation]
- /pdf_notes [id, name, pdfUrl, downloads, category, description]
- /current_affairs [id, title, description, image, date, category]
- /notifications [id, title, message, type, readStatus, createdDate]
- /leaderboard [uid, name, score, rank, district, coins, xp]
- /bookmarks [userId, questionId, savedDate]
- /achievements [name, rewardCoins, rewardXp, condition]
                                """.trimIndent(),
                                color = Color(0xFFFBBF24),
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                        "ANALYTICS" -> {
                            Text(
                                text = """
Live Firebase Analytics Event Tracking Schemas:
===================================================
[✓] app_open - Triggered when student launches app
[✓] quiz_start - Logging quiz_id, subject, category
[✓] quiz_complete - Tracking performance scores, time elapsed
[✓] pdf_download - Logging user download metrics
[✓] bookmark_added - Tracking most bookmarked questions
[✓] crashlytics_breadcrumbs - Active error diagnostics

Total Simulated Active Users: 1,54,230 Active DAU
Estimated monthly capacity: Unlimited Auto-scaled
                                """.trimIndent(),
                                color = Color(0xFFF472B6),
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        scope.launch {
                            snackbarHostState.showSnackbar("Firebase Rules & Config Synced successfully to Remote Cloud Console!")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("सिंक Firebase Security Rules", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
