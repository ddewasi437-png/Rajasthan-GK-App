package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GkCategory
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun GKCategoriesScreen(
    type: String, // "RAJASTHAN" or "INDIA"
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val title = if (type == "RAJASTHAN") "राजस्थान सामान्य ज्ञान" else "भारत सामान्य ज्ञान"
    val subtitle = if (type == "RAJASTHAN") "REET, RAS, पटवार, पुलिस हेतु संपूर्ण नोट्स व क्विज़" else "SSC, UPSC, रेलवे हेतु उत्कृष्ट भारतीय जीके"
    
    val categories by (if (type == "RAJASTHAN") viewModel.rajasthanCategories else viewModel.indiaCategories).collectAsState()
    
    var searchQuery by remember { mutableStateOf("") }
    val filteredCategories = categories.filter {
        it.title.contains(searchQuery, ignoreCase = true) || it.subtitle.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = title,
            subtitle = subtitle,
            onBackClick = { viewModel.activeTab = "home" }
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("विशिष्ट विषय खोजें... (जैसे भूगोल, इतिहास)", fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            singleLine = true
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (filteredCategories.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "कोई विषय नहीं मिला।",
                            style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray)
                        )
                    }
                }
            } else {
                items(filteredCategories) { category ->
                    CategoryRow(
                        category = category,
                        onClick = {
                            viewModel.selectedCategory.value = category
                            viewModel.startCategoryQuiz(category)
                            onNavigate("quiz_screen")
                        },
                        onReadNotesClick = {
                            viewModel.selectedCategory.value = category
                            onNavigate("pdf_notes")
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryRow(
    category: GkCategory,
    onClick: () -> Unit,
    onReadNotesClick: () -> Unit
) {
    val icon = when (category.iconName) {
        "History" -> Icons.Default.HistoryEdu
        "Terrain" -> Icons.Default.Terrain
        "Gavel" -> Icons.Default.Gavel
        "Palette" -> Icons.Default.Palette
        "TrendingUp" -> Icons.Default.TrendingUp
        "Explore" -> Icons.Default.Explore
        "Policy" -> Icons.Default.Policy
        "Science" -> Icons.Default.Science
        "CurrencyRupee" -> Icons.Default.CurrencyExchange
        else -> Icons.Default.Book
    }

    val iconColor = when (category.type) {
        "RAJASTHAN" -> Saffron
        else -> Color(0xFF1E40AF)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconBox(
                    icon = icon,
                    contentDescription = category.title,
                    backgroundColor = iconColor.copy(alpha = 0.12f),
                    iconColor = iconColor,
                    size = 46.dp
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = category.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = category.subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Read Notes Button
                OutlinedButton(
                    onClick = onReadNotesClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = iconColor),
                    border = BorderStroke(1.dp, iconColor.copy(alpha = 0.3f))
                ) {
                    Icon(Icons.Default.MenuBook, contentDescription = "Read", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("नोट्स पढ़ें", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                // Start Test Button
                Button(
                    onClick = onClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = iconColor)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Quiz", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("क्विज़ हल करें", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
