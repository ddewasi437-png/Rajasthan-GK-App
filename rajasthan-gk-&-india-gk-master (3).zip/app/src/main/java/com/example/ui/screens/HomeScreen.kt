package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CustomAvatar
import com.example.ui.components.PremiumCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val results by viewModel.userResults.collectAsState()
    val currentAffairsList by viewModel.currentAffairs.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val rajasthanCategories by viewModel.rajasthanCategories.collectAsState()
    val indiaCategories by viewModel.indiaCategories.collectAsState()

    val totalScore = results.sumOf { it.score }
    val testsTaken = results.size

    // Search query states
    var searchQuery by remember { mutableStateOf("") }
    var isSearchFocused by remember { mutableStateOf(false) }

    // Dialog state for notifications
    var showNotificationDialog by remember { mutableStateOf(false) }

    // Auto image slider state
    var currentSlide by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            currentSlide = (currentSlide + 1) % 3
        }
    }

    // Interactive Notification notices
    val notices = listOf(
        "🎯 REET 2026 परीक्षा तिथि घोषित: अपनी तैयारी तेज करें!",
        "🔥 डेली क्विज़ लाइव है: भाग लें और +100 XP अर्जित करें।",
        "📚 नया बजट 2026 नोट्स PDF डाउनलोड के लिए उपलब्ध है।"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // TOP APP BAR (Greeting, Profile, Notification Icon)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CustomAvatar(
                        avatarId = viewModel.userAvatar,
                        size = 46.dp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onNavigate("profile") }
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "नमस्ते, ${viewModel.userName}! 👋",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        )
                        Text(
                            text = "चलो आज कुछ नया सीखते हैं!",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Notification Badge Button
                Box {
                    IconButton(
                        onClick = { showNotificationDialog = true },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    // Tiny red notification dot
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Red)
                            .align(Alignment.TopEnd)
                            .offset(x = (-2).dp, y = (2).dp)
                    )
                }
            }
        }

        // SEARCH BAR (Functional GK Search)
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("विषय, नोट्स या क्विज़ खोजें...", fontSize = 13.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Saffron,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    leadingIcon = {
                        Icon(Icons.Outlined.Search, contentDescription = "Search", tint = Color.Gray)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                            }
                        }
                    },
                    singleLine = true
                )

                // Render Search Results dynamically
                if (searchQuery.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(4.dp, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = "खोज परिणाम (Search Results)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Saffron,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )

                            // Search Categories
                            val matchedCat = (rajasthanCategories + indiaCategories).filter {
                                it.title.contains(searchQuery, ignoreCase = true) || it.subtitle.contains(searchQuery, ignoreCase = true)
                            }
                            // Search Notes
                            val matchedNotes = allNotes.filter {
                                it.title.contains(searchQuery, ignoreCase = true) || it.content.contains(searchQuery, ignoreCase = true)
                            }

                            if (matchedCat.isEmpty() && matchedNotes.isEmpty()) {
                                Text(
                                    text = "कोई परिणाम नहीं मिला।",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(8.dp)
                                )
                            } else {
                                matchedCat.take(2).forEach { cat ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                searchQuery = ""
                                                if (rajasthanCategories.contains(cat)) {
                                                    onNavigate("rajasthan_gk")
                                                } else {
                                                    onNavigate("india_gk")
                                                }
                                            }
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Topic, contentDescription = null, tint = Saffron, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(cat.title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text("श्रेणी", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }

                                matchedNotes.take(2).forEach { note ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                searchQuery = ""
                                                onNavigate("pdf_notes")
                                            }
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Description, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(note.title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text("नोट्स", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // AUTO IMAGE SLIDER
        item {
            Column(modifier = Modifier.padding(top = 10.dp, bottom = 12.dp)) {
                val bannerGradients = listOf(
                    Brush.horizontalGradient(colors = listOf(Saffron, AmberGold)),
                    Brush.horizontalGradient(colors = listOf(RoyalBlue, Color(0xFF3B82F6))),
                    Brush.horizontalGradient(colors = listOf(Color(0xFF10B981), Color(0xFF059669)))
                )

                val bannerTitles = listOf(
                    "🏆 RAS Pre-Test Series 2026",
                    "📰 Daily Current Affairs Hub",
                    "⚡ General Science Masterclass"
                )

                val bannerSubtitles = listOf(
                    "पूर्ण सिलेबस मॉक टेस्ट | राजस्थान रैंक के साथ",
                    "दैनिक मुख्य समाचार विश्लेषण एवं महत्वपूर्ण प्रश्नोत्तरी",
                    "CET, REET तथा पटवार हेतु महत्वपूर्ण विज्ञान सूत्र"
                )

                val bannerEmojis = listOf("🎯", "📰", "⚡")

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .padding(horizontal = 20.dp)
                        .shadow(4.dp, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(bannerGradients[currentSlide])
                            .clickable {
                                when (currentSlide) {
                                    0 -> onNavigate("mock_test")
                                    1 -> onNavigate("current_affairs")
                                    2 -> onNavigate("rajasthan_gk")
                                }
                            }
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                text = bannerEmojis[currentSlide],
                                fontSize = 42.sp,
                                modifier = Modifier.padding(end = 16.dp)
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.White.copy(alpha = 0.25f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "विशेष लाइव (Live)",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = bannerTitles[currentSlide],
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = bannerSubtitles[currentSlide],
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Slide dots indicators
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            for (i in 0..2) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (i == currentSlide) Color.White else Color.White.copy(alpha = 0.4f)
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // QUICK ACTION GRID (10 requested items)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "परीक्षा तैयारी प्रभाग (Study Modules)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridItem(
                            title = "राजस्थान GK",
                            subtitle = "भूगोल, कला, इतिहास",
                            icon = Icons.Default.Map,
                            badge = "प्रमुख",
                            color = Saffron,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("rajasthan_gk") }
                        )
                        GridItem(
                            title = "भारत GK",
                            subtitle = "संविधान, इतिहास, विज्ञान",
                            icon = Icons.Default.Public,
                            badge = "विशेषज्ञ",
                            color = RoyalBlue,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("india_gk") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridItem(
                            title = "डेली क्विज़",
                            subtitle = "10 नए सवाल दैनिक",
                            icon = Icons.Default.Quiz,
                            badge = "लाइव",
                            color = Color(0xFF10B981),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.startDailyQuiz()
                                onNavigate("quiz_screen")
                            }
                        )
                        GridItem(
                            title = "मॉक टेस्ट",
                            subtitle = "पूर्ण परीक्षा प्रारूप",
                            icon = Icons.Default.HourglassEmpty,
                            badge = "समय-बद्ध",
                            color = Color(0xFFEF4444),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("mock_test") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridItem(
                            title = "PDF नोट्स",
                            subtitle = "डाउनलोड व पढ़ें ऑफलाइन",
                            icon = Icons.Default.Download,
                            badge = "फ्री",
                            color = Color(0xFF3B82F6),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("pdf_notes") }
                        )
                        GridItem(
                            title = "करंट अफेयर्स",
                            subtitle = "दैनिक समाचार विश्लेषण",
                            icon = Icons.Default.Article,
                            badge = "नवीनतम",
                            color = Color(0xFFF97316),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("current_affairs") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridItem(
                            title = "पुराने पेपर्स",
                            subtitle = "RAS & REET पेपर्स",
                            icon = Icons.Default.History,
                            badge = "हल सहित",
                            color = Color(0xFF8B5CF6),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("previous_papers") }
                        )
                        GridItem(
                            title = "बुकमार्क सूची",
                            subtitle = "बचाए गए महत्वपूर्ण प्रश्न",
                            icon = Icons.Default.Bookmark,
                            badge = "संग्रह",
                            color = Color(0xFFEC4899),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("bookmarks") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GridItem(
                            title = "लीडरबोर्ड",
                            subtitle = "अपनी रैंक जांचें",
                            icon = Icons.Default.Leaderboard,
                            badge = "रैंक",
                            color = AmberGold,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("leaderboard") }
                        )
                        GridItem(
                            title = "प्रोफ़ाइल",
                            subtitle = "मेडल और सिक्के",
                            icon = Icons.Default.AccountCircle,
                            badge = "स्तर",
                            color = Color(0xFF6B7280),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate("profile") }
                        )
                    }
                }
            }
        }

        // PREMIUM & REWARDS BANNER
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp))
                    .clickable { onNavigate("premium_rewards") },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(AmberGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👑", fontSize = 28.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "प्रीमियम & इनाम केंद्र 💎🎁",
                                color = AmberGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                              )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "विज्ञापन हटाएं, असीमित रिवॉर्ड्स क्लेम करें और लकी व्हील घुमाएं!",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "Navigate",
                            tint = AmberGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // DAILY CHALLENGE CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .shadow(3.dp, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Saffron.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = Saffron)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "दैनिक चुनौती (Daily Challenge)",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Saffron)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("+50 XP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "आज का विषय: 'राजस्थान की प्रमुख नदियां और झीलें'। 10 प्रश्नों का सही उत्तर देकर अतिरिक्त सिक्के हासिल करें!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            viewModel.startDailyQuiz()
                            onNavigate("quiz_screen")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("चुनौती स्वीकार करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // CONTINUE LEARNING CARD
        item {
            val lastNote = allNotes.firstOrNull()
            if (lastNote != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .shadow(2.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayCircleFilled, contentDescription = "Play", tint = RoyalBlue, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "पढ़ाई जारी रखें (Continue Learning)",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lastNote.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = lastNote.content,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onNavigate("pdf_notes") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("अभी पढ़ना शुरू करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // RECENT QUIZ
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    text = "हाल ही में हल किए गए क्विज़ (Recent Quizzes)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (results.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "आपने अभी तक कोई टेस्ट नहीं दिया है। अभ्यास शुरू करने के लिए डेली क्विज़ पर क्लिक करें!",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    results.take(2).forEach { result ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(result.quizTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("स्कोर: ${result.correctAnswers}/${result.totalQuestions}", fontSize = 10.sp, color = Color.Gray)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${result.score}/${result.totalQuestions} सही",
                                        color = Color(0xFF10B981),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // LATEST PDF
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    text = "नवीनतम डाउनलोड योग्य PDF (Latest PDF Notes)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                allNotes.take(2).forEach { note ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color.Red, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                 Column {
                                    Text(note.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("श्रेणी: ${note.categoryId}", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                            IconButton(onClick = { onNavigate("pdf_notes") }) {
                                Icon(Icons.Default.Download, contentDescription = "Download", tint = Saffron)
                            }
                        }
                    }
                }
            }
        }

        // LATEST CURRENT AFFAIRS
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    text = "लेटेस्ट करंट अफेयर्स (Latest News)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(currentAffairsList.take(3)) { news ->
                        Card(
                            modifier = Modifier
                                .width(260.dp)
                                .height(130.dp)
                                .clickable { onNavigate("current_affairs") },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Saffron.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(if (news.isMonthly) "मासिक" else "दैनिक", color = Saffron, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(news.date, fontSize = 9.sp, color = Color.Gray)
                                }
                                Text(
                                    text = news.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "आगे पढ़ें >",
                                    color = RoyalBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog displaying real notices
    if (showNotificationDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Saffron)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("महत्वपूर्ण सूचनाएं (Notices)", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    notices.forEach { notice ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = notice,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(12.dp),
                                lineHeight = 18.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showNotificationDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("ठीक है", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun GridItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badge: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(115.dp)
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background glow accent
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .align(Alignment.BottomEnd)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(color.copy(alpha = 0.15f), Color.Transparent)
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(color.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = color,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    if (badge.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(color.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badge,
                                color = color,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                Column {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
