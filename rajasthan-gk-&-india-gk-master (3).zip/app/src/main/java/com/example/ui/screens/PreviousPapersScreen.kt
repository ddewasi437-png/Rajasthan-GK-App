package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PreviousPaper
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun PreviousPapersScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val papersList by viewModel.previousPapers.collectAsState()
    
    var selectedPaperForViewing by remember { mutableStateOf<PreviousPaper?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (selectedPaperForViewing != null) {
            // Simulated Paper Viewer
            SimulatedPaperViewer(
                paper = selectedPaperForViewing!!,
                onClose = { selectedPaperForViewing = null }
            )
        } else {
            // Main lists
            MainAppHeader(
                title = "गत वर्षों के प्रश्न पत्र (Previous Papers)",
                subtitle = "विभिन्न सरकारी भर्ती परीक्षाओं के हल प्रश्न पत्र",
                onBackClick = { viewModel.activeTab = "home" }
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(papersList) { paper ->
                    PreviousPaperRow(
                        paper = paper,
                        onView = { selectedPaperForViewing = paper }
                    )
                }
            }
        }
    }
}

@Composable
fun PreviousPaperRow(
    paper: PreviousPaper,
    onView: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onView),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBox(
                icon = Icons.Default.History,
                contentDescription = paper.examName,
                backgroundColor = Saffron.copy(alpha = 0.12f),
                iconColor = Saffron,
                size = 46.dp
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = paper.examName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "विषय: ${paper.subject}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "वर्ष: ${paper.year}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Saffron
                    )
                    Text(
                        text = "कुल प्रश्न: ${paper.totalQuestions}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = onView) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "View",
                    tint = Saffron
                )
            }
        }
    }
}

@Composable
fun SimulatedPaperViewer(
    paper: PreviousPaper,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = paper.examName,
            subtitle = "परीक्षा वर्ष: ${paper.year} | प्रश्न पत्र हल",
            onBackClick = onClose,
            trailingContent = {
                IconButton(onClick = { /* Simulate PDF download */ }) {
                    Icon(Icons.Default.FileDownload, contentDescription = "Download PDF", tint = Saffron)
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "💡 परीक्षा उपयोगी विश्लेषण",
                            fontWeight = FontWeight.Bold,
                            color = Saffron,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "यह प्रश्न पत्र वास्तविक परीक्षा के प्रश्नों और उत्तर कुंजी पर आधारित है। यहाँ दिए गए समाधान प्रामाणिक पुस्तकों द्वारा सत्यापित किए गए हैं।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            // Demo verified question solutions from previous paper
            item {
                VerifiedQuestionSolution(
                    number = 1,
                    text = "राजस्थान सेवा संघ की स्थापना कहाँ हुई थी?",
                    options = listOf("वर्धा", "अजमेर", "जयपुर", "जोधपुर"),
                    correctAnswer = "वर्धा",
                    explanation = "राजस्थान सेवा संघ की स्थापना वर्ष 1919 में वर्धा (महाराष्ट्र) में विजय सिंह पथिक, रामनारायण चौधरी और हरिभाई किंकर द्वारा की गई थी। वर्ष 1920 में इसे अजमेर स्थानांतरित किया गया था।"
                )
            }

            item {
                VerifiedQuestionSolution(
                    number = 2,
                    text = "विख्यात राजस्थानी लोकगीत 'केसरिया बालम' किस गायकी शैली में गाया जाता है?",
                    options = listOf("मांगणियार", "मांड गायकी", "लंगा शैली", "तालिका शैली"),
                    correctAnswer = "मांड गायकी",
                    explanation = "केसरिया बालम आवो नी पधारो म्हारे देस, राजस्थान का प्रसिद्ध राज्य लोकगीत है, जो मुख्यतः मांड गायन शैली में गाया जाता है। इसे अंतर्राष्ट्रीय ख्याति अल्लाह जिलाई बाई ने दिलाई थी।"
                )
            }

            item {
                VerifiedQuestionSolution(
                    number = 3,
                    text = "भारतीय संविधान की कौन सी अनुसूची नगर पालिकाओं से संबंधित है?",
                    options = "10वीं अनुसूची, 11वीं अनुसूची, 12वीं अनुसूची, 9वीं अनुसूची".split(", "),
                    correctAnswer = "12वीं अनुसूची",
                    explanation = "74वें संविधान संशोधन अधिनियम (1992) द्वारा संविधान में 12वीं अनुसूची जोड़ी गई, जो नगर पालिकाओं की शक्तियों और उत्तरदायित्वों (कुल 18 विषय) से संबंधित है।"
                )
            }
        }
    }
}

@Composable
fun VerifiedQuestionSolution(
    number: Int,
    text: String,
    options: List<String>,
    correctAnswer: String,
    explanation: String
) {
    var showExplanation by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "प्रश्न $number: $text",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            options.forEach { option ->
                val isCorrectOption = option == correctAnswer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (showExplanation && isCorrectOption) Color(0xFFE8F5E9)
                            else Color.Transparent
                        )
                        .border(
                            1.dp,
                            if (showExplanation && isCorrectOption) Color(0xFF2E7D32)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (showExplanation && isCorrectOption) Color(0xFF2E7D32)
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "•",
                            color = if (showExplanation && isCorrectOption) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = option,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (showExplanation && isCorrectOption) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (!showExplanation) {
                Text(
                    text = "सत्यापित समाधान देखें ➜",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clickable { showExplanation = true }
                        .padding(vertical = 4.dp)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE8F5E9).copy(alpha = 0.4f))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AssignmentTurnedIn,
                            contentDescription = "Verified",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "सत्यापित उत्तर: $correctAnswer",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20),
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = explanation,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}
