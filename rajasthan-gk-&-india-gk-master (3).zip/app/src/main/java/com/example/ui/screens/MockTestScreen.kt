package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GradientButton
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun MockTestScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    var selectedExamForInstructions by remember { mutableStateOf<MockExamConfig?>(null) }

    val mockExams = listOf(
        MockExamConfig("ras_pre_mock", "RAS Pre-Exam 2026: Mock-1", "सामान्य अध्ययन (जीएस) - 1", 10, "15 मिनट"),
        MockExamConfig("reet_mock", "REET L-2: Social Studies Mock", "इतिहास, भूगोल, संविधान", 10, "15 मिनट"),
        MockExamConfig("cet_mock", "CET Graduate Level: Mock Test", "मिश्रित सामान्य ज्ञान राजस्थान व भारत", 10, "15 मिनट"),
        MockExamConfig("patwar_mock", "Patwar combined: Live Mock", "जीके, कंप्यूटर और सामान्य विज्ञान", 10, "15 मिनट"),
        MockExamConfig("police_mock", "Rajasthan Police Const. Mock", "महिला एवं बाल अपराध व राजस्थान सामान्य ज्ञान", 10, "15 मिनट")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = "मॉक टेस्ट श्रृंखला (Mock Test Series)",
            subtitle = "राजस्थान और भारतीय परीक्षाओं के वास्तविक पैटर्न पर आधारित",
            onBackClick = { viewModel.activeTab = "home" }
        )

        if (selectedExamForInstructions != null) {
            // Render Instruction Screen
            ExamInstructionsView(
                config = selectedExamForInstructions!!,
                onBack = { selectedExamForInstructions = null },
                onStart = {
                    viewModel.selectedCategory.value = null // Means general/mock test
                    viewModel.startMockTest(15) // Start a 15 minutes test
                    onNavigate("quiz_screen")
                }
            )
        } else {
            // Render Exam List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "Rules", tint = Saffron)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "प्रत्येक टेस्ट वास्तविक समय सीमा और नकारात्मक अंकन (Negative Marking) प्रणाली का अभ्यास करने में मदद करता है।",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                items(mockExams) { exam ->
                    MockExamRow(
                        config = exam,
                        onSelect = { selectedExamForInstructions = exam }
                    )
                }
            }
        }
    }
}

data class MockExamConfig(
    val id: String,
    val title: String,
    val description: String,
    val totalQuestions: Int,
    val duration: String
)

@Composable
fun MockExamRow(
    config: MockExamConfig,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onSelect),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBox(
                icon = Icons.Default.Assignment,
                contentDescription = config.title,
                backgroundColor = Saffron.copy(alpha = 0.12f),
                iconColor = Saffron,
                size = 46.dp
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = config.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = config.description,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Assignment, contentDescription = "QuestionsCount", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${config.totalQuestions} प्रश्न", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HourglassEmpty, contentDescription = "Duration", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(config.duration, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                Icons.Default.PlayArrow,
                contentDescription = "Start",
                tint = Saffron,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun ExamInstructionsView(
    config: MockExamConfig,
    onBack: () -> Unit,
    onStart: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "परीक्षा निर्देश (Instructions)",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = config.title,
                fontSize = 14.sp,
                color = Saffron,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            Divider(color = MaterialTheme.colorScheme.surfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            InstructionLine("📋", "कुल प्रश्न: ${config.totalQuestions} बहुविकल्पीय प्रश्न।")
            InstructionLine("⏱️", "समय सीमा: ${config.duration} मिनट।")
            InstructionLine("🎯", "अंक प्रणाली: प्रत्येक सही उत्तर के लिए +10 अंक।")
            InstructionLine("⚠️", "नकारात्मक अंकन: गलत उत्तर पर नकारात्मक अंकन अनुकरण।")
            InstructionLine("🛑", "पूर्ण स्वतंत्रता: आप किसी भी प्रश्न को छोड़ सकते हैं।")

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("रद्द करें", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onStart,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("शुरू करें ➜", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun InstructionLine(icon: String, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(icon, fontSize = 16.sp)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
            fontWeight = FontWeight.Medium
        )
    }
}
