package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    var progress by remember { mutableStateOf(0f) }
    var logoScale by remember { mutableStateOf(0.7f) }
    var statusText by remember { mutableStateOf("प्रारंभ किया जा रहा है...") }

    // Pulse animation for logo scale
    LaunchedEffect(Unit) {
        animate(
            initialValue = 0.7f,
            targetValue = 1.0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        ) { value, _ ->
            logoScale = value
        }
    }

    // Simulate Initialization (including Firebase/Room sync)
    LaunchedEffect(Unit) {
        val steps = listOf(
            0.1f to "लोकल डेटाबेस स्थापित किया जा रहा है...",
            0.3f to "Firebase सेवाओं का संकलन हो रहा है...",
            0.6f to "अध्ययन सामग्री और टेस्ट लोड किए जा रहे हैं...",
            0.9f to "सुरक्षित प्रमाणीकरण सत्यापित हो रहा है...",
            1.0f to "तैयार!"
        )
        for (step in steps) {
            delay(500)
            progress = step.first
            statusText = step.second
        }
        delay(300)

        // Route routing logic
        if (!viewModel.onboardingCompleted) {
            onNavigate("onboarding")
        } else if (!viewModel.isLoggedIn) {
            onNavigate("login")
        } else if (!viewModel.profileSetupCompleted) {
            onNavigate("profile_setup")
        } else {
            onNavigate("home")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A), // Premium Dark Slate
                        Color(0xFF1E293B)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Animated Logo Box with soft shadow
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .scale(logoScale)
                    .shadow(12.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Saffron, AmberGold)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "GK Master Logo",
                    tint = Color.White,
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // App Name with Royal Typography
            Text(
                text = "GK MASTER",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 2.sp
            )

            Text(
                text = "राजस्थान और भारत सामान्य ज्ञान",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = AmberGold,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Progress Bar & Loading Text
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(280.dp)
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = Saffron,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = statusText,
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Footer / Version
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
        ) {
            Text(
                text = "संस्करण 1.0.0 (Premium) • 100% सुरक्षित क्लाउड बैकअप",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.4f),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun OnboardingScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    var currentPage by remember { mutableStateOf(0) }
    val pageCount = 3

    val pages = listOf(
        OnboardingPageData(
            title = "सर्वश्रेष्ठ राजस्थान GK तैयारी",
            subtitle = "RAS, REET, CET, Patwar, LDC, Police तथा अन्य सभी राजस्थान राज्य स्तरीय प्रतियोगी परीक्षाओं हेतु प्रामाणिक भूगोल, इतिहास, कला-संस्कृति और राजनीतिक नोट्स व प्रश्न बैंक।",
            icon = Icons.Default.Map,
            color = Saffron,
            hindiQuote = "राजस्थान के चप्पे-चप्पे का संपूर्ण ज्ञान"
        ),
        OnboardingPageData(
            title = "व्यापक भारत GK & विज्ञान",
            subtitle = "भारत का संविधान, भूगोल, आधुनिक एवं प्राचीन इतिहास, सामान्य विज्ञान, तर्कशक्ति, और दैनिक करंट अफेयर्स। सभी विषयों का विश्लेषण विशेषज्ञों द्वारा तैयार।",
            icon = Icons.Default.Public,
            color = RoyalBlue,
            hindiQuote = "सफलता की नई बुलंदियों को छूने की तैयारी"
        ),
        OnboardingPageData(
            title = "असीमित मॉक टेस्ट + डेली क्विज़",
            subtitle = "लाइव टाइमर, विस्तृत समाधान रिपोर्ट, नेगेटिव मार्किंग विकल्प, ऑल राजस्थान रैंक लीडरबोर्ड और दैनिक चुनौती स्तर। असीमित अभ्यास से अपनी गति बढ़ाएं।",
            icon = Icons.Default.Quiz,
            color = Color(0xFF10B981),
            hindiQuote = "अभ्यास से ही विजय सुनिश्चित होगी!"
        )
    )

    val currentPageData = pages[currentPage]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Skip Button (at top-right)
        if (currentPage < pageCount - 1) {
            Text(
                text = "छोड़ें (Skip)",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(24.dp)
                    .clickable {
                        viewModel.completeOnboarding()
                        onNavigate("login")
                    }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Elegant Visual Card
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .shadow(8.dp, RoundedCornerShape(32.dp))
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                currentPageData.color,
                                currentPageData.color.copy(alpha = 0.7f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = currentPageData.icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(72.dp)
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Hindi Quote Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(currentPageData.color.copy(alpha = 0.12f))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = currentPageData.hindiQuote,
                    color = currentPageData.color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title
            Text(
                text = currentPageData.title,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Subtitle Description
            Text(
                text = currentPageData.subtitle,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 12.dp)
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Dot Indicator
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until pageCount) {
                    val isSelected = i == currentPage
                    val width = if (isSelected) 24.dp else 8.dp
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(width)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) currentPageData.color
                                else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                            )
                    )
                }
            }
        }

        // Action Bottom Button Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 36.dp, start = 24.dp, end = 24.dp)
        ) {
            Button(
                onClick = {
                    if (currentPage < pageCount - 1) {
                        currentPage++
                    } else {
                        viewModel.completeOnboarding()
                        onNavigate("login")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = currentPageData.color
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (currentPage == pageCount - 1) "पढ़ना शुरू करें (Start Learning)" else "अगला (Next)",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Next",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

data class OnboardingPageData(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val hindiQuote: String
)
