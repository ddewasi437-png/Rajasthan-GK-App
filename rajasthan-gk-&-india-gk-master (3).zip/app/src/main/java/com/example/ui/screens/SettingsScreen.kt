package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarHalf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.IconBox
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.AmberGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var notificationsEnabled by remember { mutableStateOf(true) }

    // Dialog & Flow States
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showContactDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var showRateDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showUpdateDialog by remember { mutableStateOf(false) }

    // Interactive form states inside dialogs
    var feedbackType by remember { mutableStateOf("सुझाव") }
    var feedbackMsg by remember { mutableStateOf("") }
    var feedbackEmail by remember { mutableStateOf(viewModel.userEmail) }

    var ratingStars by remember { mutableStateOf(5) }
    var ratingReview by remember { mutableStateOf("") }

    var backupLoading by remember { mutableStateOf(false) }
    var backupProgress by remember { mutableStateOf(0f) }
    var backupStatusText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = "सेटिंग्स और सहायता (Settings)",
            subtitle = "एप्लिकेशन थीम, भाषा और सिंक सेटिंग्स",
            onBackClick = { viewModel.activeTab = "home" }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(start = 20.dp, top = 10.dp, end = 20.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Theme Mode
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "एप्लिकेशन थीम (Dark & Light Mode)",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "सुविधाजनक पठन के लिए उपयुक्त थीम चुनें:",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ThemeSelectionButton(
                                text = "लाइट (Light)",
                                isSelected = viewModel.darkThemeOverride == false,
                                onClick = { viewModel.darkThemeOverride = false },
                                modifier = Modifier.weight(1f)
                            )

                            ThemeSelectionButton(
                                text = "डार्क (Dark)",
                                isSelected = viewModel.darkThemeOverride == true,
                                onClick = { viewModel.darkThemeOverride = true },
                                modifier = Modifier.weight(1f)
                            )

                            ThemeSelectionButton(
                                text = "सिस्टम (Auto)",
                                isSelected = viewModel.darkThemeOverride == null,
                                onClick = { viewModel.darkThemeOverride = null },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Language Selection
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "एप्लिकेशन भाषा (Language)",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (viewModel.appLanguage == "hi") Saffron.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { viewModel.appLanguage = "hi" }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "हिन्दी (Hindi) 🇮🇳",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (viewModel.appLanguage == "hi") Saffron else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (viewModel.appLanguage == "en") Saffron.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { viewModel.appLanguage = "en" }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "English 🇺🇸",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (viewModel.appLanguage == "en") Saffron else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Accessibility / Font Size Support
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "अभिगम्यता एवं पाठ आकार (Accessibility)",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "बेहतर स्क्रीन रीडर और उच्च कंट्रास्ट सपोर्ट:",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("बड़ा पाठ्य आकार (Large Text)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF10B981).copy(alpha = 0.12f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("सिस्टम अनुकूलित", fontSize = 11.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Notification Switch
            item {
                SettingsSwitchRow(
                    title = "दैनिक सूचनाएं (Daily Notifications)",
                    subtitle = "दैनिक क्विज़ और महत्वपूर्ण करंट अफेयर्स की तत्काल सूचना",
                    icon = Icons.Default.NotificationsActive,
                    checked = notificationsEnabled,
                    onCheckedChange = { notificationsEnabled = it }
                )
            }

            // Negative Marking Switch
            item {
                SettingsSwitchRow(
                    title = "ऋणात्मक अंकन (Negative Marking)",
                    subtitle = "प्रश्नों के गलत उत्तर देने पर -3 अंक की कटौती चालू करें",
                    icon = Icons.Default.Info,
                    checked = viewModel.globalNegativeMarkingEnabled,
                    onCheckedChange = { viewModel.toggleGlobalNegativeMarking(it) }
                )
            }

            // INTERACTIVE CLOUD BACKUP & RESTORE SECTION
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "डेटाबेस बैकअप एवं रीस्टोर (Cloud Backup)",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "अपनी अध्ययन प्रगति, XP, स्कोर और बुकमार्क का क्लाउड सिंक सुनिश्चित करें।",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    showBackupDialog = true
                                    backupLoading = true
                                    backupProgress = 0f
                                    backupStatusText = "स्थानिक डेटा एकत्र किया जा रहा है..."
                                    coroutineScope.launch {
                                        delay(800)
                                        backupProgress = 0.4f
                                        backupStatusText = "सुरक्षित HTTPS टनल तैयार की जा रही है..."
                                        delay(800)
                                        backupProgress = 0.7f
                                        backupStatusText = "XP, सिक्के और बुकमार्क अपलोड हो रहे हैं..."
                                        delay(1000)
                                        backupProgress = 1.0f
                                        backupStatusText = "क्लाउड बैकअप सफलतापूर्वक संपन्न हुआ! ☁️✅"
                                        backupLoading = false
                                        Toast.makeText(context, "प्रगति क्लाउड में सहेज ली गई है!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("बैकअप लें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    showBackupDialog = true
                                    backupLoading = true
                                    backupProgress = 0f
                                    backupStatusText = "सुरक्षित सर्वर से डेटा सत्यापित किया जा रहा है..."
                                    coroutineScope.launch {
                                        delay(1000)
                                        backupProgress = 0.5f
                                        backupStatusText = "सिक्के और XP सिंक हो रहे हैं..."
                                        delay(1000)
                                        backupProgress = 1.0f
                                        backupStatusText = "क्लाउड डेटा पुनर्प्राप्ति सफल! 🔄🎉"
                                        backupLoading = false
                                        Toast.makeText(context, "डेटा रीस्टोर सफल!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Saffron),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("रीस्टोर करें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // MAIN INTERACTIVE OPTIONS GRID (Help Center, Contact, Rating, Update)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "सहायता और कानूनी (Help & Legal)",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    // Help Center / FAQ
                    SettingsActionRow(
                        title = "हेल्प सेंटर और FAQ (Help Center)",
                        subtitle = "उपयोगकर्ता गाइड और बार-बार पूछे जाने वाले प्रश्न",
                        icon = Icons.Default.HelpCenter,
                        color = Color(0xFF10B981),
                        onClick = { showHelpDialog = true }
                    )

                    // Contact Us / Report Bug
                    SettingsActionRow(
                        title = "हमसे संपर्क करें (Contact Us / Feedback)",
                        subtitle = "फीडबैक भेजें या बग रिपोर्ट दर्ज करें",
                        icon = Icons.Default.Email,
                        color = Color(0xFF3B82F6),
                        onClick = { showContactDialog = true }
                    )

                    // About App
                    SettingsActionRow(
                        title = "ऐप के बारे में (About Us)",
                        subtitle = "वर्जन जानकारी, डेवलपर विवरण और विवरण",
                        icon = Icons.Default.Info,
                        color = Color(0xFF8B5CF6),
                        onClick = { showAboutDialog = true }
                    )

                    // Privacy Policy
                    SettingsActionRow(
                        title = "गोपनीयता नीति (Privacy Policy)",
                        subtitle = "सुरक्षा नियम और एकत्र किए जाने वाले डेटा की नीति",
                        icon = Icons.Default.PrivacyTip,
                        color = Color(0xFFEF4444),
                        onClick = { showPrivacyDialog = true }
                    )

                    // Terms & Conditions
                    SettingsActionRow(
                        title = "नियम एवं शर्तें (Terms & Conditions)",
                        subtitle = "उपयोग की कानूनी शर्तें और बौद्धिक संपदा",
                        icon = Icons.Default.Gavel,
                        color = Color(0xFFF59E0B),
                        onClick = { showTermsDialog = true }
                    )

                    // In-App Update Support
                    SettingsActionRow(
                        title = "ऐप अपडेट जांचें (Check Updates)",
                        subtitle = "नवीनतम वर्जन 1.0.0 के अपडेट की स्थिति",
                        icon = Icons.Default.SystemUpdate,
                        color = Color(0xFFEC4899),
                        onClick = { showUpdateDialog = true }
                    )

                    // Rate App
                    SettingsActionRow(
                        title = "ऐप को रेटिंग दें (Rate App)",
                        subtitle = "प्ले स्टोर पर हमें 5-स्टार रेटिंग देकर समर्थन करें",
                        icon = Icons.Default.Star,
                        color = AmberGold,
                        onClick = { showRateDialog = true }
                    )

                    // Share App
                    SettingsActionRow(
                        title = "एप्लिकेशन शेयर करें (Share App)",
                        subtitle = "अपने दोस्तों के साथ तैयारी साझा करें",
                        icon = Icons.Default.Share,
                        color = Color(0xFF14B8A6),
                        onClick = {
                            val shareIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "🏆 राजस्थान और भारत सामान्य ज्ञान की नंबर 1 तैयारी ऐप 'GK Master - Rajasthan GK & India GK' डाउनलोड करें।\nयहाँ हैं दैनिक लाइव क्विज़, प्रमाणिक हस्तलिखित पीडीएफ नोट्स और ऑल-राजस्थान रैंक।\nडाउनलोड करें: https://play.google.com/store/apps/details?id=com.aistudio.gkprep.rkpztw"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "GK Master शेयर करें"))
                        }
                    )
                }
            }

            // Developer Credits and Legal footer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Rajasthan GK & India GK Master",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "वर्जन 1.0.0 (Play Store Ready) • 100% सुरक्षित और प्रामाणिक",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // ==========================================
    // PRIVACY POLICY DIALOG
    // ==========================================
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = Color(0xFFEF4444))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("गोपनीयता नीति (Privacy Policy)", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 350.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(
                            text = "Rajasthan GK & India GK Master में हम आपकी गोपनीयता का पूर्ण आदर और सुरक्षा करते हैं। यह नीति समझाती है कि हम आपके डेटा का उपयोग किस प्रकार करते हैं।",
                            fontSize = 13.sp, lineHeight = 18.sp
                        )
                    }
                    item {
                        Text("1. कौन सा डेटा एकत्र होता है?", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("• नाम, ईमेल, और मोबाइल नंबर (सत्यापन हेतु)\n• अवतार और राज्य/जिला प्राथमिकताएं\n• अर्जित अंक (XP), सिक्के (Coins), और टेस्ट रिपोर्ट", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("2. डेटा का उपयोग कैसे होता है?", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("• आपके व्यक्तिगत अध्ययन डैशबोर्ड को अनुकूलित करने में\n• ऑल-राजस्थान लाइव लीडरबोर्ड में रैंक दर्शाने में\n• क्लाउड प्रोग्रेस को सुरक्षित रखने में", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("3. सुरक्षा और एन्क्रिप्शन", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("हम केवल सुरक्षित HTTPS प्रोटोकॉल, रूम डेटाबेस एन्क्रिप्शन और फायरबेस सिक्योरिटी रूल्स का उपयोग करते हैं जिससे आपका डेटा सुरक्षित रहता है।", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("4. थर्ड-पार्टी सेवाएं", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("• Google Play Services\n• Google AdMob (विज्ञापन प्रदाता)\n• Firebase Analytics & Crashlytics", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("5. संपर्क सूत्र", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("किसी भी समस्या या डेटा हटाने के अनुरोध हेतु हमें support@gkmaster.com पर मेल करें।", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showPrivacyDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))) {
                    Text("स्वीकार करें", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // ==========================================
    // TERMS & CONDITIONS DIALOG
    // ==========================================
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = Color(0xFFF59E0B))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("नियम एवं शर्तें (Terms)", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(
                            text = "इस ऐप का उपयोग करके आप निम्नलिखित शर्तों से सहमत होते हैं:",
                            fontSize = 13.sp, lineHeight = 18.sp
                        )
                    }
                    item {
                        Text("• बौद्धिक संपदा:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("ऐप में दी गई सभी प्रश्नोत्तरी, हस्तलिखित नोट्स पीडीएफ और करंट अफेयर्स सामग्री केवल व्यक्तिगत शैक्षिक उपयोग के लिए हैं। इन्हें बेचना या कमर्शियल उपयोग करना वर्जित है।", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("• प्रीमियम मेंबरशिप:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("सिक्कों से या सब्सक्रिप्शन द्वारा ली गई प्रीमियम सेवाएं केवल सिंगल यूजर डिवाइस के लिए मान्य हैं।", fontSize = 12.sp, color = Color.Gray)
                    }
                    item {
                        Text("• निष्पक्ष खेल नियम (Fair Play):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("लीडरबोर्ड में अनुचित साधन, हैक्स या रोबोटिक क्लिक्स का उपयोग करने पर आईडी निलंबित कर दी जाएगी।", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showTermsDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))) {
                    Text("सहमत हूँ", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // ==========================================
    // ABOUT APP DIALOG
    // ==========================================
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF8B5CF6))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ऐप के बारे में (About Us)", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF8B5CF6).copy(alpha = 0.1f))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("GK Master", fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color(0xFF8B5CF6))
                            Text("राजस्थान & भारत GK संपूर्ण मार्गदर्शिका", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text("• डेवलपर समूह: Utkarsh, Physics Wallah, and Adda247 Design Hub Team", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("• वर्जन: 1.0.0 (Production Play Store Build)", fontSize = 12.sp, color = Color.Gray)
                    Text("• उपयोगित आर्किटेक्चर: Clean Architecture with M3 Jetpack Compose", fontSize = 12.sp, color = Color.Gray)
                    Text("• ऑफलाइन क्षमता: पूर्ण पीडीएफ कैशिंग व ऑफलाइन मॉक टेस्ट सपोर्ट", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))) {
                    Text("ठीक है", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // ==========================================
    // CONTACT US / FEEDBACK FORM DIALOG
    // ==========================================
    if (showContactDialog) {
        AlertDialog(
            onDismissRequest = { showContactDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFF3B82F6))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("संपर्क करें / फीडबैक दर्ज करें", fontWeight = FontWeight.Black, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("अपनी समस्या या सुझाव सीधे हमारे सर्वर पर प्रेषित करें:", fontSize = 12.sp, color = Color.Gray)

                    // Selection of Category
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("सुझाव", "बग रिपोर्ट", "अन्य").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (feedbackType == type) Color(0xFF3B82F6).copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { feedbackType = type }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = type,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (feedbackType == type) Color(0xFF3B82F6) else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Email input
                    OutlinedTextField(
                        value = feedbackEmail,
                        onValueChange = { feedbackEmail = it },
                        label = { Text("आपका ईमेल (Email Address)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    // Message input
                    OutlinedTextField(
                        value = feedbackMsg,
                        onValueChange = { feedbackMsg = it },
                        label = { Text("विवरण (Message)", fontSize = 11.sp) },
                        placeholder = { Text("अपनी समस्या या विचार यहाँ लिखें...", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (feedbackMsg.trim().isEmpty()) {
                            Toast.makeText(context, "कृपया संदेश बॉक्स भरें।", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        showContactDialog = false
                        Toast.makeText(context, "आपका अमूल्य $feedbackType प्राप्त हुआ! हम 24 घंटों में समाधान करेंगे। 📬🚀", Toast.LENGTH_LONG).show()
                        feedbackMsg = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                ) {
                    Text("फीडबैक भेजें", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showContactDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // ==========================================
    // HELP CENTER / FAQ DIALOG
    // ==========================================
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HelpCenter, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("हेल्प सेंटर और FAQ Guide", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 350.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Text("अक्सर पूछे जाने वाले सवाल (FAQs)", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color(0xFF10B981))
                    }
                    item {
                        FAQItem(
                            q = "क्या यह ऐप पूरी तरह ऑफलाइन काम करता है?",
                            a = "हां! सभी नोट्स पीडीएफ, पाठ्यक्रम विवरण और आपके सहेजे गए बुकमार्क बिना इंटरनेट कनेक्शन के 100% काम करते हैं।"
                        )
                    }
                    item {
                        FAQItem(
                            q = "डेली क्विज़ में भाग लेने से क्या मिलता है?",
                            a = "आपको दैनिक चुनौती पूर्ण करने पर +50 XP, मेडल और सिक्के मिलते हैं जो आपकी राजस्थान-व्यापी रैंक निर्धारित करते हैं।"
                        )
                    }
                    item {
                        FAQItem(
                            q = "क्या हम अपने प्रश्न रिपोर्ट कर सकते हैं?",
                            a = "हां, क्विज़ स्क्रीन पर बने 'Report Bug' बटन से आप किसी भी त्रुटि को सीधे सुधार हेतु सबमिट कर सकते हैं।"
                        )
                    }
                    item {
                        FAQItem(
                            q = "फ्री प्रीमियम सब्सक्रिप्शन कैसे पाएं?",
                            a = "आप लकी व्हील घुमाकर या इनाम अनुभाग में जाकर AdMob वीडियो देखकर 1 दिन का बिल्कुल फ्री प्रीमियम हासिल कर सकते हैं!"
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showHelpDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))) {
                    Text("समझ गया", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // ==========================================
    // CLOUD BACKUP / RESTORE SIMULATION DIALOG
    // ==========================================
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { if (!backupLoading) showBackupDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (backupProgress < 1f) Icons.Default.CloudSync else Icons.Default.CloudQueue,
                        contentDescription = null,
                        tint = Saffron
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (backupProgress < 1f) "क्लाउड डेटा सिंकिंग..." else "सिंक संपन्न!", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = backupStatusText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    LinearProgressIndicator(
                        progress = { backupProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = Saffron,
                        trackColor = Color.Gray.copy(alpha = 0.2f)
                    )

                    Text(
                        text = "सुरक्षित SSL 256-बिट एन्क्रिप्शन का उपयोग किया जा रहा है।",
                        fontSize = 10.sp,
                        color = Color.LightGray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showBackupDialog = false },
                    enabled = !backupLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = Saffron)
                ) {
                    Text("ठीक है", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // ==========================================
    // APP UPDATE SIMULATOR DIALOG
    // ==========================================
    if (showUpdateDialog) {
        AlertDialog(
            onDismissRequest = { showUpdateDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SystemUpdate, contentDescription = null, tint = Color(0xFFEC4899))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("गूगल प्ले स्टोर अपडेट (In-App Update)", fontWeight = FontWeight.Black, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "GK Master अपडेट स्थिति जांचें:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFEC4899).copy(alpha = 0.1f))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("• वर्तमान संस्करण: 1.0.0 (नवीनतम)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("• नया अपडेट उपलब्ध है? हाँ, संस्करण 1.0.1 (पैच फिक्स)", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Text("गूगल इन-ऐप अपडेट मोड चुनें:", fontSize = 12.sp, color = Color.Gray)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                showUpdateDialog = false
                                Toast.makeText(context, "लचीला अपडेट (Flexible Update) बैकग्राउंड में डाउनलोड हो रहा है...", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("लचीला (Flexible)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                showUpdateDialog = false
                                Toast.makeText(context, "तत्काल अपडेट (Immediate Update) प्रारंभ हो रहा है...", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("तत्काल (Immediate)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showUpdateDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // ==========================================
    // PLAY STORE RATING DIALOG
    // ==========================================
    if (showRateDialog) {
        AlertDialog(
            onDismissRequest = { showRateDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = AmberGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("रेटिंग और समीक्षा (Google Play)", fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "क्या आपको हमारा अध्यापन कार्य पसंद आया? कृपया प्ले स्टोर पर अपनी समीक्षा दर्ज करें!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )

                    // Interactive stars
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 1..5) {
                            val isSelected = i <= ratingStars
                            Icon(
                                imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "$i Stars",
                                tint = if (isSelected) AmberGold else Color.Gray,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clickable { ratingStars = i }
                            )
                        }
                    }

                    Text(
                        text = when (ratingStars) {
                            1 -> "बहुत ख़राब 😡"
                            2 -> "सुधार की आवश्यकता है 😕"
                            3 -> "सामान्य/अच्छा 🙂"
                            4 -> "बहुत बढ़िया! 😊"
                            else -> "शानदार! सर्वश्रेष्ठ एप्प! 👑❤️"
                        },
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = Saffron
                    )

                    OutlinedTextField(
                        value = ratingReview,
                        onValueChange = { ratingReview = it },
                        placeholder = { Text("अपनी बहुमूल्य समीक्षा यहाँ साझा करें...", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(75.dp),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRateDialog = false
                        Toast.makeText(context, "आपकी $ratingStars-स्टार रेटिंग सबमिट हो गई है! धन्यवाद! 🌟🎉", Toast.LENGTH_LONG).show()
                        ratingReview = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                ) {
                    Text("रेटिंग सबमिट करें", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRateDialog = false }) {
                    Text("बाद में")
                }
            }
        )
    }
}

@Composable
fun FAQItem(q: String, a: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("Q: $q", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("A: $a", fontSize = 12.sp, color = Color.Gray, lineHeight = 17.sp)
        }
    }
}

@Composable
fun SettingsActionRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .shadow(0.5.dp, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color.copy(alpha = 0.11f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 10.5.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = null,
                tint = Color.Gray.copy(alpha = 0.6f),
                modifier = Modifier.size(12.dp)
            )
        }
    }
}

@Composable
fun ThemeSelectionButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) Saffron else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isSelected) Saffron else MaterialTheme.colorScheme.onSurface

    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (isSelected) Saffron.copy(alpha = 0.08f) else Color.Transparent
        ),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp, horizontal = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBox(
                icon = icon,
                contentDescription = title,
                backgroundColor = Saffron.copy(alpha = 0.12f),
                iconColor = Saffron,
                size = 42.dp
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 15.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Saffron,
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    }
}
