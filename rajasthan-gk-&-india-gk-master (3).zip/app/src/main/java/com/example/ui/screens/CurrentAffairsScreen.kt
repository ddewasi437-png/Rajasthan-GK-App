package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CurrentAffair
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun CurrentAffairsScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val affairsList by viewModel.currentAffairs.collectAsState()
    
    var selectedAffairForReading by remember { mutableStateOf<CurrentAffair?>(null) }
    var showMonthlyTab by remember { mutableStateOf(false) }

    val filteredList = affairsList.filter { it.isMonthly == showMonthlyTab }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (selectedAffairForReading != null) {
            // Render full current affair view
            FullAffairDetailView(
                affair = selectedAffairForReading!!,
                viewModel = viewModel,
                onClose = { selectedAffairForReading = null }
            )
        } else {
            // Header
            MainAppHeader(
                title = "दैनिक सामयिकी (Current Affairs)",
                subtitle = "परीक्षा उपयोगी समसामयिक घटनाओं का दैनिक संकलन",
                onBackClick = { viewModel.activeTab = "home" }
            )

            // Tabs (Daily vs Monthly)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (!showMonthlyTab) Saffron else Color.Transparent)
                        .clickable { showMonthlyTab = false }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "दैनिक अपडेट (Daily)",
                        color = if (!showMonthlyTab) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (showMonthlyTab) Saffron else Color.Transparent)
                        .clickable { showMonthlyTab = true }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "मासिक पत्रिका (Monthly)",
                        color = if (showMonthlyTab) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            // Timeline
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (filteredList.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("कोई डेटा उपलब्ध नहीं है।", color = Color.Gray)
                        }
                    }
                } else {
                    items(filteredList) { affair ->
                        AffairCard(
                            affair = affair,
                            onClick = { selectedAffairForReading = affair }
                        )
                    }
                }

                // Simulated AdBanner on Current Affairs Screen (Part 6)
                item {
                    com.example.ui.components.SimulatedAdBanner(viewModel = viewModel, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }
}

@Composable
fun AffairCard(
    affair: CurrentAffair,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = affair.date,
                    color = Saffron,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Saffron.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (affair.isMonthly) "मासिक सार" else "दैनिक सार",
                        color = Saffron,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = affair.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = affair.description,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "पूरा विवरण पढ़ें ➜",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun FullAffairDetailView(
    affair: CurrentAffair,
    viewModel: GKViewModel,
    onClose: () -> Unit
) {
    var isBookmarked by remember { mutableStateOf(false) }

    LaunchedEffect(affair.id) {
        isBookmarked = viewModel.isBookmarked("a_${affair.id}")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = "करंट अफेयर्स विवरण",
            subtitle = affair.date,
            onBackClick = onClose,
            trailingContent = {
                Row {
                    IconButton(
                        onClick = {
                            isBookmarked = !isBookmarked
                            viewModel.toggleBookmark(
                                id = "a_${affair.id}",
                                type = "AFFAIR",
                                title = affair.title,
                                categoryId = "current_affairs",
                                contentJson = ""
                            )
                        }
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = Saffron
                        )
                    }

                    IconButton(onClick = { /* Share simulated link */ }) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = Saffron)
                    }
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = affair.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground,
                    lineHeight = 28.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = Saffron.copy(alpha = 0.3f))
            }

            item {
                Text(
                    text = affair.content,
                    fontSize = 16.sp,
                    lineHeight = 26.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
