package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LeaderboardEntry
import com.example.ui.components.CustomAvatar
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.AmberGold
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun LeaderboardScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val rankingList by viewModel.leaderboard.collectAsState()
    val results by viewModel.userResults.collectAsState()
    
    val totalUserScore = results.sumOf { it.score }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        MainAppHeader(
            title = "राज्य स्तरीय लीडरबोर्ड",
            subtitle = "राजस्थान जीके मास्टर परीक्षा योद्धाओं की साप्ताहिक रैंकिंग",
            onBackClick = { viewModel.activeTab = "home" }
        )

        // Top 3 Podium Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            val secondPlace = rankingList.getOrNull(1)
            val firstPlace = rankingList.getOrNull(0)
            val thirdPlace = rankingList.getOrNull(2)

            // Rank 2
            if (secondPlace != null) {
                PodiumCard(
                    entry = secondPlace,
                    podiumColor = Color(0xFFC0C0C0), // Silver
                    height = 140.dp,
                    scaleSize = 0.9f,
                    modifier = Modifier.weight(1f)
                )
            }

            // Rank 1
            if (firstPlace != null) {
                PodiumCard(
                    entry = firstPlace,
                    podiumColor = AmberGold, // Gold
                    height = 170.dp,
                    scaleSize = 1.1f,
                    modifier = Modifier.weight(1.1f)
                )
            }

            // Rank 3
            if (thirdPlace != null) {
                PodiumCard(
                    entry = thirdPlace,
                    podiumColor = Color(0xFFCD7F32), // Bronze
                    height = 130.dp,
                    scaleSize = 0.85f,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Remaining Standings List
        val remainingStandings = rankingList.drop(3)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(start = 20.dp, top = 6.dp, end = 20.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(remainingStandings) { entry ->
                LeaderboardRow(entry = entry)
            }
        }

        // Current User standing anchored card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "8", // Mock user rank
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = Saffron,
                    modifier = Modifier.width(30.dp)
                )

                CustomAvatar(avatarId = viewModel.userAvatar, size = 42.dp)

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${viewModel.userName} (आप)",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "जिला: ${viewModel.userDistrict}",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = "Points", tint = AmberGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$totalUserScore XP",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PodiumCard(
    entry: LeaderboardEntry,
    podiumColor: Color,
    height: androidx.compose.ui.unit.Dp,
    scaleSize: Float,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(height)
            .shadow(2.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Custom rank icon
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(podiumColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = entry.rank.toString(),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                CustomAvatar(avatarId = entry.avatarId, size = (38 * scaleSize).dp)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = entry.name.substringBefore(" "), // Show first name only for podium
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = entry.district,
                    fontSize = 10.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(podiumColor.copy(alpha = 0.12f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${entry.score}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (podiumColor == AmberGold) Saffron else podiumColor,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun LeaderboardRow(
    entry: LeaderboardEntry
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank Number
            Text(
                text = entry.rank.toString(),
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = Color.Gray,
                modifier = Modifier.width(30.dp),
                textAlign = TextAlign.Center
            )

            CustomAvatar(avatarId = entry.avatarId, size = 42.dp)

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.name,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "जिला: ${entry.district}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = "Points", tint = AmberGold, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${entry.score} XP",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
