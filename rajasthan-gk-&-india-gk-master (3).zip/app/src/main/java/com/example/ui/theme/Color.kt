package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Royal Saffron / Gold Rajasthani Palette
val Saffron = Color(0xFFFF7F32)
val AmberGold = Color(0xFFFFB300)
val DarkGold = Color(0xFFC58B00)
val RoyalBlue = Color(0xFF1E40AF)
val DeepIndigo = Color(0xFF0D1127)

// Dark Theme Colors
val DarkBackground = Color(0xFF080B16)
val DarkSurface = Color(0xFF13192E)
val DarkSurfaceVariant = Color(0xFF1C2442)
val DarkOnPrimary = Color(0xFFFFFFFF)
val DarkOnBackground = Color(0xFFE5E9F0)
val DarkOnSurface = Color(0xFFECEFF4)

// Light Theme Colors
val LightBackground = Color(0xFFFAF7F2) // Soft warm ivory
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF3EEE3)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF1E222B)
val LightOnSurface = Color(0xFF262D3D)
val AccentOrange = Color(0xFFE65100)
val AccentGreen = Color(0xFF2E7D32)
val AccentRed = Color(0xFFC62828)
