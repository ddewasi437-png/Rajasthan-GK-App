package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GkQuestion
import com.example.ui.components.GradientButton
import com.example.ui.components.MainAppHeader
import com.example.ui.theme.AmberGold
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@Composable
fun QuizScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val questions = viewModel.quizQuestions.value
    val currentIndex = viewModel.currentQuestionIndex
    val timerSeconds = viewModel.quizTimerSeconds
    val isFinished = viewModel.quizFinished

    // UI State: "START", "PLAYING", "CONFIRM_SUBMIT", "RESULT", "REVIEW_ANSWERS", "ANALYSIS"
    var screenState by remember { mutableStateOf("START") }

    // Synchronize quiz completion with state change
    LaunchedEffect(isFinished) {
        if (isFinished) {
            screenState = "RESULT"
        }
    }

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Saffron)
                Spacer(modifier = Modifier.height(16.dp))
                Text("प्रश्नों को लोड किया जा रहा है...", color = Color.Gray)
            }
        }
        return
    }

    val currentQuestion = questions.getOrNull(currentIndex) ?: questions[0]
    var isBookmarkedState by remember(currentQuestion.id) { mutableStateOf(false) }

    LaunchedEffect(currentQuestion.id) {
        isBookmarkedState = viewModel.isBookmarked("q_${currentQuestion.id}")
    }

    when (screenState) {
        "START" -> {
            QuizStartView(
                quizName = viewModel.quizName,
                quizType = viewModel.quizType,
                totalQuestions = questions.size,
                totalMarks = viewModel.totalMarks,
                negativeMarking = viewModel.isNegativeMarkingEnabled,
                timeLimitMinutes = viewModel.quizTimeLimitSeconds / 60,
                difficulty = viewModel.difficultyLevel,
                onStartClick = {
                    screenState = "PLAYING"
                },
                onBackClick = {
                    viewModel.activeTab = "home"
                    onNavigate("home")
                }
            )
        }

        "PLAYING" -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                MainAppHeader(
                    title = viewModel.quizName,
                    subtitle = if (timerSeconds > 0) {
                        "समय शेष: ${timerSeconds / 60}:${String.format("%02d", timerSeconds % 60)}"
                    } else {
                        "शानदार अभ्यास मोड"
                    },
                    onBackClick = {
                        screenState = "START"
                    },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Bookmark toggle button
                            IconButton(
                                onClick = {
                                    isBookmarkedState = !isBookmarkedState
                                    viewModel.toggleBookmark(
                                        id = "q_${currentQuestion.id}",
                                        type = "QUESTION",
                                        title = currentQuestion.questionText,
                                        categoryId = currentQuestion.categoryId,
                                        contentJson = ""
                                    )
                                    Toast.makeText(
                                        context,
                                        if (isBookmarkedState) "बुकमार्क जोड़ा गया" else "बुकमार्क हटाया गया",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            ) {
                                Icon(
                                    imageVector = if (isBookmarkedState) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = Saffron,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            // Share Question
                            IconButton(
                                onClick = {
                                    Toast.makeText(context, "प्रश्न साझा किया गया! 📲", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share Question",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                )

                // Progress Bar
                val progress = (currentIndex + 1).toFloat() / questions.size
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp),
                    color = Saffron,
                    trackColor = Saffron.copy(alpha = 0.15f)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Question Status
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    contentColor = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Text(
                                        text = "प्रश्न ${currentIndex + 1} / ${questions.size}",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (viewModel.markedForReview.contains(currentIndex)) {
                                    Badge(
                                        containerColor = Color(0xFFE65100).copy(alpha = 0.15f),
                                        contentColor = Color(0xFFE65100)
                                    ) {
                                        Text(
                                            text = "पुनरावलोकन (Review)",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Running Score
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FlashOn, contentDescription = "XP", tint = AmberGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "XP: ${viewModel.userXP}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Specialized UI based on Question Type (IMAGE, MATCH, TF, MCQ)
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(3.dp, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                // If question contains an image
                                if (currentQuestion.questionType == "IMAGE") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                Brush.verticalGradient(
                                                    colors = listOf(Color(0xFFE0F2F1), Color(0xFFB2DFDB))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Default.Map,
                                                contentDescription = "Map Image",
                                                tint = Color(0xFF00796B),
                                                modifier = Modifier.size(48.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                "भौतिक मानचित्र संदर्भ चित्र",
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF004D40),
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(14.dp))
                                }

                                Text(
                                    text = currentQuestion.questionText,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 24.sp
                                    )
                                )

                                // If Match the Following columns
                                if (currentQuestion.questionType == "MATCH") {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                            .padding(12.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("स्तंभ X (Left Column)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Saffron)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(currentQuestion.matchPairsLeft, fontSize = 13.sp, lineHeight = 20.sp)
                                        }
                                        Divider(modifier = Modifier.width(1.dp).height(80.dp).align(Alignment.CenterVertically))
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("स्तंभ Y (Right Column)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(currentQuestion.matchPairsRight, fontSize = 13.sp, lineHeight = 20.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Options list
                    item {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val selected = viewModel.userAnswers[currentIndex]
                            
                            OptionRow(
                                key = "A",
                                text = currentQuestion.optionA,
                                isSelected = selected == "A",
                                onClick = { viewModel.selectEngineOption("A") }
                            )

                            OptionRow(
                                key = "B",
                                text = currentQuestion.optionB,
                                isSelected = selected == "B",
                                onClick = { viewModel.selectEngineOption("B") }
                            )

                            // Show only option C and D if not True / False Type
                            if (currentQuestion.questionType != "TF") {
                                OptionRow(
                                    key = "C",
                                    text = currentQuestion.optionC,
                                    isSelected = selected == "C",
                                    onClick = { viewModel.selectEngineOption("C") }
                                )

                                OptionRow(
                                    key = "D",
                                    text = currentQuestion.optionD,
                                    isSelected = selected == "D",
                                    onClick = { viewModel.selectEngineOption("D") }
                                )
                            }
                        }
                    }

                    // Report Question Utility
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    Toast.makeText(context, "इस प्रश्न की रिपोर्ट एडमिन पैनल को भेज दी गई है। धन्यवाद!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Flag, contentDescription = "Report", tint = Color.Gray.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("प्रश्न में कोई त्रुटि रिपोर्ट करें (Report Error)", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                // Controls Navigation Panel
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Prev Button
                            OutlinedButton(
                                onClick = { viewModel.prevEngineQuestion() },
                                enabled = currentIndex > 0,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Prev")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("पीछे (Prev)")
                            }

                            // Mark for Review Button
                            Button(
                                onClick = { viewModel.toggleMarkForReview(currentIndex) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (viewModel.markedForReview.contains(currentIndex)) Color(0xFFE65100) else Color(0xFFFF9800)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (viewModel.markedForReview.contains(currentIndex)) Icons.Default.Check else Icons.Default.Help,
                                    contentDescription = "Review",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("रिव्यू")
                            }

                            // Next Button / Skip Button
                            Button(
                                onClick = {
                                    if (currentIndex < questions.size - 1) {
                                        viewModel.nextEngineQuestion()
                                    } else {
                                        screenState = "CONFIRM_SUBMIT"
                                    }
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (currentIndex < questions.size - 1) "आगे (Next)" else "समीक्षा (Review)")
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    viewModel.activeTab = "home"
                                    onNavigate("home")
                                }
                            ) {
                                Icon(Icons.Default.ExitToApp, contentDescription = "Exit", modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("सहेजें और बाहर निकलें (Save & Exit)")
                            }

                            Button(
                                onClick = { screenState = "CONFIRM_SUBMIT" },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Submit", modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("जमा करें (Submit)")
                            }
                        }
                    }
                }
            }
        }

        "CONFIRM_SUBMIT" -> {
            val attempted = viewModel.userAnswers.size
            val unattempted = questions.size - attempted
            val reviewed = viewModel.markedForReview.size

            ConfirmSubmitView(
                total = questions.size,
                attempted = attempted,
                unattempted = unattempted,
                markedReview = reviewed,
                onBackToQuiz = { screenState = "PLAYING" },
                onSubmitConfirm = {
                    viewModel.submitQuizFinal()
                    screenState = "RESULT"
                }
            )
        }

        "RESULT" -> {
            QuizResultHubView(
                viewModel = viewModel,
                onBackHome = {
                    viewModel.activeTab = "home"
                    onNavigate("home")
                },
                onReviewAnswers = { screenState = "REVIEW_ANSWERS" },
                onViewAnalysis = { screenState = "ANALYSIS" }
            )
        }

        "REVIEW_ANSWERS" -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                MainAppHeader(
                    title = "उत्तर समीक्षा (Answer Key)",
                    subtitle = viewModel.quizName,
                    onBackClick = { screenState = "RESULT" }
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    itemsIndexed(questions) { index, question ->
                        val userAnswer = viewModel.userAnswers[index]
                        val correct = question.correctOption

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (userAnswer == correct) Color(0xFF2E7D32).copy(alpha = 0.5f) else Color(0xFFC62828).copy(alpha = 0.3f)
                            ),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "प्रश्न ${index + 1}: ${question.questionText}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Options indicators
                                val isCorrectA = correct == "A"
                                val isUserA = userAnswer == "A"
                                val isCorrectB = correct == "B"
                                val isUserB = userAnswer == "B"
                                val isCorrectC = correct == "C"
                                val isUserC = userAnswer == "C"
                                val isCorrectD = correct == "D"
                                val isUserD = userAnswer == "D"

                                ReviewOptionItem("A", question.optionA, isCorrectA, isUserA)
                                ReviewOptionItem("B", question.optionB, isCorrectB, isUserB)
                                if (question.questionType != "TF") {
                                    ReviewOptionItem("C", question.optionC, isCorrectC, isUserC)
                                    ReviewOptionItem("D", question.optionD, isCorrectD, isUserD)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Score status
                                if (userAnswer == null) {
                                    Text("⚠️ आपने यह प्रश्न हल नहीं किया (Skipped)", color = Color(0xFFFF9800), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                } else if (userAnswer == correct) {
                                    Text("✅ सही उत्तर (+10 अंक प्राप्त)", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                } else {
                                    Text(
                                        text = "❌ गलत उत्तर (${if (viewModel.isNegativeMarkingEnabled) "-3 अंक की कटौती" else "कोई नकारात्मक अंकन नहीं"})",
                                        color = Color(0xFFC62828),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Explanation Box
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Text("💡 व्याख्या (Explanation):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(question.explanation, fontSize = 13.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "📚 संदर्भ स्रोत: ${question.reference}",
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = { screenState = "RESULT" },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("परिणाम पर वापस जाएँ")
                }
            }
        }

        "ANALYSIS" -> {
            PerformanceAnalysisView(
                viewModel = viewModel,
                onBackToResult = { screenState = "RESULT" }
            )
        }
    }
}

// Option selection row
@Composable
fun OptionRow(
    key: String,
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val containerColor = if (isSelected) Saffron.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
    val borderStrokeColor = if (isSelected) Saffron else MaterialTheme.colorScheme.surfaceVariant

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(containerColor)
            .border(BorderStroke(if (isSelected) 2.dp else 1.dp, borderStrokeColor), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(if (isSelected) Saffron else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = key,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Text(
            text = text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun ReviewOptionItem(
    key: String,
    text: String,
    isCorrect: Boolean,
    isUserSelected: Boolean
) {
    val bgColor = when {
        isCorrect -> Color(0xFFE8F5E9)
        isUserSelected && !isCorrect -> Color(0xFFFFEBEE)
        else -> Color.Transparent
    }

    val textColor = when {
        isCorrect -> Color(0xFF2E7D32)
        isUserSelected && !isCorrect -> Color(0xFFC62828)
        else -> MaterialTheme.colorScheme.onSurface
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(vertical = 6.dp, horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isCorrect -> Color(0xFF2E7D32)
                        isUserSelected -> Color(0xFFC62828)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                key,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isCorrect || isUserSelected) Color.White else MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = text,
            fontSize = 14.sp,
            color = textColor,
            modifier = Modifier.weight(1f)
        )

        if (isCorrect) {
            Icon(Icons.Default.CheckCircle, contentDescription = "Correct", tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
        } else if (isUserSelected) {
            Icon(Icons.Default.Close, contentDescription = "Wrong", tint = Color(0xFFC62828), modifier = Modifier.size(16.dp))
        }
    }
}

// ------------------- SUBMIT SCREEN --------------------
@Composable
fun ConfirmSubmitView(
    total: Int,
    attempted: Int,
    unattempted: Int,
    markedReview: Int,
    onBackToQuiz: () -> Unit,
    onSubmitConfirm: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Submit Confirm",
                tint = Saffron,
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "क्विज़ सबमिट करें?",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "क्या आप वास्तव में इस टेस्ट को समाप्त करके अपना स्कोर देखना चाहते हैं?",
                textAlign = TextAlign.Center,
                color = Color.Gray,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("कुल प्रश्न (Total)", fontWeight = FontWeight.Bold)
                        Text("$total", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Divider()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("हल किए गए (Attempted)", color = Color(0xFF2E7D32))
                        Text("$attempted", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                    Divider()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("बिना हल किए (Unattempted)", color = Color.Gray)
                        Text("$unattempted", fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                    Divider()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("पुनरावलोकन हेतु चिन्हित (Marked)", color = Color(0xFFFF9800))
                        Text("$markedReview", fontWeight = FontWeight.Bold, color = Color(0xFFFF9800))
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            GradientButton(
                text = "हाँ, टेस्ट जमा करें (Confirm Submit) 🚀",
                onClick = onSubmitConfirm
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onBackToQuiz,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("नहीं, हल करना जारी रखें (Back to Quiz)")
            }
        }
    }
}

// ------------------- RESULT HUB VIEW --------------------
@Composable
fun QuizResultHubView(
    viewModel: GKViewModel,
    onBackHome: () -> Unit,
    onReviewAnswers: () -> Unit,
    onViewAnalysis: () -> Unit
) {
    val correct = viewModel.correctAnswersCount
    val total = viewModel.quizQuestions.value.size
    val skipped = viewModel.skippedQuestionsCount
    val wrong = viewModel.wrongAnswersCount
    val finalScore = viewModel.quizScore
    val timeTakenSeconds = viewModel.quizTimeTaken

    val percentage = if (total > 0) (correct.toFloat() / total) * 100 else 0f
    val accuracy = if ((correct + wrong) > 0) (correct.toFloat() / (correct + wrong)) * 100 else 0f
    
    // Simulate Rank
    val rank = when {
        percentage >= 90f -> 3
        percentage >= 80f -> 12
        percentage >= 50f -> 45
        else -> 82
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Saffron.copy(alpha = 0.25f), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("🏆", fontSize = 48.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "क्विज़ का परिणाम आ गया!",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black)
            )

            Text(
                text = viewModel.quizName,
                style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray),
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Score Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$correct / $total", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF2E7D32))
                            Text("सही (Correct)", fontSize = 11.sp, color = Color.Gray)
                        }
                        Divider(modifier = Modifier.width(1.dp).height(40.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$finalScore", fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            Text("कुल अंक (Score)", fontSize = 11.sp, color = Color.Gray)
                        }
                        Divider(modifier = Modifier.width(1.dp).height(40.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("#$rank", fontSize = 24.sp, fontWeight = FontWeight.Black, color = AmberGold)
                            Text("रैंक (Rank)", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    // Key Statistics
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("प्रतिशत (Percentage)", fontSize = 13.sp)
                        Text("${percentage.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("सटीकता (Accuracy)", fontSize = 13.sp)
                        Text("${accuracy.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("लिया गया समय (Time Taken)", fontSize = 13.sp)
                        val mins = timeTakenSeconds / 60
                        val secs = timeTakenSeconds % 60
                        Text("${mins}m ${secs}s", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("छोड़े गए प्रश्न (Skipped)", fontSize = 13.sp)
                        Text("$skipped", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reward Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Saffron.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, Saffron.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Saffron),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = "Coins", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("शानदार! आपने अर्जित किए:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("+${correct * 2} कॉइन्स और +${correct * 10} XP पॉइंट्स प्राप्त हुए।", fontSize = 12.sp, color = Color.DarkGray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Options
            GradientButton(
                text = "📊 प्रदर्शन विश्लेषण (Performance Analysis)",
                onClick = onViewAnalysis
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onReviewAnswers,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.MenuBook, contentDescription = "Review", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("सारे प्रश्नों के उत्तर और व्याख्या देखें")
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onBackHome,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("होम स्क्रीन पर वापस जाएँ")
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Simulated AdBanner on Quiz Result Screen (Part 6)
            com.example.ui.components.SimulatedAdBanner(viewModel = viewModel, modifier = Modifier.fillMaxWidth())
        }
    }
}

// ------------------- QUIZ START SCREEN --------------------
@Composable
fun QuizStartView(
    quizName: String,
    quizType: String,
    totalQuestions: Int,
    totalMarks: Int,
    negativeMarking: Boolean,
    timeLimitMinutes: Int,
    difficulty: String,
    onStartClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.align(Alignment.Start)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Saffron.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MenuBook, contentDescription = "Quiz Logo", tint = Saffron, modifier = Modifier.size(44.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = quizName,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            )

            Badge(
                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text(
                    text = "परीक्षा प्रकार: $quizType",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Test specifications list
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SpecRow("कुल प्रश्न (Total Questions)", "$totalQuestions Qs", Icons.Default.MenuBook)
                    Divider()
                    SpecRow("अधिकतम अंक (Total Marks)", "$totalMarks Marks", Icons.Default.Star)
                    Divider()
                    SpecRow("ऋणात्मक अंकन (Negative Marking)", if (negativeMarking) "हाँ (Yes, -1/3)" else "नहीं (No Marking)", Icons.Default.Info)
                    Divider()
                    SpecRow("समय सीमा (Time Limit)", if (timeLimitMinutes > 0) "$timeLimitMinutes मिनट" else "असीमित (Unlimited)", Icons.Default.Timer)
                    Divider()
                    SpecRow("कठिनाई स्तर (Difficulty)", difficulty, Icons.Default.EmojiEvents)
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            GradientButton(
                text = "क्विज़ शुरू करें (Start Quiz) ⚡",
                onClick = onStartClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "* कृपया सुनिश्चित करें कि आपका इंटरनेट चालू है। परिणाम स्वतः स्थानीय डेटाबेस और फायरस्टोर में सहेज लिए जाते हैं।",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }
    }
}

@Composable
fun SpecRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = label, tint = Saffron, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}


// ------------------- PERFORMANCE ANALYSIS VIEW (WITH CANVAS CHARTS) --------------------
@Composable
fun PerformanceAnalysisView(
    viewModel: GKViewModel,
    onBackToResult: () -> Unit
) {
    val correct = viewModel.correctAnswersCount
    val total = viewModel.quizQuestions.value.size
    val skipped = viewModel.skippedQuestionsCount
    val wrong = viewModel.wrongAnswersCount

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            MainAppHeader(
                title = "गहन प्रदर्शन विश्लेषण (Analysis)",
                subtitle = "स्मार्ट टॉपिक-वाइज विश्लेषण",
                onBackClick = onBackToResult
            )

            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                
                // 1. PIE CHART CARD (Correct vs Wrong vs Skipped)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("प्रश्नों की स्थिति (Questions Status Pie Chart)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(16.dp))

                        // Drawing Custom Pie Chart on Canvas
                        Box(
                            modifier = Modifier.size(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.size(150.dp)) {
                                val sum = total.toFloat()
                                if (sum > 0) {
                                    val sweepCorrect = (correct.toFloat() / sum) * 360f
                                    val sweepWrong = (wrong.toFloat() / sum) * 360f
                                    val sweepSkipped = (skipped.toFloat() / sum) * 360f

                                    // Correct (Green)
                                    drawArc(
                                        color = Color(0xFF2E7D32),
                                        startAngle = -90f,
                                        sweepAngle = sweepCorrect,
                                        useCenter = false,
                                        style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                    // Wrong (Red)
                                    drawArc(
                                        color = Color(0xFFC62828),
                                        startAngle = -90f + sweepCorrect,
                                        sweepAngle = sweepWrong,
                                        useCenter = false,
                                        style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                    // Skipped (Gray)
                                    drawArc(
                                        color = Color(0xFF9E9E9E),
                                        startAngle = -90f + sweepCorrect + sweepWrong,
                                        sweepAngle = sweepSkipped,
                                        useCenter = false,
                                        style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                } else {
                                    drawCircle(color = Color.LightGray, style = Stroke(width = 20.dp.toPx()))
                                }
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val acc = if ((correct + wrong) > 0) (correct * 100) / (correct + wrong) else 0
                                Text("$acc%", fontSize = 28.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                                Text("सटीकता", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Legends
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            LegendItem("सही ($correct)", Color(0xFF2E7D32))
                            LegendItem("गलत ($wrong)", Color(0xFFC62828))
                            LegendItem("छोड़े गए ($skipped)", Color(0xFF9E9E9E))
                        }
                    }
                }

                // 2. BAR CHART CARD (Topic Wise Correctness)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("विषय-वार दक्षता (Subject-Wise Efficiency Bar Chart)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(16.dp))

                        // Bar Chart drawn with Custom Canvas
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .padding(horizontal = 8.dp)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val barWidth = 32.dp.toPx()
                                val maxBarHeight = size.height - 30.dp.toPx()
                                val spaceBetween = (size.width - (barWidth * 4)) / 5

                                val scores = listOf(85f, 50f, 90f, 65f) // simulated topic percentages
                                val colors = listOf(Color(0xFF3F51B5), Color(0xFF009688), Color(0xFFFF9800), Color(0xFFE91E63))

                                scores.forEachIndexed { index, score ->
                                    val x = spaceBetween + index * (barWidth + spaceBetween)
                                    val height = (score / 100f) * maxBarHeight
                                    val y = size.height - height - 16.dp.toPx()

                                    // Draw background bar
                                    drawRect(
                                        color = Color.LightGray.copy(alpha = 0.2f),
                                        topLeft = androidx.compose.ui.geometry.Offset(x, 0f),
                                        size = androidx.compose.ui.geometry.Size(barWidth, maxBarHeight),
                                        style = androidx.compose.ui.graphics.drawscope.Fill
                                    )

                                    // Draw correct score bar
                                    drawRect(
                                        color = colors[index],
                                        topLeft = androidx.compose.ui.geometry.Offset(x, y),
                                        size = androidx.compose.ui.geometry.Size(barWidth, height),
                                        style = androidx.compose.ui.graphics.drawscope.Fill
                                    )
                                }
                            }
                        }

                        // Labels for subjects
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            SubjectLabel("इतिहास (Hist)", Color(0xFF3F51B5))
                            SubjectLabel("भूगोल (Geo)", Color(0xFF009688))
                            SubjectLabel("संस्कृति (Cult)", Color(0xFFFF9800))
                            SubjectLabel("राजव्यवस्था (Pol)", Color(0xFFE91E63))
                        }
                    }
                }

                // 3. STRONG & WEAK TOPICS
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("सकारात्मक व सुधारात्मक विषय (Topic Analysis)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            // Strong Topics
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Strong", tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("मजबूत पक्ष (Strong)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                BulletItem("राजस्थान एकीकरण")
                                BulletItem("ऐतिहासिक कला-कृति")
                                BulletItem("संविधान संशोधन")
                            }

                            // Weak Topics
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, contentDescription = "Weak", tint = Color(0xFFC62828), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("कमजोर पक्ष (Weak)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFC62828))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                BulletItem("अरावली नदी अपवाह तंत्र")
                                BulletItem("1857 नसीराबाद क्रांति")
                                BulletItem("संसदीय आयु सीमा")
                            }
                        }
                    }
                }

                // 4. IMPROVEMENT SUGGESTIONS
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = "Tips", tint = Saffron)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("सुझाव व मार्गदर्शन (Improvement Suggestions)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "1. भूगोल और अपवाह तंत्र के प्रश्नों का गहराई से अभ्यास करें।\n" +
                                   "2. नकारात्मक अंकन से बचने हेतु केवल 80% से ऊपर सुनिश्चित होने वाले प्रश्नों को ही हल करें।\n" +
                                   "3. हमारी पीडीएफ और नोट्स सेक्शन में जाकर अरावली पर्वत श्रेणी के विस्तृत नोट्स पढ़ें।",
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Button(
                    onClick = onBackToResult,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("परिणाम देखें (Back to Results)")
                }
            }
        }
    }
}

@Composable
fun LegendItem(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SubjectLabel(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BulletItem(text: String) {
    Row(
        modifier = Modifier.padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Gray))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
    }
}
