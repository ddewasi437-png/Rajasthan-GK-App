package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CustomAvatar
import com.example.ui.theme.AmberGold
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.Saffron
import com.example.ui.viewmodel.GKViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
    viewModel: GKViewModel,
    onNavigate: (String) -> Unit
) {
    var name by remember { mutableStateOf(viewModel.userName) }
    var email by remember { mutableStateOf(viewModel.userEmail) }
    var phone by remember { mutableStateOf(viewModel.userPhone) }
    var selectedAvatar by remember { mutableStateOf(viewModel.userAvatar) }
    var state by remember { mutableStateOf(viewModel.userState) }
    var district by remember { mutableStateOf(viewModel.userDistrict) }
    val selectedExams = remember { mutableStateOf(viewModel.userTargetExams.toMutableSet()) }

    var expandedState by remember { mutableStateOf(false) }
    var expandedDistrict by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val statesList = listOf("राजस्थान (Rajasthan)", "दिल्ली (Delhi)", "हरियाणा (Haryana)", "उत्तर प्रदेश (UP)", "मध्य प्रदेश (MP)")
    val districtsList = listOf("जयपुर (Jaipur)", "जोधपुर (Jodhpur)", "उदयपुर (Udaipur)", "अजमेर (Ajmer)", "पाली (Pali)", "सीकर (Sikar)", "बीकानेर (Bikaner)", "कोटा (Kota)", "अलवर (Alwar)", "सिरोही (Sirohi)")
    val targetExamsList = listOf("RAS", "REET", "CET", "Patwar", "Rajasthan Police", "LDC", "Teacher Grade I & II", "SSC GD")
    val avatarsList = listOf("avatar_male_1", "avatar_male_2", "avatar_female_1", "avatar_female_2", "avatar_male_3", "avatar_female_3")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .statusBarsPadding()
        ) {
            // Header Top Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Saffron, AmberGold)
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Column {
                    Text(
                        text = "प्रोफ़ाइल सेटअप (Profile Setup)",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
                    )
                    Text(
                        text = "बेहतर अनुभव के लिए कृपया अपनी सही जानकारी भरें।",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // Scrollable Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Avatar Selection Section
                Text(
                    text = "अवतार (Avatar) चुनें",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    avatarsList.forEach { avatar ->
                        val isSelected = selectedAvatar == avatar
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                    else Color.Transparent
                                )
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f),
                                    shape = CircleShape
                                )
                                .clickable { selectedAvatar = avatar }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CustomAvatar(
                                avatarId = avatar,
                                size = 56.dp
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f))

                // Error message banner
                errorMsg?.let { err ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = err,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // General details Form
                Text(
                    text = "व्यक्तिगत विवरण (Personal Details)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                // Name TextField
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("विद्यार्थी का नाम (Full Name)") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Email TextField
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("ईमेल पता (Email Address)") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Phone TextField
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("मोबाइल नंबर (Mobile Number)") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = "Phone") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // State Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedState,
                    onExpandedChange = { expandedState = !expandedState },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = state,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("राज्य (State)") },
                        leadingIcon = { Icon(Icons.Default.Map, contentDescription = "State") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedState) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedState,
                        onDismissRequest = { expandedState = false }
                    ) {
                        statesList.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s) },
                                onClick = {
                                    state = s
                                    expandedState = false
                                }
                            )
                        }
                    }
                }

                // District Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedDistrict,
                    onExpandedChange = { expandedDistrict = !expandedDistrict },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = district,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("ज़िला (District)") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = "District") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDistrict) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                    )
                    ExposedDropdownMenu(
                        expanded = expandedDistrict,
                        onDismissRequest = { expandedDistrict = false }
                    ) {
                        districtsList.forEach { d ->
                            DropdownMenuItem(
                                text = { Text(d) },
                                onClick = {
                                    district = d
                                    expandedDistrict = false
                                }
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f))

                // Target Exams Selection Multi-Select Badges
                Text(
                    text = "लक्ष्य परीक्षा (Target Exams) चुनें",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    targetExamsList.forEach { exam ->
                        val isSelected = selectedExams.value.contains(exam)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                val current = selectedExams.value.toMutableSet()
                                if (isSelected) {
                                    current.remove(exam)
                                } else {
                                    current.add(exam)
                                }
                                selectedExams.value = current
                            },
                            label = { Text(exam, fontWeight = FontWeight.Bold) },
                            leadingIcon = if (isSelected) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Submit Button
                Button(
                    onClick = {
                        if (name.trim().isEmpty()) {
                            errorMsg = "कृपया अपना पूरा नाम दर्ज करें।"
                            return@Button
                        }
                        if (phone.trim().isEmpty() || phone.length < 10) {
                            errorMsg = "कृपया 10-अंकीय मोबाइल नंबर दर्ज करें।"
                            return@Button
                        }
                        if (selectedExams.value.isEmpty()) {
                            errorMsg = "कृपया कम से कम एक लक्ष्य परीक्षा चुनें।"
                            return@Button
                        }

                        // Save details to SharedPrefs & VM state
                        viewModel.saveProfile(
                            name = name,
                            phone = phone,
                            email = email,
                            photo = selectedAvatar,
                            state = state,
                            district = district,
                            targetExams = selectedExams.value
                        )

                        onNavigate("home")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("जानकारी सुरक्षित करें और ऐप शुरू करें", fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
        }
    }
}
